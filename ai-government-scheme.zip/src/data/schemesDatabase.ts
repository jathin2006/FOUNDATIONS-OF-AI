import { GovernmentScheme, ProfileData } from '../types';

// Helper to parse currency formatted as e.g. "3,50,000" or "350000"
export const parseIncome = (incomeStr: string): number => {
  if (!incomeStr) return 0;
  const clean = incomeStr.replace(/[^\d]/g, '');
  const val = parseInt(clean, 10);
  return isNaN(val) ? 0 : val;
};

// Helper for form validation: returns number, or null if empty/invalid (does not default to 0)
export const parseNumericIncome = (incomeStr?: string | null): number | null => {
  if (incomeStr === undefined || incomeStr === null) return null;
  const clean = String(incomeStr).trim().replace(/[^\d]/g, '');
  if (clean === '') return null;
  const val = parseInt(clean, 10);
  return isNaN(val) ? null : val;
};

// Helper for form validation: returns positive whole number (or 0), or null if empty/invalid
export const parseWholeNumber = (val?: string | null): number | null => {
  if (val === undefined || val === null) return null;
  const str = String(val).trim();
  if (str === '') return null;
  if (!/^\d+$/.test(str)) return null;
  const num = parseInt(str, 10);
  return isNaN(num) ? null : num;
};

export const parseAge = (ageStr: string): number => {
  if (!ageStr) return 0;
  const val = parseInt(ageStr, 10);
  return isNaN(val) ? 0 : val;
};

export const parsePercentage = (pctStr: string): number => {
  if (!pctStr) return 0;
  const val = parseInt(pctStr, 10);
  return isNaN(val) ? 0 : val;
};

export const SCHEMES_DATABASE: GovernmentScheme[] = [
  // 1. Post-Matric Scholarship
  {
    id: 'pms-sc-st-obc',
    name: 'Post-Matric Scholarship Scheme for SC/ST/OBC Students',
    department: 'Department of Social Justice and Empowerment / Ministry of Tribal Affairs',
    category: 'Education',
    description:
      'Provides financial assistance to Scheduled Caste, Scheduled Tribe, and Other Backward Class students studying at post-matriculation or post-secondary stages to enable them to complete their education.',
    benefits: [
      'Full compulsory non-refundable fees reimbursement including tuition fees',
      'Monthly maintenance allowance ranging from ₹550 to ₹1,200 per month',
      'Study tour charges, thesis typing charges, and book grant for professional courses',
      'Direct Benefit Transfer (DBT) directly into the student bank account',
    ],
    rules: [
      {
        id: 'category-check',
        label: 'Social Category Requirement',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = ['SC', 'ST', 'OBC'].includes(p.casteCategory);
          return {
            satisfied: valid,
            reason: valid
              ? `Profile category (${p.casteCategory}) is eligible for Post-Matric social scholarship.`
              : `Requires SC, ST, or OBC category. Profile indicates ${p.casteCategory || 'unspecified'}.`,
          };
        },
      },
      {
        id: 'income-check',
        label: 'Family Annual Income Limit',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const inc = parseIncome(p.familyIncome);
          const limit = p.casteCategory === 'OBC' ? 150000 : 250000;
          const valid = inc <= limit;
          return {
            satisfied: valid,
            reason: valid
              ? `Family annual income (₹ ${inc.toLocaleString('en-IN')}) is within the ceiling of ₹ ${limit.toLocaleString('en-IN')}.`
              : `Family income (₹ ${inc.toLocaleString('en-IN')}) exceeds the ceiling of ₹ ${limit.toLocaleString('en-IN')}.`,
          };
        },
      },
      {
        id: 'education-level',
        label: 'Post-Matriculation Education Level',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const postMatricLevels = ['Higher Secondary', 'Diploma', 'Undergraduate', 'Postgraduate', 'PhD'];
          const valid = postMatricLevels.includes(p.educationLevel);
          return {
            satisfied: valid,
            reason: valid
              ? `Current education level (${p.educationLevel}) qualifies as post-matric studies.`
              : `Must be enrolled in Higher Secondary, Diploma, Degree, or PG. Current level is ${p.educationLevel || 'unspecified'}.`,
          };
        },
      },
      {
        id: 'student-status',
        label: 'Active Student Enrollment',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.currentStudent === 'Yes';
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate is currently an active enrolled student.'
              : 'Candidate must be currently studying in an accredited institution.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Aadhaar Card (linked to bank account for DBT)',
      'Verified Caste / Community Certificate issued by competent revenue authority',
      'Current Financial Year Income Certificate',
      'Previous examination mark sheets and admission fee receipt',
      'Bank passbook photocopy showing IFSC and account details',
    ],
    applicationProcess: [
      'Register on the National Scholarship Portal (NSP) with Aadhaar credentials',
      'Select Post-Matric Scholarship Scheme under the respective State / Central ministry tab',
      'Upload verified institutional bona fide certificate and income documents',
      'Submit for institutional level verification and state nodal approval',
    ],
    officialUrl: 'https://scholarships.gov.in',
    lastUpdated: '15 June 2026',
  },

  // 2. Pradhan Mantri Awas Yojana (PMAY)
  {
    id: 'pmay-housing',
    name: 'Pradhan Mantri Awas Yojana (PMAY - Urban & Gramin)',
    department: 'Ministry of Housing and Urban Affairs / Ministry of Rural Development',
    category: 'Housing',
    description:
      'A flagship mission providing central financial assistance to homeless families and households living in kutcha/dilapidated houses to build a pucca dwelling unit equipped with basic amenities.',
    benefits: [
      'Financial subsidy of ₹1,20,000 in plains and ₹1,30,000 in hilly/difficult regions for construction',
      'Additional support of 90 to 95 days of unskilled labor wage under MGNREGS (approx. ₹20,000)',
      'Direct subsidy of ₹12,000 for construction of household latrine under Swachh Bharat Mission',
      'Priority for women co-ownership or sole ownership of the dwelling unit',
    ],
    rules: [
      {
        id: 'no-pucca-house',
        label: 'Homeless / No Existing Pucca House',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.ownHouse === 'No';
          return {
            satisfied: valid,
            reason: valid
              ? 'Applicant does not currently own a pucca residential house.'
              : 'Applicants already owning a pucca residential house are not eligible for new dwelling unit assistance.',
          };
        },
      },
      {
        id: 'income-bracket',
        label: 'EWS / LIG / BPL Household Criteria',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const inc = parseIncome(p.familyIncome);
          const isBpl = p.bplRationCard === 'Yes';
          const valid = inc <= 300000 || isBpl || p.casteCategory === 'EWS';
          return {
            satisfied: valid,
            reason: valid
              ? 'Household qualifies under EWS/LIG or BPL economic criteria.'
              : `Family income (₹ ${inc.toLocaleString('en-IN')}) exceeds the Economically Weaker Section limit of ₹ 3,00,000.`,
          };
        },
      },
      {
        id: 'family-status',
        label: 'Family Household Composition',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const count = parseInt(p.familyMembersCount, 10);
          const valid = !isNaN(count) && count >= 1;
          return {
            satisfied: valid,
            reason: 'Household unit verified with valid family member count.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Aadhaar card of all adult family members',
      'Affidavit / declaration of not owning a pucca house anywhere in India',
      'Ration card or BPL survey confirmation number',
      'Bank account details seeded with Aadhaar',
      'Land title document or local panchayat/municipal allotment certificate',
    ],
    applicationProcess: [
      'Apply online via pmaymis.gov.in or through nearest Common Service Centre (CSC)',
      'Local revenue and panchayat physical survey verification of current kutcha house',
      'Geo-tagging of proposed construction site before fund installment release',
      'Three-stage DBT disbursement aligned with plinth, lintel, and roof completion',
    ],
    officialUrl: 'https://pmaymis.gov.in',
    lastUpdated: '10 May 2026',
  },

  // 3. PM-KISAN
  {
    id: 'pm-kisan',
    name: 'PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)',
    department: 'Department of Agriculture and Farmers Welfare',
    category: 'Agriculture',
    description:
      'Direct income support scheme providing ₹6,000 per year in three equal four-monthly installments of ₹2,000 directly to landholding farmer families across the nation.',
    benefits: [
      'Unconditional income support of ₹6,000 per year directly into bank accounts via DBT',
      'Assists small and marginal agricultural households in procuring crop inputs and seeds',
      'Protects farmers from informal high-interest moneylenders at the start of sowing season',
    ],
    rules: [
      {
        id: 'farmer-status',
        label: 'Farmer Occupation Status',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.isFarmer === 'Yes' || p.employmentStatus === 'Farmer';
          return {
            satisfied: valid,
            reason: valid
              ? 'Applicant confirmed active farming / cultivator engagement.'
              : 'Applicant profile indicates non-farmer occupation.',
          };
        },
      },
      {
        id: 'agri-land-ownership',
        label: 'Agricultural Land Title Ownership',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.ownAgriculturalLand === 'Yes' || p.farmerLandOwnership === 'Yes';
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate holds verified cultivable agricultural land title.'
              : 'PM-KISAN mandates ownership of cultivable land records in applicant or family name.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Citizenship Aadhaar Card (mandatory e-KYC)',
      'Land revenue ownership record (Khata / Khasra / RoR document)',
      'Aadhaar-seeded active bank savings account',
    ],
    applicationProcess: [
      'Self-registration on PM-KISAN portal (pmkisan.gov.in) or via Village Patwari / CSC',
      'Complete biometric or OTP-based Aadhaar e-KYC',
      'State revenue department verifies landholding against digital land records',
    ],
    officialUrl: 'https://pmkisan.gov.in',
    lastUpdated: '22 July 2026',
  },

  // 4. Ayushman Bharat - PM-JAY
  {
    id: 'pmjay-health',
    name: 'Ayushman Bharat - Pradhan Mantri Jan Arogya Yojana (PM-JAY)',
    department: 'National Health Authority, Ministry of Health and Family Welfare',
    category: 'Health',
    description:
      'The world’s largest health assurance scheme providing a health cover of ₹5,00,000 per family per year for secondary and tertiary care hospitalization across empanelled public and private hospitals.',
    benefits: [
      'Cashless hospital care up to ₹5,00,000 per family per year with no co-pay',
      'Coverage includes 3 days pre-hospitalization and 15 days post-hospitalization expenses',
      'Covers nearly 1,949 medical and surgical procedures across 27 specialties',
      'No restriction on family size, age, or gender',
    ],
    rules: [
      {
        id: 'economic-vulnerability',
        label: 'Deprivation / BPL / Vulnerable Household Criteria',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const isBpl = p.bplRationCard === 'Yes';
          const inc = parseIncome(p.familyIncome);
          const valid = isBpl || inc <= 250000 || p.casteCategory === 'SC' || p.casteCategory === 'ST';
          return {
            satisfied: valid,
            reason: valid
              ? 'Household matches SECC deprivation or BPL priority health assurance criteria.'
              : 'PM-JAY targets families within SECC socio-economic deprivation or priority ration thresholds.',
          };
        },
      },
      {
        id: 'disability-or-senior',
        label: 'Special Priority Factors',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const hasDisability = p.personWithDisability === 'Yes';
          const valid = age >= 60 || hasDisability || p.gender === 'Female';
          return {
            satisfied: valid,
            reason: valid
              ? 'Qualifies for expedited senior citizen / PwD / female-headed household coverage.'
              : 'General eligible applicant within household quota.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Aadhaar card or recognized government photo identity',
      'Ration card / Family identity card verifying family composition',
    ],
    applicationProcess: [
      'Check eligibility on mera.pmjay.gov.in using registered mobile number or Ration card',
      'Visit nearest Ayushman Mitra kiosk at any empanelled hospital or CSC',
      'Complete biometric verification and generate personalized Ayushman Card (PVC/Digital)',
    ],
    officialUrl: 'https://pmjay.gov.in',
    lastUpdated: '18 August 2026',
  },

  // 5. Pradhan Mantri Mudra Yojana (PMMY)
  {
    id: 'pmmy-mudra',
    name: 'Pradhan Mantri Mudra Yojana (PMMY)',
    department: 'Department of Financial Services, Ministry of Finance',
    category: 'Financial Assistance',
    description:
      'Provides collateral-free institutional loans up to ₹10,00,000 to non-corporate, non-farm small and micro enterprises to encourage micro-entrepreneurship and self-employment.',
    benefits: [
      'Shishu loan: Coverage up to ₹50,000 for setting up early-stage micro-ventures',
      'Kishore loan: Coverage from ₹50,001 up to ₹5,00,000 for operational expansion',
      'Tarun loan: Coverage from ₹5,00,001 up to ₹10,00,000 for established small businesses',
      'Zero collateral or third-party guarantee required from the entrepreneur',
    ],
    rules: [
      {
        id: 'age-requirement',
        label: 'Minimum Age Requirement (18+)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const valid = age >= 18;
          return {
            satisfied: valid,
            reason: valid
              ? `Applicant age (${age} years) satisfies legal contractual credit age (18+).`
              : `Applicant must be at least 18 years old. Current age: ${age || 0}.`,
          };
        },
      },
      {
        id: 'employment-or-enterprise',
        label: 'Self-Employed / Enterprise Aspirant',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = ['Self-employed', 'Unemployed', 'Daily Wage Worker', 'Other'].includes(p.employmentStatus);
          return {
            satisfied: valid,
            reason: valid
              ? `Employment profile (${p.employmentStatus}) qualifies for micro-enterprise credit.`
              : 'Targeted primarily at self-employed traders, micro-manufacturers, and small service providers.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Identity Proof (Aadhaar / Voter ID / PAN)',
      'Proof of business address or enterprise Udyam registration (if operational)',
      'Bank statement for previous 6 months (for Kishore & Tarun categories)',
      'Business project quotation for machinery or inventory purchases',
    ],
    applicationProcess: [
      'Apply online via udyamimitra.in portal or visit any public/private commercial bank or NBFC',
      'Submit project proposal specifying loan category (Shishu / Kishore / Tarun)',
      'Bank appraises the micro-business plan and disburses Mudra loan card',
    ],
    officialUrl: 'https://www.mudra.org.in',
    lastUpdated: '04 April 2026',
  },

  // 6. National Means-cum-Merit Scholarship (NMMSS)
  {
    id: 'nmmss-education',
    name: 'National Means-cum-Merit Scholarship Scheme (NMMSS)',
    department: 'Department of School Education & Literacy, Ministry of Education',
    category: 'Education',
    description:
      'Awards scholarships to meritorious students of economically weaker sections to arrest their drop out at class 8 and encourage them to continue secondary schooling.',
    benefits: [
      'Scholarship amount of ₹12,000 per annum (₹1,000 per month) from Class 9 to Class 12',
      'Assistance disbursed directly into student accounts via Public Financial Management System (PFMS)',
    ],
    rules: [
      {
        id: 'school-education-level',
        label: 'Secondary / High School Level',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = ['Secondary School', 'Higher Secondary', 'Primary School'].includes(p.educationLevel);
          return {
            satisfied: valid,
            reason: valid
              ? `Education level (${p.educationLevel}) matches school scholarship tier.`
              : `Restricted to school students up to secondary level. Current level is ${p.educationLevel || 'unspecified'}.`,
          };
        },
      },
      {
        id: 'family-income-nmmss',
        label: 'Income Ceiling (₹ 3,50,000)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const inc = parseIncome(p.familyIncome);
          const valid = inc <= 350000;
          return {
            satisfied: valid,
            reason: valid
              ? `Family income (₹ ${inc.toLocaleString('en-IN')}) is within NMMSS threshold of ₹ 3,50,000.`
              : `Family income (₹ ${inc.toLocaleString('en-IN')}) exceeds NMMSS limit of ₹ 3,50,000.`,
          };
        },
      },
      {
        id: 'active-student',
        label: 'Active School Student Status',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.currentStudent === 'Yes';
          return {
            satisfied: valid,
            reason: valid
              ? 'Student is actively enrolled in regular schooling.'
              : 'Must be actively studying in an accredited state or government-aided school.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Aadhaar card of student and parent',
      'Class 7/8 mark sheet with minimum 55% marks (50% for SC/ST)',
      'Income certificate from revenue authority not exceeding ₹3,50,000',
      'Bank passbook linked to student Aadhaar',
    ],
    applicationProcess: [
      'Appear for State Level NMMSS written selection examination',
      'Selected candidates register on National Scholarship Portal (NSP)',
      'School headmaster verifies attendance and promotes record annually',
    ],
    officialUrl: 'https://scholarships.gov.in',
    lastUpdated: '12 January 2026',
  },

  // 7. PM Vishwakarma Scheme
  {
    id: 'pm-vishwakarma',
    name: 'PM Vishwakarma Scheme',
    department: 'Ministry of Micro, Small and Medium Enterprises',
    category: 'Employment',
    description:
      'Provides holistic end-to-end support to traditional artisans and craftspeople working with their hands and tools across 18 designated traditional trades.',
    benefits: [
      'Recognition as a verified Vishwakarma with ID card and certificate',
      'Skill upgradation with 5–7 days basic training and ₹500/day stipend',
      'Modern tool-kit incentive grant of ₹15,000 in electronic voucher form',
      'Collateral-free credit support up to ₹1,00,000 (1st tranche) and ₹2,00,000 (2nd tranche) at concessional 5% interest',
    ],
    rules: [
      {
        id: 'artisan-trade',
        label: 'Artisan / Traditional Craft Engagement',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = ['Self-employed', 'Daily Wage Worker', 'Other'].includes(p.employmentStatus);
          return {
            satisfied: valid,
            reason: valid
              ? `Work status (${p.employmentStatus}) qualifies for artisan guild onboarding.`
              : 'Scheme is focused on traditional hand-tool crafts and artisan trades.',
          };
        },
      },
      {
        id: 'age-limit',
        label: 'Minimum Age 18 Years',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const valid = age >= 18;
          return {
            satisfied: valid,
            reason: valid
              ? `Applicant age (${age} years) is eligible.`
              : `Must be at least 18 years on date of application.`,
          };
        },
      },
    ],
    requiredDocuments: [
      'Aadhaar card with biometric authentication',
      'Bank account passbook',
      'Self-declaration of traditional trade occupation (Carpentry, Blacksmith, Potter, Tailor, Cobbler, Mason, etc.)',
    ],
    applicationProcess: [
      'Free biometric registration at any nearest Common Service Centre (CSC)',
      'Three-stage verification: Gram Panchayat / Urban Local Body, District Implementation Committee, Screening Committee',
      'Commence basic skill training and receive e-toolkit voucher',
    ],
    officialUrl: 'https://pmvishwakarma.gov.in',
    lastUpdated: '01 July 2026',
  },

  // 8. Indira Gandhi National Disability Pension Scheme (IGNDPS)
  {
    id: 'igndps-pension',
    name: 'Indira Gandhi National Disability Pension Scheme (IGNDPS)',
    department: 'Department of Rural Development, Ministry of Rural Development',
    category: 'Social Welfare',
    description:
      'Provides monthly social security pension to persons with severe or multiple disabilities belonging to below poverty line households.',
    benefits: [
      'Monthly central pension of ₹300 per month (combined with state top-up up to ₹1,500 - ₹3,000 in various states)',
      'Free healthcare assistive devices and priority transit passes in public transport',
    ],
    rules: [
      {
        id: 'pwd-status',
        label: 'Person with Disability (Divyangjan)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.personWithDisability === 'Yes';
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate is registered as Person with Disability.'
              : 'Scheme specifically caters to persons with severe disabilities.',
          };
        },
      },
      {
        id: 'disability-severity',
        label: 'Severe Disability Benchmark (80%+ or Severe)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const pct = parsePercentage(p.disabilityPercentage);
          const valid = pct >= 40;
          return {
            satisfied: valid,
            reason: valid
              ? `Disability degree (${pct}%) satisfies statutory Divyangjan pension norms.`
              : `Requires certified disability of 40% or above. Profile specifies ${pct || 0}%.`,
          };
        },
      },
      {
        id: 'bpl-pension-check',
        label: 'BPL / Low Income Family Status',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const isBpl = p.bplRationCard === 'Yes';
          const inc = parseIncome(p.familyIncome);
          const valid = isBpl || inc <= 200000;
          return {
            satisfied: valid,
            reason: valid
              ? 'Economic status conforms to social security pension limits.'
              : 'Requires BPL cardholder or economically distressed family status.',
          };
        },
      },
    ],
    requiredDocuments: [
      'UDID (Unique Disability Identity Card) or District Medical Board certificate',
      'BPL card / Ration card copy',
      'Aadhaar card linked with bank account',
      'Age proof verifying applicant is between 18 and 79 years',
    ],
    applicationProcess: [
      'Submit physical or online application via Gram Panchayat / Block Development Office (BDO) or state social welfare portal (nsap.nic.in)',
      'Verification of disability certificate by Medical Officer',
      'Pension sanctioned directly through DBT into beneficiary account',
    ],
    officialUrl: 'https://nsap.nic.in',
    lastUpdated: '14 March 2026',
  },

  // 9. Indira Gandhi National Widow Pension Scheme (IGNWPS)
  {
    id: 'ignwps-pension',
    name: 'Indira Gandhi National Widow Pension Scheme (IGNWPS)',
    department: 'Ministry of Rural Development',
    category: 'Social Welfare',
    description:
      'Monthly social security pension for widowed women belonging to households living below the poverty line.',
    benefits: [
      'Monthly financial pension support credited directly to the beneficiary account',
      'Access to priority grain allocation under Antyodaya Anna Yojana',
    ],
    rules: [
      {
        id: 'widow-status',
        label: 'Marital Status: Widowed',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.maritalStatus === 'Widowed' && p.gender === 'Female';
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate meets widowed female eligibility criteria.'
              : `Requires widowed female candidate. Profile indicates ${p.gender || 'unspecified'}, ${p.maritalStatus || 'unspecified'}.`,
          };
        },
      },
      {
        id: 'age-criterion',
        label: 'Age between 40 and 79 Years',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const valid = age >= 40 && age <= 79;
          return {
            satisfied: valid,
            reason: valid
              ? `Age (${age} years) satisfies age bracket of 40–79 years.`
              : `Candidate must be aged between 40 and 79 years. Current age: ${age || 0}.`,
          };
        },
      },
      {
        id: 'economic-need',
        label: 'BPL / Low Income Family Status',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.bplRationCard === 'Yes' || parseIncome(p.familyIncome) <= 200000;
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate meets BPL / priority social assistance economic conditions.'
              : 'Requires BPL status or low family annual income.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Death Certificate of late spouse',
      'Aadhaar card of applicant',
      'BPL survey list inclusion proof / ration card',
      'Bank passbook photocopy with IFSC code',
    ],
    applicationProcess: [
      'Apply at the office of Block Development Officer (BDO) or Municipal Sub-Divisional Magistrate',
      'Gram Sabha / Urban Local Body social audit verification',
      'Enrollment on National Social Assistance Programme (NSAP) portal',
    ],
    officialUrl: 'https://nsap.nic.in',
    lastUpdated: '11 February 2026',
  },

  // 10. Stand-Up India Scheme
  {
    id: 'standup-india',
    name: 'Stand-Up India Scheme for Women and SC/ST Entrepreneurs',
    department: 'Department of Financial Services, Ministry of Finance / SIDBI',
    category: 'Financial Assistance',
    description:
      'Facilitates bank loans between ₹10,00,000 and ₹1,00,00,000 to at least one Scheduled Caste (SC) or Scheduled Tribe (ST) borrower and at least one woman borrower per bank branch for setting up greenfield enterprises.',
    benefits: [
      'Composite loan (term loan and working capital) between ₹10 Lakhs and ₹1 Crore',
      'Repayable in 7 years with a maximum moratorium period of 18 months',
      'Covered by Credit Guarantee Fund for Stand-Up India (CGFSI)',
    ],
    rules: [
      {
        id: 'sc-st-or-woman',
        label: 'SC / ST Category or Woman Borrower',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const isScSt = ['SC', 'ST'].includes(p.casteCategory);
          const isWoman = p.gender === 'Female';
          const valid = isScSt || isWoman;
          return {
            satisfied: valid,
            reason: valid
              ? `Qualifies as ${isScSt ? 'SC/ST candidate' : 'Woman entrepreneur'}.`
              : 'Stand-Up India is earmarked exclusively for SC/ST individuals or Women entrepreneurs.',
          };
        },
      },
      {
        id: 'age-check',
        label: 'Minimum Age 18 Years',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const valid = age >= 18;
          return {
            satisfied: valid,
            reason: valid ? `Age (${age}) meets adult enterprise borrowing norms.` : 'Must be at least 18 years old.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Aadhaar / Voter ID / Passport',
      'Caste certificate (for SC/ST applicants)',
      'Detailed Project Report (DPR) for the proposed greenfield business',
      'PAN card and proof of promoter contribution (minimum 10% to 15%)',
    ],
    applicationProcess: [
      'Apply directly on the Stand-Up India portal (standupmitra.in)',
      'Select handholding support agency or connect with designated Lead District Manager (LDM)',
      'Scheduled commercial bank branch assesses DPR and sanctions loan',
    ],
    officialUrl: 'https://www.standupmitra.in',
    lastUpdated: '30 May 2026',
  },

  // 11. Pradhan Mantri Fasal Bima Yojana (PMFBY)
  {
    id: 'pmfby-insurance',
    name: 'Pradhan Mantri Fasal Bima Yojana (PMFBY)',
    department: 'Ministry of Agriculture and Farmers Welfare',
    category: 'Agriculture',
    description:
      'Comprehensive crop insurance providing financial support to farmers suffering crop loss or damage arising from unforeseen weather events, pests, and natural calamities.',
    benefits: [
      'Very low uniform farmer premium: 2% for Kharif crops, 1.5% for Rabi crops, and 5% for annual commercial/horticultural crops',
      'Full insured sum payable with zero upper cap on government subsidy',
      'Covers prevented sowing, standing crop damage, post-harvest losses, and localized localized calamities like hailstorms',
    ],
    rules: [
      {
        id: 'farmer-cultivator',
        label: 'Active Farmer / Cultivator Profile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.isFarmer === 'Yes' || p.employmentStatus === 'Farmer';
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate is actively involved in crop cultivation.'
              : 'Applicable exclusively to food grain, oilseed, and notified crop farmers.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Land Record Document (Khasra / Khatauni) or Tenancy agreement',
      'Sowing certificate / declaration issued by local village revenue official',
      'Aadhaar card and active bank passbook',
    ],
    applicationProcess: [
      'Enroll through bank where crop loan account (KCC) is maintained or online via pmfby.gov.in',
      'Submit crop sowing details within cut-off dates announced for Kharif/Rabi seasons',
    ],
    officialUrl: 'https://pmfby.gov.in',
    lastUpdated: '19 June 2026',
  },

  // 12. National Apprenticeship Promotion Scheme (NAPS)
  {
    id: 'naps-apprenticeship',
    name: 'National Apprenticeship Promotion Scheme (NAPS)',
    department: 'Ministry of Skill Development and Entrepreneurship',
    category: 'Employment',
    description:
      'Promotes apprenticeship training in industrial establishments, providing industry-led on-the-job training with shared stipend support from the Government of India.',
    benefits: [
      'Government reimburses 25% of prescribed stipend up to ₹1,500 per month per apprentice',
      'Hands-on industrial workplace experience and National Apprenticeship Certificate (NAC)',
      'High pathway to permanent absorption and skilled employment',
    ],
    rules: [
      {
        id: 'age-naps',
        label: 'Age between 14 and 35 Years',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const valid = age >= 14 && age <= 35;
          return {
            satisfied: valid,
            reason: valid
              ? `Age (${age} years) qualifies for apprenticeship training bracket.`
              : `Apprenticeship age window is 14 to 35 years. Current age: ${age || 0}.`,
          };
        },
      },
      {
        id: 'education-naps',
        label: 'Minimum 5th Pass to Degree Level',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.educationLevel !== 'Not Studying' && p.educationLevel !== '';
          return {
            satisfied: valid,
            reason: valid
              ? `Education level (${p.educationLevel}) qualifies for designated/optional apprenticeship trades.`
              : 'Requires at least basic formal education certification.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Aadhaar card',
      'Educational certificates / mark sheets (Class 10 / ITI / Diploma / Degree)',
      'Bank passbook for Direct Benefit Transfer of government stipend share',
    ],
    applicationProcess: [
      'Register as candidate on apprenticeshipindia.gov.in portal',
      'Browse trade opportunities posted by registered companies and submit digital application',
      'Sign online digital apprenticeship contract upon selection',
    ],
    officialUrl: 'https://www.apprenticeshipindia.gov.in',
    lastUpdated: '08 August 2026',
  },

  // 13. Pre-Matric Scholarship for Minorities
  {
    id: 'pre-matric-minorities',
    name: 'Pre-Matric Scholarship for Minority Communities',
    department: 'Ministry of Minority Affairs',
    category: 'Education',
    description:
      'Encourages parents from notified minority communities to send their school-going children to school and reduce the dropout rate in classes 9 and 10.',
    benefits: [
      'Admission and tuition fee assistance up to ₹500 per annum',
      'Maintenance allowance of ₹500 per month for 10 months for hostellers and ₹100 per month for day scholars',
    ],
    rules: [
      {
        id: 'minority-check',
        label: 'Notified Minority Community Status',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.minorityCommunity === 'Yes' || ['Muslim', 'Christian', 'Sikh', 'Buddhist', 'Jain', 'Parsi'].includes(p.religion);
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate belongs to a recognized minority community.'
              : 'Scheme is dedicated to notified religious minorities (Muslim, Christian, Sikh, Buddhist, Jain, Parsi).',
          };
        },
      },
      {
        id: 'school-level-check',
        label: 'Pre-Matric Education Level (Schooling)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = ['Primary School', 'Secondary School'].includes(p.educationLevel);
          return {
            satisfied: valid,
            reason: valid
              ? `Education level (${p.educationLevel}) qualifies for pre-matric scholarship.`
              : `Requires enrollment in Classes 1 through 10. Profile indicates ${p.educationLevel || 'unspecified'}.`,
          };
        },
      },
      {
        id: 'income-minority',
        label: 'Family Annual Income Limit (₹ 1,00,000)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const inc = parseIncome(p.familyIncome);
          const valid = inc <= 100000;
          return {
            satisfied: valid,
            reason: valid
              ? `Family income (₹ ${inc.toLocaleString('en-IN')}) is within the threshold of ₹ 1,00,000.`
              : `Family income (₹ ${inc.toLocaleString('en-IN')}) exceeds the Pre-Matric ceiling of ₹ 1,00,000.`,
          };
        },
      },
    ],
    requiredDocuments: [
      'Self-declaration of minority community by parent/guardian',
      'Income certificate from designated state authority',
      'Previous class mark sheet with at least 50% marks',
      'Student bank account details',
    ],
    applicationProcess: [
      'Apply online on the National Scholarship Portal (NSP)',
      'School verification by Institutional Nodal Officer (INO)',
    ],
    officialUrl: 'https://scholarships.gov.in',
    lastUpdated: '15 April 2026',
  },

  // 14. Central Sector Scheme of Scholarship for College and University Students
  {
    id: 'csss-higher-education',
    name: 'Central Sector Scheme of Scholarships for College and University Students',
    department: 'Department of Higher Education, Ministry of Education',
    category: 'Education',
    description:
      'Provides financial assistance to meritorious students from low-income families to meet a part of their day-to-day expenses while pursuing graduate and post-graduate studies.',
    benefits: [
      '₹12,000 per annum at graduation level for the first three years of college education',
      '₹20,000 per annum at postgraduate stage for two years',
    ],
    rules: [
      {
        id: 'higher-ed-level',
        label: 'Undergraduate or Postgraduate College Student',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = ['Undergraduate', 'Postgraduate'].includes(p.educationLevel);
          return {
            satisfied: valid,
            reason: valid
              ? `Education level (${p.educationLevel}) qualifies for college scholarship.`
              : `Requires college enrollment in regular UG or PG course. Current level is ${p.educationLevel || 'unspecified'}.`,
          };
        },
      },
      {
        id: 'family-income-csss',
        label: 'Family Annual Income Limit (₹ 4,50,000)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const inc = parseIncome(p.familyIncome);
          const valid = inc <= 450000;
          return {
            satisfied: valid,
            reason: valid
              ? `Family income (₹ ${inc.toLocaleString('en-IN')}) is within the limit of ₹ 4,50,000.`
              : `Family income (₹ ${inc.toLocaleString('en-IN')}) exceeds the ceiling of ₹ 4,50,000.`,
          };
        },
      },
      {
        id: 'active-college-student',
        label: 'Active Student Status',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.currentStudent === 'Yes';
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate is currently enrolled in a recognized university or college.'
              : 'Must be actively pursuing regular college education.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Class 12th Board marks verification (above 80th percentile)',
      'Income certificate not exceeding ₹4.5 Lakhs per annum',
      'Aadhaar card linked with active bank account',
      'College admission fee receipt and identity card',
    ],
    applicationProcess: [
      'Apply on National Scholarship Portal (NSP)',
      'Institute nodal officer validates college enrollment and attendance',
    ],
    officialUrl: 'https://scholarships.gov.in',
    lastUpdated: '14 May 2026',
  },

  // 15. Atal Pension Yojana (APY)
  {
    id: 'apy-pension',
    name: 'Atal Pension Yojana (APY)',
    department: 'Pension Fund Regulatory and Development Authority (PFRDA), Ministry of Finance',
    category: 'Social Welfare',
    description:
      'Guaranteed monthly pension scheme primarily focused on unorganized sector workers, providing a defined monthly pension from ₹1,000 to ₹5,000 upon reaching 60 years of age.',
    benefits: [
      'Guaranteed minimum pension of ₹1,000, ₹2,000, ₹3,000, ₹4,000, or ₹5,000 per month after age 60',
      'Same pension amount continues to the spouse upon demise of subscriber',
      'Return of accumulated pension corpus to nominee after death of both subscriber and spouse',
    ],
    rules: [
      {
        id: 'age-apy',
        label: 'Entry Age between 18 and 40 Years',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const valid = age >= 18 && age <= 40;
          return {
            satisfied: valid,
            reason: valid
              ? `Applicant age (${age} years) is within the eligible subscription window (18–40 years).`
              : `Subscriber entry age must be between 18 and 40 years. Current age: ${age || 0}.`,
          };
        },
      },
      {
        id: 'non-taxpayer',
        label: 'Targeted Non-Taxpayer Worker',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const inc = parseIncome(p.personalIncome);
          const valid = inc <= 700000;
          return {
            satisfied: valid,
            reason: 'Applicant income conforms to general unorganized subscriber profile.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Savings Bank account / Post Office savings account',
      'Aadhaar card and active mobile number',
    ],
    applicationProcess: [
      'Submit APY enrollment form at any bank branch or online through net-banking',
      'Set up auto-debit facility for monthly/quarterly contribution based on selected pension tier',
    ],
    officialUrl: 'https://www.npscra.nsdl.co.in',
    lastUpdated: '05 March 2026',
  },

  // 16. Kisan Credit Card (KCC)
  {
    id: 'kcc-loan',
    name: 'Kisan Credit Card (KCC) Scheme',
    department: 'Ministry of Agriculture and Farmers Welfare / RBI / NABARD',
    category: 'Agriculture',
    description:
      'Provides adequate and timely credit support under a single window with flexible and simplified procedures for farmers to meet agriculture cultivation expenses and post-harvest requirements.',
    benefits: [
      'Short-term production credit at an effective interest rate of 4% per annum (with 3% prompt repayment incentive)',
      'Credit limit based on scale of finance and cropping pattern',
      'Collateral-free agricultural loans up to ₹1,60,000',
      'Includes built-in accidental insurance cover',
    ],
    rules: [
      {
        id: 'kcc-farmer-check',
        label: 'Farmer / Cultivator Profile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.isFarmer === 'Yes' || p.employmentStatus === 'Farmer';
          return {
            satisfied: valid,
            reason: valid
              ? 'Applicant confirmed active farming profile.'
              : 'Targeted specifically at owner cultivators, tenant farmers, and oral lessees.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Land ownership records (Pattadar passbook / 7/12 extract)',
      'Identity and Address proof (Aadhaar / Voter ID)',
      'Crop sowing certificate',
    ],
    applicationProcess: [
      'Download 1-page simplified KCC form from agricultural department or bank portal',
      'Submit at nearest bank branch; banks mandated to sanction eligible KCC within 14 working days',
    ],
    officialUrl: 'https://pmkisan.gov.in',
    lastUpdated: '12 May 2026',
  },

  // 17. National Family Benefit Scheme (NFBS)
  {
    id: 'nfbs-welfare',
    name: 'National Family Benefit Scheme (NFBS)',
    department: 'Ministry of Rural Development',
    category: 'Social Welfare',
    description:
      'Lump-sum financial assistance to below poverty line households on the death of a primary breadwinner to shield the surviving family members from immediate impoverishment.',
    benefits: [
      'One-time lump sum grant of ₹20,000 to the bereaved family',
      'Disbursed directly into the bank account of the surviving spouse or eldest family member',
    ],
    rules: [
      {
        id: 'bpl-family',
        label: 'BPL / Low Income Household',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.bplRationCard === 'Yes' || parseIncome(p.familyIncome) <= 200000;
          return {
            satisfied: valid,
            reason: valid
              ? 'Household meets BPL / priority social assistance economic conditions.'
              : 'Requires BPL status or economically vulnerable household certification.',
          };
        },
      },
      {
        id: 'family-size',
        label: 'Multi-member Household',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const count = parseInt(p.familyMembersCount, 10);
          const valid = !isNaN(count) && count >= 2;
          return {
            satisfied: valid,
            reason: 'Household has multiple dependent members.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Death Certificate of the primary breadwinner (aged 18–59 at time of death)',
      'BPL Card / Antyodaya Card',
      'Aadhaar card of surviving applicant',
      'Bank passbook photocopy',
    ],
    applicationProcess: [
      'Submit application to the Tahsildar / Sub-Divisional Officer within 6 months of death',
      'Revenue authority verifies breadwinner status and processes DBT payment',
    ],
    officialUrl: 'https://nsap.nic.in',
    lastUpdated: '20 January 2026',
  },

  // 18. DAY-NRLM (Deendayal Antyodaya Yojana)
  {
    id: 'day-nrlm',
    name: 'Deendayal Antyodaya Yojana - National Rural Livelihoods Mission (DAY-NRLM)',
    department: 'Ministry of Rural Development',
    category: 'Employment',
    description:
      'Mobilizes rural poor households into Self Help Groups (SHGs) and supports them with revolving funds, community investment support, and bank credit linkages to diversify livelihoods.',
    benefits: [
      'Revolving fund support of ₹20,000 to ₹30,000 per eligible Self Help Group',
      'Community Investment Support Fund up to ₹2.5 Lakhs per group',
      'Interest subvention on bank loans up to ₹3,00,000 at subsidized 7% interest rate',
    ],
    rules: [
      {
        id: 'women-or-vulnerable',
        label: 'Rural / Priority Social Vulnerability',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const isWoman = p.gender === 'Female';
          const isBpl = p.bplRationCard === 'Yes';
          const valid = isWoman || isBpl || ['SC', 'ST'].includes(p.casteCategory);
          return {
            satisfied: valid,
            reason: valid
              ? 'High-priority mobilization profile for women SHGs and livelihood collectives.'
              : 'General eligible household in rural and semi-urban community blocks.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Aadhaar card',
      'SHG membership register entry or local village federation endorsement',
      'Group bank savings account details',
    ],
    applicationProcess: [
      'Join or form an SHG under Village Organization / Community Resource Person guidance',
      'Prepare micro-investment plan (MIP) and apply through local Block Mission Management Unit',
    ],
    officialUrl: 'https://aajeevika.gov.in',
    officialWebsite: 'https://aajeevika.gov.in',
    historicalUrl: 'https://aajeevika.gov.in',
    urlStatus: 'unavailable',
    urlUnavailableReason:
      'The legacy Aajeevika portal (aajeevika.gov.in) is currently non-operational or unreachable from public networks (ERR_CONNECTION_TIMED_OUT). Official schemes under DAY-NRLM are actively administered by the Ministry of Rural Development.',
    officialApplicationUrl: 'https://nrlm.gov.in',
    applicationUrlStatus: 'verified',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/day-nrlm',
    lastUpdated: '17 July 2026',
  },

  // 19. Pradhan Mantri Matru Vandana Yojana (PMMVY)
  {
    id: 'pmmvy-maternity',
    name: 'Pradhan Mantri Matru Vandana Yojana (PMMVY)',
    department: 'Ministry of Women and Child Development',
    category: 'Health',
    description:
      'Direct cash incentive for pregnant women and lactating mothers to compensate for wage loss and promote healthy nutrition and institutional healthcare practices.',
    benefits: [
      'Cash incentive of ₹5,000 in two installments for the first live child',
      'Additional incentive of ₹6,000 on birth of a second girl child to discourage gender selection',
      'Credited directly via DBT upon completing antenatal checkups and child immunization',
    ],
    rules: [
      {
        id: 'female-beneficiary',
        label: 'Female Beneficiary Profile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.gender === 'Female';
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate satisfies female maternal demographic criteria.'
              : 'PMMVY is exclusively designed for pregnant women and lactating mothers.',
          };
        },
      },
      {
        id: 'economic-need-pmmvy',
        label: 'Non-Salaried / Vulnerable Economic Household',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const inc = parseIncome(p.familyIncome);
          const valid = inc <= 800000 || p.bplRationCard === 'Yes';
          return {
            satisfied: valid,
            reason: valid
              ? 'Household income is within PMMVY social assistance ceiling.'
              : 'Excludes regular government and public sector salaried employees.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Mother and Child Protection (MCP) card issued by Anganwadi / Health Centre',
      'Aadhaar cards of pregnant woman and husband',
      'Aadhaar-seeded bank account details',
    ],
    applicationProcess: [
      'Register at the nearest Anganwadi Centre (AWC) or approved health facility',
      'Or register online on the PMMVY Citizen Portal (pmmvy.wcd.gov.in)',
    ],
    officialUrl: 'https://pmmvy.wcd.gov.in',
    lastUpdated: '02 June 2026',
  },

  // 20. Prime Minister's Employment Generation Programme (PMEGP)
  {
    id: 'pmegp-micro-business',
    name: "Prime Minister's Employment Generation Programme (PMEGP)",
    department: 'Khadi and Village Industries Commission (KVIC), Ministry of MSME',
    category: 'Employment',
    description:
      'Credit-linked subsidy programme to generate self-employment opportunities through establishment of micro-enterprises in non-farm sector.',
    benefits: [
      'Project cost up to ₹50,00,000 for manufacturing units and ₹20,00,000 for service units',
      'Capital subsidy of 15% to 25% for general category and 25% to 35% for special categories (SC/ST/OBC/Women/PwD)',
      'Bank credit finances remaining 60% to 75% of total project cost',
    ],
    rules: [
      {
        id: 'age-pmegp',
        label: 'Minimum Age 18 Years',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const valid = age >= 18;
          return {
            satisfied: valid,
            reason: valid
              ? `Applicant age (${age} years) is eligible.`
              : 'Must be at least 18 years old to apply for enterprise establishment.',
          };
        },
      },
      {
        id: 'education-for-projects',
        label: 'Education Qualification for Higher Project Outlays',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const valid = ['Higher Secondary', 'Diploma', 'Undergraduate', 'Postgraduate', 'PhD'].includes(p.educationLevel);
          return {
            satisfied: valid,
            reason: valid
              ? 'Qualified for projects above ₹10 Lakhs in manufacturing / ₹5 Lakhs in service.'
              : 'Qualified for small-scale projects up to ₹10 Lakhs without minimum academic bar.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Detailed Project Report (DPR)',
      'Aadhaar card and PAN card',
      'Caste / Special category certificate for higher subsidy (25%-35%)',
      'Educational certificate (Class 8+ mark sheet for larger units)',
    ],
    applicationProcess: [
      'Apply online on KVIC PMEGP e-portal (kviconline.gov.in)',
      'District Level Task Force Committee (DLTFC) reviews application and forwards to financing bank',
      'Undertake mandatory 5–10 days Entrepreneurship Development Programme (EDP) training before disbursement',
    ],
    officialUrl: 'https://www.kviconline.gov.in/pmegpeportal',
    lastUpdated: '11 April 2026',
  },

  // 21. Assistance to Disabled Persons for Purchase/Fitting of Aids (ADIP)
  {
    id: 'adip-disability-aids',
    name: 'Assistance to Disabled Persons for Purchase/Fitting of Aids and Appliances (ADIP)',
    department: 'Department of Empowerment of Persons with Disabilities, Ministry of Social Justice',
    category: 'Social Welfare',
    description:
      'Provides high-quality, scientifically manufactured modern aids and assistive appliances (wheelchairs, motorized tricycles, braille kits, hearing aids) free of cost to promote physical and economic independence.',
    benefits: [
      'Free distribution of assistive aids: motorized tricycles, motorized wheelchairs, smart canes, digital hearing aids',
      'Cochlear implant surgery grant up to ₹6,00,000 for children under 5 years',
      'Zero cost for beneficiaries with monthly income up to ₹15,000 (50% aid for income ₹15,001–₹20,000)',
    ],
    rules: [
      {
        id: 'disability-confirmed',
        label: 'Person with Certified Disability',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.personWithDisability === 'Yes';
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate is registered with recognized disability.'
              : 'Scheme is dedicated exclusively to Divyangjan requiring assistive equipment.',
          };
        },
      },
      {
        id: 'income-adip',
        label: 'Family Income Criteria for 100% Grant',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const inc = parseIncome(p.personalIncome);
          const valid = inc <= 250000;
          return {
            satisfied: valid,
            reason: valid
              ? 'Qualifies for 100% free aid allocation.'
              : 'Income may require partial co-contribution of 50%.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Disability Certificate showing 40% or more disability or UDID card',
      'Income Certificate issued by Revenue Authority / MP / MLA / Gazetted Officer',
      'Aadhaar card or copy of Voter ID',
    ],
    applicationProcess: [
      'Apply online on ADIP portal (adip.alimco.in) or attend mega assessment camps organized by ALIMCO',
      'Medical screening to identify suitable prosthetic or assistive apparatus',
    ],
    officialUrl: 'https://adip.alimco.in',
    lastUpdated: '25 May 2026',
  },

  // 22. Pradhan Mantri Ujjwala Yojana (PMUY)
  {
    id: 'pmuy-gas',
    name: 'Pradhan Mantri Ujjwala Yojana (PMUY - Ujjwala 2.0)',
    department: 'Ministry of Petroleum and Natural Gas',
    category: 'Social Welfare',
    description:
      'Provides deposit-free LPG connections to poor households to safeguard women and children from respiratory hazards of indoor smoke.',
    benefits: [
      'Free LPG connection with zero security deposit for cylinder and pressure regulator',
      'Free first LPG refill and a free hotplate (gas stove)',
      'Targeted recurring subsidy of ₹300 per refill directly credited to bank account for up to 12 refills a year',
    ],
    rules: [
      {
        id: 'woman-applicant',
        label: 'Adult Woman Applicant (18+)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const isAdultWoman = p.gender === 'Female' && parseAge(p.age) >= 18;
          return {
            satisfied: isAdultWoman,
            reason: isAdultWoman
              ? 'Connection will be released in the name of the adult female head of household.'
              : 'Connections under Ujjwala are issued strictly in the name of an adult woman member (18+).',
          };
        },
      },
      {
        id: 'economic-deprivation',
        label: 'BPL / Vulnerable Household Status',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.bplRationCard === 'Yes' || ['SC', 'ST', 'EWS'].includes(p.casteCategory) || parseIncome(p.familyIncome) <= 200000;
          return {
            satisfied: valid,
            reason: valid
              ? 'Household qualifies under vulnerable socioeconomic category for free LPG connection.'
              : 'Applicant must belong to poor household categories as per 14-point declaration.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Aadhaar card of adult woman applicant and all adult family members',
      'Ration card verifying family composition',
      'Bank passbook showing active account details',
    ],
    applicationProcess: [
      'Apply online at pmuy.gov.in or submit form at nearest LPG distributorship (Indane / Bharatgas / HP Gas)',
      'Field verification and instant biometric de-duplication check against OMC clearing database',
    ],
    officialUrl: 'https://www.pmuy.gov.in',
    lastUpdated: '09 March 2026',
  },

  // 23. National Fellowship for Persons with Disabilities (NFPwD)
  {
    id: 'nfpwd-fellowship',
    name: 'National Fellowship for Persons with Disabilities (NFPwD)',
    department: 'Department of Empowerment of Persons with Disabilities / UGC',
    category: 'Education',
    description:
      'Provides 200 fellowships every year to students with disabilities to pursue regular and full-time M.Phil. and Ph.D. degrees in Sciences, Humanities, and Engineering.',
    benefits: [
      'Junior Research Fellow (JRF): ₹31,000 per month for the first two years',
      'Senior Research Fellow (SRF): ₹35,000 per month for remaining tenure',
      'Contingency allowance up to ₹25,000 per annum and escorts/reader allowance of ₹2,000 per month',
    ],
    rules: [
      {
        id: 'pwd-fellowship-check',
        label: 'Certified Person with Disability',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.personWithDisability === 'Yes';
          return {
            satisfied: valid,
            reason: valid ? 'Candidate is certified as Divyangjan.' : 'Fellowship is restricted to students with disabilities.',
          };
        },
      },
      {
        id: 'research-education-level',
        label: 'Postgraduate or Doctoral (PhD) Level',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = ['Postgraduate', 'PhD'].includes(p.educationLevel);
          return {
            satisfied: valid,
            reason: valid
              ? `Education level (${p.educationLevel}) qualifies for higher research fellowship.`
              : `Must have completed Post-Graduation to pursue research fellowship. Current level: ${p.educationLevel || 'unspecified'}.`,
          };
        },
      },
      {
        id: 'active-student-check',
        label: 'Currently Enrolled Student',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.currentStudent === 'Yes';
          return {
            satisfied: valid,
            reason: valid ? 'Currently an active student.' : 'Must be registered for regular research degree.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Disability certificate (minimum 40%)',
      'Postgraduate degree mark sheets (minimum 55% marks)',
      'University admission / registration letter for M.Phil / Ph.D.',
    ],
    applicationProcess: [
      'Apply online on UGC Fellowship Portal during annual call for applications',
      'Merit-based selection prepared by expert committee',
    ],
    officialUrl: 'https://www.ugc.ac.in',
    lastUpdated: '10 January 2026',
  },

  // 24. Credit Linked Subsidy Scheme (CLSS) under PMAY
  {
    id: 'clss-housing-loan',
    name: 'Credit Linked Subsidy Scheme (CLSS) for Home Buyers',
    department: 'Ministry of Housing and Urban Affairs',
    category: 'Housing',
    description:
      'Provides interest subsidy on home loans taken by eligible urban poor and middle-income families for acquisition or construction of their first pucca house.',
    benefits: [
      'Upfront interest subsidy of 6.5% for EWS/LIG (up to ₹2.67 Lakhs upfront deduction from principal)',
      'Interest subsidy of 4% for MIG-I and 3% for MIG-II categories',
      'Significantly lowers monthly EMI repayment burden over 20-year loan tenure',
    ],
    rules: [
      {
        id: 'first-time-homebuyer',
        label: 'First-time Homebuyer (No existing pucca house)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.ownHouse === 'No';
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate does not own an existing pucca dwelling unit.'
              : 'Beneficiary family must not own a pucca house in their name anywhere in India.',
          };
        },
      },
      {
        id: 'income-clss',
        label: 'Income Eligibility (Up to ₹ 18 Lakhs)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const inc = parseIncome(p.familyIncome);
          const valid = inc > 0 && inc <= 1800000;
          return {
            satisfied: valid,
            reason: valid
              ? `Family income (₹ ${inc.toLocaleString('en-IN')}) qualifies across EWS/LIG/MIG interest subsidy slabs.`
              : 'Family income exceeds maximum CLSS eligibility ceiling of ₹18 Lakhs.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Aadhaar card of all family members',
      'Income tax returns / Form 16 / Salary slips / Income certificate',
      'Agreement to sale / construction estimate with developer/builder',
      'Affidavit confirming no prior pucca house ownership',
    ],
    applicationProcess: [
      'Apply through any primary lending institution (Scheduled Commercial Bank / Housing Finance Company)',
      'Lender uploads application to Central Nodal Agency (HUDCO / NHB) portal',
      'Subsidized amount directly credited into borrower’s loan account',
    ],
    officialUrl: 'https://pmayuclap.gov.in',
    lastUpdated: '18 July 2026',
  },

  // 25. Indira Gandhi National Old Age Pension Scheme (IGNOAPS)
  {
    id: 'ignoaps-old-age',
    name: 'Indira Gandhi National Old Age Pension Scheme (IGNOAPS)',
    department: 'Department of Rural Development, Ministry of Rural Development',
    category: 'Social Welfare',
    description:
      'Provides a monthly non-contributory social assistance pension to elderly citizens living in destitute economic conditions.',
    benefits: [
      'Direct monthly pension of ₹200 to ₹500 (central component) plus state top-up (totaling up to ₹1,000–₹3,000/month)',
      'Higher rate applicable for super-senior citizens aged 80 years and above',
    ],
    rules: [
      {
        id: 'senior-age',
        label: 'Senior Citizen Age (60+ Years)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const valid = age >= 60;
          return {
            satisfied: valid,
            reason: valid
              ? `Applicant age (${age} years) qualifies as senior citizen (60+).`
              : `Requires applicant to be at least 60 years of age. Current age: ${age || 0}.`,
          };
        },
      },
      {
        id: 'bpl-senior',
        label: 'BPL / Low Income Household',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const valid = p.bplRationCard === 'Yes' || parseIncome(p.familyIncome) <= 200000;
          return {
            satisfied: valid,
            reason: valid
              ? 'Candidate belongs to below poverty line or economically distressed household.'
              : 'Requires verified BPL household certification.',
          };
        },
      },
    ],
    requiredDocuments: [
      'Age proof (Aadhaar / Voter ID / Birth Certificate / School Leaving Certificate)',
      'BPL Card / Antyodaya Anna Yojana Card',
      'Aadhaar-seeded bank account passbook',
    ],
    applicationProcess: [
      'Submit form to local Gram Panchayat / Municipal Office or online via nsap.nic.in',
      'Field verification by revenue officials and inclusion in beneficiary payment roll',
    ],
    officialUrl: 'https://nsap.nic.in',
    lastUpdated: '12 January 2026',
  },
];
