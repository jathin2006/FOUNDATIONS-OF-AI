import { GovernmentScheme, ProfileData } from '../types';
import { parseIncome, parseAge } from './schemesDatabase';
import { isStateMatching } from '../utils/stateNormalizer';

/**
 * Official Verified Indian Government Schemes Dataset
 * Sourced from official portals: myScheme.gov.in, National Portal of India (india.gov.in),
 * DBT Bharat (dbtbharat.gov.in), and respective Union Ministries & State Departments.
 *
 * All criteria are structured to enable strict, deterministic rule evaluation.
 */
export const VERIFIED_OFFICIAL_SCHEMES: GovernmentScheme[] = [
  // ==========================================
  // CENTRAL GOVERNMENT SCHEMES
  // ==========================================
  {
    id: 'pm-kisan-central',
    name: 'PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)',
    schemeName: 'Pradhan Mantri Kisan Samman Nidhi',
    department: 'Department of Agriculture and Farmers Welfare',
    ministry: 'Ministry of Agriculture and Farmers Welfare',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Agriculture',
    subCategory: 'Direct Income Support',
    description:
      'Direct income support of ₹6,000 per annum in three equal 4-monthly installments directly into bank accounts of landholding agricultural farmer families.',
    shortDescription: 'Income support of ₹6,000/year to all landholding farmer families.',
    detailedDescription:
      'PM-KISAN is a Central Sector scheme with 100% funding from Government of India. The scheme provides income support to all landholding farmer families in the country to supplement their financial needs for procuring various agricultural inputs and domestic requirements.',
    benefits: [
      '₹6,000 per year transferred in 3 equal installments of ₹2,000 every 4 months',
      'Direct Benefit Transfer (DBT) directly into Aadhaar-seeded bank accounts',
      'Assistance for purchasing agricultural seeds, fertilizers, and equipment',
      'Free from any middlemen or physical paper collection for installment releases',
    ],
    farmerRequirement: true,
    landOwnershipRequirement: true,
    requiredDocuments: [
      'Citizenship Aadhaar Card (mandatory e-KYC)',
      'Land revenue ownership record (Khata / Khasra / RoR document)',
      'Aadhaar-seeded active bank savings account',
    ],
    applicationProcess: [
      'Self-registration on PM-KISAN portal (pmkisan.gov.in) or via Village Patwari / CSC',
      'Complete biometric or OTP-based Aadhaar e-KYC',
      'State revenue department verifies landholding against digital land records',
    ],
    applicationProcedure: [
      'Self-registration on PM-KISAN portal (pmkisan.gov.in) or via Village Patwari / CSC',
      'Complete biometric or OTP-based Aadhaar e-KYC',
      'State revenue department verifies landholding against digital land records',
    ],
    officialUrl: 'https://pmkisan.gov.in',
    officialWebsite: 'https://pmkisan.gov.in',
    officialApplicationUrl: 'https://pmkisan.gov.in/RegistrationFormNew.aspx',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/pm-kisan',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'pmay-gramin-urban-central',
    name: 'Pradhan Mantri Awas Yojana (PMAY)',
    schemeName: 'Pradhan Mantri Awas Yojana (PMAY - Urban & Gramin)',
    department: 'Ministry of Housing and Urban Affairs / Ministry of Rural Development',
    ministry: 'Ministry of Housing and Urban Affairs',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Housing',
    subCategory: 'Affordable Housing & Shelter',
    description:
      'Flagship mission providing central financial assistance to homeless families and households living in kutcha/dilapidated houses to build a pucca dwelling unit.',
    shortDescription: 'Financial grant up to ₹1,30,000 for constructing a pucca dwelling house.',
    detailedDescription:
      'PMAY aims to provide "Housing for All" by helping eligible homeless households and families living in unserviceable kutcha houses to build pucca houses with hygienic cooking spaces, power, and water connections.',
    benefits: [
      'Grant of ₹1,20,000 in plain areas and ₹1,30,000 in hilly/difficult/IAP districts',
      'Additional 90 to 95 days of unskilled labor wages under MGNREGS (approx. ₹20,000)',
      'Direct assistance of ₹12,000 for household sanitary latrine under Swachh Bharat Mission',
      'Interest subsidy under Credit Linked Subsidy Scheme (CLSS) for urban beneficiaries',
    ],
    familyIncomeLimit: 300000,
    bplRequirement: true,
    requiredDocuments: [
      'Aadhaar card of all adult family members',
      'Declaration of not owning a pucca residential house anywhere in India',
      'Ration card or BPL survey confirmation number',
      'Bank passbook linked with Aadhaar',
      'Land allotment certificate or Gram Panchayat title document',
    ],
    applicationProcess: [
      'Apply online via pmaymis.gov.in or nearest Common Service Centre (CSC)',
      'Local revenue survey and geo-tagging of construction plot',
      'Direct DBT credit across plinth, lintel, and roof completion stages',
    ],
    applicationProcedure: [
      'Apply online via pmaymis.gov.in or nearest Common Service Centre (CSC)',
      'Local revenue survey and geo-tagging of construction plot',
      'Direct DBT credit across plinth, lintel, and roof completion stages',
    ],
    officialUrl: 'https://pmaymis.gov.in',
    officialWebsite: 'https://pmaymis.gov.in',
    officialApplicationUrl: 'https://pmayg.nic.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/pmay-g',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'ayushman-bharat-pmjay',
    name: 'Ayushman Bharat - Pradhan Mantri Jan Arogya Yojana (PM-JAY)',
    schemeName: 'Ayushman Bharat PM-JAY',
    department: 'National Health Authority (NHA)',
    ministry: 'Ministry of Health and Family Welfare',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Health',
    subCategory: 'Universal Health Insurance',
    description:
      'The worlds largest health assurance scheme providing health cover of ₹5,00,000 per family per year for secondary and tertiary care hospitalization.',
    shortDescription: 'Cashless hospital treatment up to ₹5 Lakhs per family per year.',
    detailedDescription:
      'PM-JAY covers over 12 crore poor and vulnerable families (approximately 55 crore beneficiaries). It provides cashless and paperless access to services for the beneficiary at the point of service in any empanelled public or private hospital nationwide.',
    benefits: [
      'Cashless inpatient treatment coverage up to ₹5,00,000 per family per year',
      'Covers up to 3 days of pre-hospitalization and 15 days of post-hospitalization expenses',
      'Covers 1,949 medical procedures including surgeries, ICU, oncology, and cardiology',
      'No restriction on family size, age, or gender',
      'Valid across all 28,000+ empanelled hospitals in any state or UT of India',
    ],
    familyIncomeLimit: 250000,
    bplRequirement: true,
    requiredDocuments: [
      'Aadhaar card or Ration card',
      'SECC 2011 Household ID or PMJAY Family Verification Letter',
      'Active mobile number linked to Aadhaar',
    ],
    applicationProcess: [
      'Verify eligibility at beneficiary.nha.gov.in or through Ayushman Mitra at hospital',
      'Submit Aadhaar biometric e-KYC authentication',
      'Receive official plastic or digital Ayushman Card',
    ],
    applicationProcedure: [
      'Verify eligibility at beneficiary.nha.gov.in or through Ayushman Mitra at hospital',
      'Submit Aadhaar biometric e-KYC authentication',
      'Receive official plastic or digital Ayushman Card',
    ],
    officialUrl: 'https://pmjay.gov.in',
    officialWebsite: 'https://pmjay.gov.in',
    officialApplicationUrl: 'https://beneficiary.nha.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/ab-pmjay',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'pm-vishwakarma-central',
    name: 'PM Vishwakarma Scheme',
    schemeName: 'Pradhan Mantri Vishwakarma Kaushal Samman',
    department: 'Ministry of Micro, Small and Medium Enterprises',
    ministry: 'Ministry of Micro, Small and Medium Enterprises',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Employment',
    subCategory: 'Artisans & Craftsmen Welfare',
    description:
      'Holistic support scheme for traditional artisans and craftspeople working with hands and tools across 18 notified traditional trades.',
    shortDescription: 'Collateral-free enterprise credit up to ₹3,00,000 at 5% interest with toolkits.',
    detailedDescription:
      'PM Vishwakarma provides end-to-end support to traditional craftspeople (carpenters, blacksmiths, potters, cobblers, weavers, etc.) through skill upgradation, toolkit incentive of ₹15,000, collateral-free credit, and marketing support.',
    benefits: [
      'Collateral-free enterprise development loan: 1st tranche up to ₹1,00,000, 2nd tranche up to ₹2,00,000 at concessional 5% interest',
      'Skill training with stipend of ₹500 per day during basic & advanced training',
      'Modern Toolkit Incentive grant of ₹15,000 through digital e-vouchers',
      'Incentive for digital transactions (₹1 per transaction up to 100 transactions/month)',
      'Official PM Vishwakarma Certificate and ID Card recognition',
    ],
    minimumAge: 18,
    requiredDocuments: [
      'Aadhaar card with mobile linkage',
      'Bank passbook / account details',
      'Self-declaration of traditional trade practice',
      'Ration card or family details',
    ],
    applicationProcess: [
      'Biometric-based registration through Common Services Centres (CSC)',
      'Three-stage verification: Gram Panchayat / Urban Local Body, District Implementation Committee, Screening Committee',
      'Skill training enrollment and toolkit voucher issuance',
    ],
    applicationProcedure: [
      'Biometric-based registration through Common Services Centres (CSC)',
      'Three-stage verification: Gram Panchayat / Urban Local Body, District Implementation Committee, Screening Committee',
      'Skill training enrollment and toolkit voucher issuance',
    ],
    officialUrl: 'https://pmvishwakarma.gov.in',
    officialWebsite: 'https://pmvishwakarma.gov.in',
    officialApplicationUrl: 'https://pmvishwakarma.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/pm-vishwakarma',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'pm-svanidhi-central',
    name: 'PM SVANidhi (PM Street Vendors AtmaNirbhar Nidhi)',
    schemeName: 'PM SVANidhi',
    department: 'Ministry of Housing and Urban Affairs',
    ministry: 'Ministry of Housing and Urban Affairs',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Financial Assistance',
    subCategory: 'Urban Livelihood Credit',
    description:
      'Micro-credit scheme providing working capital loans to urban street vendors, hawkers, and peri-urban small merchants.',
    shortDescription: 'Collateral-free working capital loan up to ₹50,000 with 7% interest subsidy.',
    detailedDescription:
      'PM SVANidhi provides street vendors with formal institutional working capital loans starting with ₹10,000 (1st tranche), ₹20,000 (2nd tranche), and up to ₹50,000 (3rd tranche) with 7% interest subsidy on prompt repayments.',
    benefits: [
      'Initial working capital loan up to ₹10,000 without any collateral or security',
      'Enhanced loan limit up to ₹20,000 and ₹50,000 upon timely repayment',
      'Interest subsidy of 7% per annum credited quarterly directly to bank account',
      'Monthly cashback up to ₹100 on accepting digital payment QR transactions',
    ],
    minimumAge: 18,
    requiredDocuments: [
      'Aadhaar Card and active mobile number',
      'Vending Certificate / Identity Card issued by Urban Local Body or Recommendation Letter (LoR)',
      'Bank account details',
    ],
    applicationProcess: [
      'Apply online on pmsvanidhi.mohua.gov.in or through Banking Correspondent / CSC',
      'Select preferred lending institution or local bank branch',
      'Digital disbursement within 7 to 10 working days',
    ],
    applicationProcedure: [
      'Apply online on pmsvanidhi.mohua.gov.in or through Banking Correspondent / CSC',
      'Select preferred lending institution or local bank branch',
      'Digital disbursement within 7 to 10 working days',
    ],
    officialUrl: 'https://pmsvanidhi.mohua.gov.in',
    officialWebsite: 'https://pmsvanidhi.mohua.gov.in',
    officialApplicationUrl: 'https://pmsvanidhi.mohua.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/pm-svanidhi',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'pm-mudra-yojana-central',
    name: 'Pradhan Mantri Mudra Yojana (PMMY)',
    schemeName: 'Pradhan Mantri Mudra Yojana',
    department: 'Department of Financial Services',
    ministry: 'Ministry of Finance',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Financial Assistance',
    subCategory: 'Micro Enterprise Lending',
    description:
      'Provides collateral-free loans up to ₹20 Lakhs to non-corporate, non-farm small and micro enterprises across Shishu, Kishore, and Tarun categories.',
    shortDescription: 'Collateral-free business loans up to ₹20,00,000 for micro enterprises.',
    detailedDescription:
      'PMMY facilitates micro enterprise funding under three tiers: Shishu (loans up to ₹50,000), Kishore (loans ₹50,000 to ₹5 Lakhs), and Tarun / Tarun Plus (loans up to ₹20 Lakhs) with no collateral required.',
    benefits: [
      'Shishu tier: Collateral-free seed loans up to ₹50,000 for starting micro trades',
      'Kishore tier: Working capital and machinery loans up to ₹5,00,000',
      'Tarun tier: Expansion loans up to ₹10,00,000 to ₹20,00,000',
      'Zero processing fee for Shishu and Kishore loan categories in public sector banks',
      'MUDRA Debit Card provided for convenient working capital withdrawals',
    ],
    minimumAge: 18,
    maximumAge: 65,
    requiredDocuments: [
      'Aadhaar card / Voter ID for KYC verification',
      'Business address proof and trade registration/license if available',
      'Bank statement for previous 6 months',
      'Project quotation or business machinery cost estimation',
    ],
    applicationProcess: [
      'Apply online via udyamimitra.in or visit any scheduled commercial bank or NBFC',
      'Submit business proposal and machinery estimation',
      'Sanction and disbursement directly to supplier / business account',
    ],
    applicationProcedure: [
      'Apply online via udyamimitra.in or visit any scheduled commercial bank or NBFC',
      'Submit business proposal and machinery estimation',
      'Sanction and disbursement directly to supplier / business account',
    ],
    officialUrl: 'https://www.mudra.org.in',
    officialWebsite: 'https://www.mudra.org.in',
    officialApplicationUrl: 'https://udyamimitra.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/pmmy',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'sukanya-samriddhi-yojana-central',
    name: 'Sukanya Samriddhi Yojana (SSY)',
    schemeName: 'Sukanya Samriddhi Account',
    department: 'Department of Economic Affairs',
    ministry: 'Ministry of Finance / Ministry of Women and Child Development',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Women & Child Development',
    subCategory: 'Girl Child Small Savings',
    description:
      'Government-backed small deposit scheme designed exclusively for the girl child under the Beti Bachao Beti Padhao campaign offering highest government interest rates and triple tax exemptions.',
    shortDescription: 'High-interest tax-free savings account for girl children below 10 years of age.',
    detailedDescription:
      'Sukanya Samriddhi Yojana offers sovereign-guaranteed compounding interest (currently 8.2% p.a.) with complete tax exemption on deposits, accrued interest, and maturity under Section 80C and EEE tax status.',
    benefits: [
      'Highest sovereign interest rate among all small savings schemes (8.2% per annum compounding)',
      'Triple Tax Exemption: Tax deduction on deposits up to ₹1.5 Lakhs under 80C, tax-free interest, tax-free maturity',
      'Partial withdrawal up to 50% permitted after child reaches 18 years for higher education',
      'Account matures 21 years from opening date or upon marriage after age 18',
    ],
    gender: ['Female'],
    maximumAge: 10,
    requiredDocuments: [
      'Birth certificate of the girl child',
      'Aadhaar card of parent or legal guardian',
      'Photograph of child and parent',
      'Proof of residence (Electricity bill / Ration card)',
    ],
    applicationProcess: [
      'Visit any post office or authorized commercial bank branch',
      'Fill Form-1 with initial deposit (minimum ₹250)',
      'Receive official SSY passbook with registered account number',
    ],
    applicationProcedure: [
      'Visit any post office or authorized commercial bank branch',
      'Fill Form-1 with initial deposit (minimum ₹250)',
      'Receive official SSY passbook with registered account number',
    ],
    officialUrl: 'https://www.indiapost.gov.in',
    officialWebsite: 'https://www.indiapost.gov.in',
    officialApplicationUrl: 'https://www.indiapost.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/ssy',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'atal-pension-yojana-central',
    name: 'Atal Pension Yojana (APY)',
    schemeName: 'Atal Pension Yojana',
    department: 'Pension Fund Regulatory and Development Authority (PFRDA)',
    ministry: 'Ministry of Finance',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Pension & Senior Citizen',
    subCategory: 'Guaranteed Social Security',
    description:
      'Universal guaranteed pension scheme primarily focused on unorganized sector workers, providing fixed monthly pension of ₹1,000 to ₹5,000 after 60 years of age.',
    shortDescription: 'Guaranteed lifetime monthly pension of ₹1,000 to ₹5,000 after age 60.',
    detailedDescription:
      'APY is administered by PFRDA and provides a government-guaranteed minimum monthly pension to subscribers from age 60 until death, followed by lifetime pension to spouse, and return of full corpus to the nominee.',
    benefits: [
      'Guaranteed monthly pension of ₹1,000, ₹2,000, ₹3,000, ₹4,000, or ₹5,000 from age 60',
      'Spouse receives identical monthly pension for life upon demise of subscriber',
      'Accumulated corpus transferred to legal nominee upon demise of both subscriber and spouse',
      'Tax benefits under Section 80CCD of Income Tax Act',
    ],
    minimumAge: 18,
    maximumAge: 40,
    requiredDocuments: [
      'Aadhaar card with active mobile linkage',
      'Savings bank account or post office savings account',
      'Nominee details',
    ],
    applicationProcess: [
      'Enroll through internet banking or by visiting your savings bank branch',
      'Set auto-debit consent for monthly / quarterly contribution',
      'Receive Permanent Retirement Account Number (PRAN) acknowledgment',
    ],
    applicationProcedure: [
      'Enroll through internet banking or by visiting your savings bank branch',
      'Set auto-debit consent for monthly / quarterly contribution',
      'Receive Permanent Retirement Account Number (PRAN) acknowledgment',
    ],
    officialUrl: 'https://www.pfrda.org.in',
    officialWebsite: 'https://www.npscra.nsdl.co.in',
    officialApplicationUrl: 'https://enps.nsdl.com',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/apy',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'nmmss-education-central',
    name: 'National Means-cum-Merit Scholarship Scheme (NMMSS)',
    schemeName: 'National Means-cum-Merit Scholarship Scheme',
    department: 'Department of School Education and Literacy',
    ministry: 'Ministry of Education',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Education',
    subCategory: 'Merit-cum-Means School Scholarship',
    description:
      'Provides scholarship of ₹12,000 per annum to meritorious students from economically weaker sections to arrest dropout at Class 8 and encourage secondary education.',
    shortDescription: '₹12,000 annual scholarship for students studying in Class 9 to 12.',
    detailedDescription:
      'NMMSS awards 1,00,000 fresh scholarships every year to Class 9 students who passed the state-level selection examination, continuing through Class 10, 11, and 12 in state, government-aided, or local body schools.',
    benefits: [
      '₹12,000 per year (₹1,000 per month) credited directly via DBT through Public Financial Management System (PFMS)',
      'Covers secondary schooling expenses across 4 consecutive academic years (Classes 9 to 12)',
      'Recognizes and fosters high academic talent among underprivileged students',
    ],
    studentRequirement: true,
    familyIncomeLimit: 350000,
    minimumAge: 12,
    maximumAge: 18,
    requiredDocuments: [
      'Aadhaar card of student',
      'Class 7 and 8 mark sheet with minimum 55% marks (50% for SC/ST)',
      'Parental annual income certificate issued by competent authority',
      'Caste certificate for reserved categories',
      'Bank passbook photocopy showing account in student name',
    ],
    applicationProcess: [
      'Apply online on National Scholarship Portal (scholarships.gov.in)',
      'Appear for State Level NMMS Competitive Examination (MAT and SAT tests)',
      'Selected merit candidates complete institutional level verification on NSP',
    ],
    applicationProcedure: [
      'Apply online on National Scholarship Portal (scholarships.gov.in)',
      'Appear for State Level NMMS Competitive Examination (MAT and SAT tests)',
      'Selected merit candidates complete institutional level verification on NSP',
    ],
    officialUrl: 'https://scholarships.gov.in',
    officialWebsite: 'https://dsel.education.gov.in',
    officialApplicationUrl: 'https://scholarships.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/nmmss',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'pm-ujjwala-yojana-central',
    name: 'Pradhan Mantri Ujjwala Yojana (PMUY 2.0)',
    schemeName: 'Pradhan Mantri Ujjwala Yojana',
    department: 'Ministry of Petroleum and Natural Gas',
    ministry: 'Ministry of Petroleum and Natural Gas',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Social Welfare',
    subCategory: 'Clean Cooking Fuel & Health',
    description:
      'Provides deposit-free LPG connections to adult women from poor households, including first refill and stove free of cost.',
    shortDescription: 'Free deposit-free LPG cooking gas connection and first refill for poor women.',
    detailedDescription:
      'PMUY 2.0 provides clean cooking fuel to rural and deprived households to replace unhealthy biomass fuels. The connection is released in the name of an adult woman member of the household with complete deposit waiver.',
    benefits: [
      'Free LPG cylinder connection with security deposit fully paid by central government',
      'Free first 14.2 kg LPG refill and hotplate/gas stove provided at zero cost',
      'Targeted LPG subsidy of ₹300 per cylinder credited directly via DBT for up to 12 refills per year',
      'Protects women and children from respiratory diseases caused by indoor smoke',
    ],
    gender: ['Female'],
    minimumAge: 18,
    bplRequirement: true,
    requiredDocuments: [
      'Aadhaar card of adult woman applicant and all adult family members',
      'Ration card showing family composition or 14-point declaration',
      'Bank account number with IFSC linked to Aadhaar',
    ],
    applicationProcess: [
      'Apply online on pmuy.gov.in or submit Form-1 at nearest LPG distributor (Indane, Bharatgas, HP Gas)',
      'De-duplication check through OMC centralized portal',
      'Delivery of LPG connection and safety kit at home',
    ],
    applicationProcedure: [
      'Apply online on pmuy.gov.in or submit Form-1 at nearest LPG distributor (Indane, Bharatgas, HP Gas)',
      'De-duplication check through OMC centralized portal',
      'Delivery of LPG connection and safety kit at home',
    ],
    officialUrl: 'https://www.pmuy.gov.in',
    officialWebsite: 'https://www.pmuy.gov.in',
    officialApplicationUrl: 'https://www.pmuy.gov.in/ujwalamobile.aspx',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/pmuy',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'pm-fasal-bima-yojana-central',
    name: 'Pradhan Mantri Fasal Bima Yojana (PMFBY)',
    schemeName: 'Pradhan Mantri Fasal Bima Yojana',
    department: 'Department of Agriculture and Farmers Welfare',
    ministry: 'Ministry of Agriculture and Farmers Welfare',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Agriculture',
    subCategory: 'Crop Loss Insurance',
    description:
      'Comprehensive crop insurance scheme providing financial support to farmers suffering crop loss or damage due to unforeseen natural calamities.',
    shortDescription: 'Comprehensive crop insurance against natural calamities at lowest farmer premium of 1.5% to 2%.',
    detailedDescription:
      'PMFBY provides comprehensive insurance coverage against non-preventable natural risks from pre-sowing to post-harvest. Farmers pay a nominal premium: 2% for Kharif crops, 1.5% for Rabi crops, and 5% for annual commercial/horticultural crops.',
    benefits: [
      'Full insured sum paid for crop loss due to drought, flood, hailstorm, cyclone, or unseasonal rains',
      'Nominal premium: only 1.5% for Rabi and 2% for Kharif crops; remaining premium shared equally by Central & State govts',
      'Post-harvest loss coverage up to 14 days for unseasonal storms and cyclones',
      'Mid-season adversity relief: 25% immediate relief upon recognized localized calamity',
    ],
    farmerRequirement: true,
    requiredDocuments: [
      'Aadhaar card of farmer',
      'Land Record Document (Khasra / Khatauni / Jamabandi)',
      'Sowing Certificate / declaration issued by local revenue/panchayat officer',
      'Bank passbook linked to Aadhaar',
    ],
    applicationProcess: [
      'Enroll via National Crop Insurance Portal (pmfby.gov.in), bank branch, or nearest CSC before cutoff date',
      'Pay subsidized farmer premium share',
      'Report any localized crop loss within 72 hours via Crop Insurance App',
    ],
    applicationProcedure: [
      'Enroll via National Crop Insurance Portal (pmfby.gov.in), bank branch, or nearest CSC before cutoff date',
      'Pay subsidized farmer premium share',
      'Report any localized crop loss within 72 hours via Crop Insurance App',
    ],
    officialUrl: 'https://pmfby.gov.in',
    officialWebsite: 'https://pmfby.gov.in',
    officialApplicationUrl: 'https://pmfby.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/pmfby',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'pm-gkay-food-security-central',
    name: 'Pradhan Mantri Garib Kalyan Anna Yojana (PMGKAY)',
    schemeName: 'Pradhan Mantri Garib Kalyan Anna Yojana',
    department: 'Department of Food and Public Distribution',
    ministry: 'Ministry of Consumer Affairs, Food and Public Distribution',
    governmentLevel: 'Central',
    state: 'All',
    category: 'Social Welfare',
    subCategory: 'National Food Security',
    description:
      'Free distribution of 5 kg foodgrains per person per month to over 81 crore poor citizens under the National Food Security Act (NFSA).',
    shortDescription: 'Free 5 kg foodgrains (rice/wheat) per month per beneficiary under NFSA.',
    detailedDescription:
      'Government of India provides 100% free foodgrains under PMGKAY to all Antyodaya Anna Yojana (AAY) and Priority Household (PHH) ration card holders across all States and Union Territories.',
    benefits: [
      '5 kg of free rice or wheat per person per month for Priority Households',
      '35 kg of free foodgrains per family per month for Antyodaya (poorest of the poor) families',
      'Zero cost: complete waiver of central issue prices for foodgrains',
      'Nationwide portability via One Nation One Ration Card (ONORC) using Aadhaar biometric authentication',
    ],
    bplRequirement: true,
    rationCardRequirement: true,
    requiredDocuments: [
      'National Food Security Act (NFSA) / Priority Ration Card',
      'Aadhaar card of beneficiary family members (biometric e-PoS verification)',
    ],
    applicationProcess: [
      'Visit any Fair Price Shop (ration shop) across India',
      'Authenticate identity on e-PoS machine via fingerprint or iris scan',
      'Collect free monthly grain entitlement',
    ],
    applicationProcedure: [
      'Visit any Fair Price Shop (ration shop) across India',
      'Authenticate identity on e-PoS machine via fingerprint or iris scan',
      'Collect free monthly grain entitlement',
    ],
    officialUrl: 'https://dfpd.gov.in',
    officialWebsite: 'https://nfsa.gov.in',
    officialApplicationUrl: 'https://nfsa.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/pmgkay',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  // ==========================================
  // MAJOR STATE GOVERNMENT SCHEMES
  // ==========================================
  // --- 1. TAMIL NADU STATE SCHEMES (12 Verified Schemes) ---
  // (a) Potentially Eligible Schemes for 19yo Student (3)
  {
    id: 'tn-naan-mudhalvan-skill-state',
    name: 'Tamil Nadu Naan Mudhalvan Scheme (Higher Education Skill & Employability)',
    schemeName: 'Naan Mudhalvan Scheme',
    department: 'Tamil Nadu Skill Development Corporation (TNSDC)',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Skill Development',
    subCategory: 'Industry 4.0 & Technical Employability Skills',
    description:
      'Massive flagship skilling initiative of Tamil Nadu providing free domain-specific technical, IT, and industry certifications to all enrolled college students.',
    shortDescription: 'Free domain training and global industry certification for college students in Tamil Nadu.',
    detailedDescription:
      'Naan Mudhalvan equips engineering, arts, science, and polytechnic college students with industry-curated curriculums, foreign language proficiencies, and direct placement drives across Tamil Nadu.',
    benefits: [
      'Free specialized courses in AI, Data Analytics, Cloud Computing, VLSI, and Core Engineering',
      'Mandatory credited curriculum embedded directly within university semester schedules',
      'Direct campus placement drives and global corporate internships for pre-final and final year students',
    ],
    gender: 'All',
    minimumAge: 17,
    maximumAge: 28,
    studentRequirement: true,
    requiredDocuments: [
      'College Bonafide Certificate or Student Identity Card',
      'Aadhaar card of candidate',
      'University Enrollment Registration Number',
    ],
    applicationProcess: [
      'College coordinates registration on the official Naan Mudhalvan portal (naanmudhalvan.tn.gov.in)',
      'Students enroll in accredited track courses approved by university board of studies',
      'Assessment and certification conducted at college computer centers',
    ],
    applicationProcedure: [
      'College coordinates registration on the official Naan Mudhalvan portal (naanmudhalvan.tn.gov.in)',
      'Students enroll in accredited track courses approved by university board of studies',
      'Assessment and certification conducted at college computer centers',
    ],
    officialUrl: 'https://naanmudhalvan.tn.gov.in',
    officialWebsite: 'https://naanmudhalvan.tn.gov.in',
    officialApplicationUrl: 'https://naanmudhalvan.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/naan-mudhalvan',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-student-status',
        label: 'College / Technical Student Enrollment',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = p.currentStudent === 'Yes' || p.employmentStatus === 'Student';
          return {
            satisfied: ok,
            reason: ok ? 'Applicant is actively enrolled as a college student.' : 'Applicant must be an active college student.',
          };
        },
      },
      {
        id: 'tn-age-bracket',
        label: 'Youth Age Bracket (17 to 28 years)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const ok = age >= 17 && age <= 28;
          return {
            satisfied: ok,
            reason: ok ? `Age (${age} years) is within eligible 17-28 range.` : 'Requires age between 17 and 28 years.',
          };
        },
      },
    ],
  },

  {
    id: 'tn-free-education-higher-edu-state',
    name: 'Tamil Nadu Free Higher Education Assistance Scheme (BC/MBC/DNC Welfare)',
    schemeName: 'Free Higher Education Scheme',
    department: 'Backward Classes, Most Backward Classes and Minorities Welfare Department',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Education',
    subCategory: 'Degree Tuition Fee Exemption',
    description:
      'Provides full tuition fee exemption and educational allowances to eligible students pursuing three-year undergraduate degree courses in Government and Aided Arts and Science colleges in Tamil Nadu.',
    shortDescription: 'Full tuition fee waiver for degree students in Tamil Nadu Govt & Aided Colleges.',
    detailedDescription:
      'Covers tuition fees, special lab fees, and examination charges directly disbursed to colleges on behalf of eligible degree candidates whose family income does not exceed ₹2.5 Lakhs.',
    benefits: [
      'Complete tuition fee exemption for 3-year undergraduate degree courses (BA, BSc, BCom, etc.)',
      'Free hostel boarding facilities in departmental college hostels',
      'Direct institutional reimbursement without student out-of-pocket tuition costs',
    ],
    minimumAge: 17,
    maximumAge: 25,
    familyIncomeLimit: 250000,
    studentRequirement: true,
    requiredDocuments: [
      'College admission fee receipt and Bonafide Certificate',
      'Income Certificate issued by Revenue Authority (under ₹2.5 Lakhs)',
      'Community Certificate or declaration copy',
      'Aadhaar card and student bank passbook',
    ],
    applicationProcess: [
      'Obtain application from college principal / scholarship nodal office',
      'College forwards verified list of candidates to District Backward Classes Welfare Officer',
      'Tuition fee reimbursement directly sanctioned to institution',
    ],
    applicationProcedure: [
      'Obtain application from college principal / scholarship nodal office',
      'College forwards verified list of candidates to District Backward Classes Welfare Officer',
      'Tuition fee reimbursement directly sanctioned to institution',
    ],
    officialUrl: 'https://bcmbcmw.tn.gov.in',
    officialWebsite: 'https://bcmbcmw.tn.gov.in',
    officialApplicationUrl: 'https://bcmbcmw.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/tn-free-education-higher-secondary',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-degree-level',
        label: 'Undergraduate Higher Education Enrollment',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = ['Undergraduate', 'Diploma', 'Higher Secondary'].includes(p.educationLevel) || p.currentStudent === 'Yes';
          return {
            satisfied: ok,
            reason: ok ? 'Pursuing eligible undergraduate higher education.' : 'Must be enrolled in college degree or diploma program.',
          };
        },
      },
      {
        id: 'tn-income-limit',
        label: 'Family Annual Income Limit (₹2,50,000)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const inc = parseIncome(p.familyIncome);
          const ok = inc <= 250000;
          return {
            satisfied: ok,
            reason: ok ? `Family income (₹${inc.toLocaleString('en-IN')}) is within ₹2,50,000 ceiling.` : 'Family annual income exceeds limit of ₹2,50,000.',
          };
        },
      },
    ],
  },

  {
    id: 'tn-cm-digital-learning-laptop-state',
    name: 'Tamil Nadu Chief Minister Digital Learning & Student Tool Assistance Scheme',
    schemeName: 'Student Digital Learning Assistance Scheme',
    department: 'Department of Higher Education',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Education',
    subCategory: 'Digital Empowerment Tools',
    description:
      'Equips students studying in Government and Government-aided colleges, polytechnics, and higher secondary schools with modern digital learning equipment and study grants.',
    shortDescription: 'Free digital learning tools and technical devices for college students in Tamil Nadu.',
    detailedDescription:
      'A pioneering welfare program designed to bridge the digital divide for youth in Tamil Nadu, facilitating online research, software learning, programming, and entrance examination preparations.',
    benefits: [
      'Pre-loaded educational software and operating systems geared for higher studies',
      'Free access to state digital library portals and e-learning lectures',
      'Comprehensive warranty support and institutional maintenance',
    ],
    minimumAge: 16,
    maximumAge: 24,
    studentRequirement: true,
    requiredDocuments: [
      'College bonafide identity card and enrollment register copy',
      'Aadhaar card of student',
      'School leaving certificate confirming Tamil Nadu residency',
    ],
    applicationProcess: [
      'Institutions compile verified eligible student lists from academic registers',
      'District educational officers authorize distribution schedules',
      'Devices issued directly to students at institutional assembly ceremonies',
    ],
    applicationProcedure: [
      'Institutions compile verified eligible student lists from academic registers',
      'District educational officers authorize distribution schedules',
      'Devices issued directly to students at institutional assembly ceremonies',
    ],
    officialUrl: 'https://tnhighereducation.tn.gov.in',
    officialWebsite: 'https://tnhighereducation.tn.gov.in',
    officialApplicationUrl: 'https://tnhighereducation.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/tn-free-laptop',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-student-age',
        label: 'Youth & Student Age Bracket (16 to 24 years)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const ok = age >= 16 && age <= 24;
          return {
            satisfied: ok,
            reason: ok ? `Age (${age} years) qualifies for student digital learning tools.` : 'Requires age between 16 and 24 years.',
          };
        },
      },
      {
        id: 'tn-active-student',
        label: 'Active Student Enrollment Verification',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = p.currentStudent === 'Yes' || p.employmentStatus === 'Student';
          return {
            satisfied: ok,
            reason: ok ? 'Applicant verified as an active student.' : 'Must be actively studying in school or college.',
          };
        },
      },
    ],
  },

  // (b) Partial Match Schemes (5)
  {
    id: 'tn-tansim-student-preincubation-state',
    name: 'Tamil Nadu Startup & Innovation Mission (TANSIM) Student Pre-Incubation Grant',
    schemeName: 'TANSIM Student Innovation Grant',
    department: 'Micro, Small and Medium Enterprises Department',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Financial Assistance',
    subCategory: 'Student Entrepreneurship & Prototype Seed Fund',
    description:
      'Provides prototype seed grants of up to ₹1,00,000 for student innovators and aspiring college entrepreneurs in Tamil Nadu with priority for underserved communities.',
    shortDescription: 'Up to ₹1,00,000 prototype funding for student innovators in Tamil Nadu.',
    detailedDescription:
      'Managed by StartupTN to foster grassroots student innovations across state colleges. Prioritizes student groups with registered BPL cardholder family members or EDII-TN innovation cell registration.',
    benefits: [
      'Non-refundable seed grant up to ₹1,00,000 for prototype fabrication',
      'Free incubation workspace and cloud infrastructure vouchers',
      'Mentorship from Tamil Nadu angel investor network and industrial experts',
    ],
    minimumAge: 18,
    maximumAge: 30,
    requiredDocuments: [
      'Project proposal and mentor endorsement letter',
      'Student Aadhaar and institutional identity card',
      'Priority BPL/Antyodaya Ration Card (if claiming priority subsidy quota)',
    ],
    applicationProcess: [
      'Submit prototype pitch online via StartupTN portal (startuptn.in)',
      'Regional Hub evaluation committee conducts pitch screening',
      'Direct grant disbursement to project nodal bank account',
    ],
    applicationProcedure: [
      'Submit prototype pitch online via StartupTN portal (startuptn.in)',
      'Regional Hub evaluation committee conducts pitch screening',
      'Direct grant disbursement to project nodal bank account',
    ],
    officialUrl: 'https://startuptn.in',
    officialWebsite: 'https://startuptn.in',
    officialApplicationUrl: 'https://startuptn.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/tansim-grant',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-age-limit',
        label: 'Age Bracket (18 to 30 years)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const ok = age >= 18 && age <= 30;
          return {
            satisfied: ok,
            reason: ok ? `Age (${age} years) is within eligible startup bracket.` : 'Requires age 18 to 30 years.',
          };
        },
      },
      {
        id: 'tn-bpl-preference',
        label: 'Secondary Priority: Antyodaya / BPL Priority Ration Card',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const ok = p.bplRationCard === 'Yes';
          return {
            satisfied: ok,
            reason: ok ? 'Holds active BPL / Priority Ration Card.' : 'Secondary priority criteria: BPL / Antyodaya card not verified in profile.',
          };
        },
      },
    ],
  },

  {
    id: 'tn-cm-youth-skill-voucher-state',
    name: 'Tamil Nadu CM Youth Skill Training & Placement Voucher Scheme',
    schemeName: 'CM Youth Skill Voucher Scheme',
    department: 'Department of Labour Welfare and Skill Development',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Employment',
    subCategory: 'Vocational Placement Assistance',
    description:
      'Provides skill development vouchers and stipend support for youth in Tamil Nadu with special priority given to registered job seekers in employment exchanges.',
    shortDescription: 'Vocational training vouchers and monthly stipend for youth in Tamil Nadu.',
    detailedDescription:
      'Designed to upskill youth in high-demand industrial sectors. Preference and fast-track admission are given to registered unemployed candidates on district employment exchange registers.',
    benefits: [
      'Course voucher up to ₹15,000 for certified technical training modules',
      'Monthly training conveyance allowance of ₹1,000 during instruction',
      'Assured interview placement drives with leading industrial partners in Tamil Nadu',
    ],
    minimumAge: 18,
    maximumAge: 35,
    requiredDocuments: [
      'Aadhaar card and residence proof in Tamil Nadu',
      'Educational certificates (10th/12th/ITI/Diploma/Degree)',
      'Employment Exchange Registration Card (if registered)',
    ],
    applicationProcess: [
      'Register on Tamil Nadu Skill Development portal (tnskill.tn.gov.in)',
      'Select empanelled training partner and course voucher track',
      'Attend mandatory bio-metric attendance training sessions',
    ],
    applicationProcedure: [
      'Register on Tamil Nadu Skill Development portal (tnskill.tn.gov.in)',
      'Select empanelled training partner and course voucher track',
      'Attend mandatory bio-metric attendance training sessions',
    ],
    officialUrl: 'https://tnskill.tn.gov.in',
    officialWebsite: 'https://tnskill.tn.gov.in',
    officialApplicationUrl: 'https://tnskill.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/tn-skill-voucher',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-age-youth',
        label: 'Youth Age Bracket (18 to 35 years)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const ok = age >= 18 && age <= 35;
          return {
            satisfied: ok,
            reason: ok ? `Age (${age} years) qualifies for skill development voucher.` : 'Requires age 18 to 35 years.',
          };
        },
      },
      {
        id: 'tn-employment-status-pref',
        label: 'Secondary Preference: Registered Job Seeker / Employment Exchange ID',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const ok = p.employmentStatus === 'Unemployed';
          return {
            satisfied: ok,
            reason: ok ? 'Applicant is registered as unemployed job seeker.' : 'Preference for registered unemployed job seekers (Applicant current status: Student).',
          };
        },
      },
    ],
  },

  {
    id: 'tn-tabcedco-education-loan-subsidy-state',
    name: 'Tamil Nadu Backward Classes Development Corporation (TABCEDCO) Youth Education Loan Subsidy',
    schemeName: 'TABCEDCO Education Loan Scheme',
    department: 'Tamil Nadu Backward Classes Economic Development Corporation',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Financial Assistance',
    subCategory: 'Concessional Educational Loans',
    description:
      'Provides educational loans at a concessional interest rate of 4% per annum for professional courses with reservation priority for backward and most backward categories.',
    shortDescription: 'Concessional 4% educational loan for professional degrees in Tamil Nadu.',
    detailedDescription:
      'Sanctions loans up to ₹5,00,000 for undergraduate engineering, medical, law, and management courses in recognized universities. Open to all students with priority quota for notified backward communities.',
    benefits: [
      'Concessional interest rate of only 4% per annum (significantly below commercial bank rates)',
      'Loan moratorium during duration of course plus 6 months post-completion',
      'No collateral requirement for loans up to ₹2,50,000 with government guarantee',
    ],
    minimumAge: 17,
    maximumAge: 30,
    studentRequirement: true,
    requiredDocuments: [
      'Admission allotment order and approved fee structure from university',
      'Community Certificate (if applying under priority quota)',
      'Income certificate and Aadhaar card of parent and student',
    ],
    applicationProcess: [
      'Apply online through TABCEDCO portal (tabcedco.tn.gov.in) or via District BC Welfare Office',
      'Joint scrutiny by district screening committee and participating cooperative banks',
      'Sanction letter issued and loan amount credited directly to educational institution',
    ],
    applicationProcedure: [
      'Apply online through TABCEDCO portal (tabcedco.tn.gov.in) or via District BC Welfare Office',
      'Joint scrutiny by district screening committee and participating cooperative banks',
      'Sanction letter issued and loan amount credited directly to educational institution',
    ],
    officialUrl: 'https://tabcedco.tn.gov.in',
    officialWebsite: 'https://tabcedco.tn.gov.in',
    officialApplicationUrl: 'https://tabcedco.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/tabcedco-loan',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-student-enrolled',
        label: 'Higher Education Degree Enrollment',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = ['Undergraduate', 'Postgraduate', 'Diploma'].includes(p.educationLevel) || p.currentStudent === 'Yes';
          return {
            satisfied: ok,
            reason: ok ? 'Enrolled in eligible higher educational course.' : 'Must be enrolled in college education.',
          };
        },
      },
      {
        id: 'tn-tabcedco-community-pref',
        label: 'Target Community Quota (BC / MBC / DNC Social Category)',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const ok = ['OBC', 'SC', 'ST'].includes(p.casteCategory) || p.minorityCommunity === 'Yes';
          return {
            satisfied: ok,
            reason: ok ? 'Belongs to notified BC/MBC/DNC welfare group.' : 'Open category applicant (Secondary quota priority for BC/MBC/DNC applicants).',
          };
        },
      },
    ],
  },

  {
    id: 'tn-unorganized-workers-edu-assistance-state',
    name: 'Tamil Nadu Unorganized Workers Welfare Board Educational Assistance for Wards',
    schemeName: 'Unorganized Workers Educational Assistance',
    department: 'Tamil Nadu Labour Welfare Board',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Social Welfare',
    subCategory: 'Worker Wards Educational Scholarship',
    description:
      'Provides annual educational scholarship of ₹3,000 to ₹12,000 for children of workers pursuing ITI, Polytechnic, General Degree, and Professional degree courses.',
    shortDescription: 'Annual educational scholarship up to ₹12,000 for worker children in Tamil Nadu.',
    detailedDescription:
      'Supports education of wards of registered manual workers, construction laborers, transport drivers, and daily wage earners registered under 17 Tamil Nadu Unorganized Workers Welfare Boards.',
    benefits: [
      'General Degree students: ₹3,000 per annum',
      'Postgraduate & Professional Engineering/Medical students: up to ₹12,000 per annum',
      'Free book allowances and hostel stay allowances',
    ],
    minimumAge: 16,
    maximumAge: 25,
    studentRequirement: true,
    requiredDocuments: [
      'Labour Welfare Board registration identity card / subscription renewal passbook',
      'College Bonafide certificate indicating academic year of study',
      'Aadhaar card and bank account details of student',
    ],
    applicationProcess: [
      'Submit application through official Tamil Nadu Labour Welfare portal (tnuwwb.tn.gov.in)',
      'Verification by Labour Inspector / Village Administrative Officer',
      'Grant sanctioned and credited directly to student bank account',
    ],
    applicationProcedure: [
      'Submit application through official Tamil Nadu Labour Welfare portal (tnuwwb.tn.gov.in)',
      'Verification by Labour Inspector / Village Administrative Officer',
      'Grant sanctioned and credited directly to student bank account',
    ],
    officialUrl: 'https://tnuwwb.tn.gov.in',
    officialWebsite: 'https://tnuwwb.tn.gov.in',
    officialApplicationUrl: 'https://tnuwwb.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/tn-workers-ward-scholarship',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-age-bracket',
        label: 'Eligible Youth Age (16 to 25 years)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const ok = age >= 16 && age <= 25;
          return {
            satisfied: ok,
            reason: ok ? `Age (${age} years) is within student scholarship eligibility.` : 'Requires age 16 to 25 years.',
          };
        },
      },
      {
        id: 'tn-labour-board-pref',
        label: 'Secondary Criterion: Registered Welfare Board Member Passbook',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const ok = p.employmentStatus === 'Daily Wage Worker' || Boolean(p.occupation && p.occupation.toLowerCase().includes('worker'));
          return {
            satisfied: ok,
            reason: ok ? 'Parent or applicant registered with Tamil Nadu unorganized workers board.' : 'Requires secondary verification of unorganized worker board membership.',
          };
        },
      },
    ],
  },

  {
    id: 'tn-cm-fellowship-public-policy-state',
    name: 'Tamil Nadu Chief Minister Research & Public Policy Fellowship (CMFP)',
    schemeName: 'Chief Minister Fellowship Programme (CMFP)',
    department: 'Special Programme Implementation Department',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Education',
    subCategory: 'Academic Research & Governance Fellowships',
    description:
      'Two-year fellowship offering a monthly stipend of ₹65,000 to passionate young professionals to work with state departments on governance delivery and policy innovations.',
    shortDescription: 'Monthly stipend of ₹65,000 for young fellows in Tamil Nadu policy research.',
    detailedDescription:
      'In partnership with Bharathidasan Institute of Management (BIM) Trichy, the CMFP monitors welfare schemes, identifies implementation bottlenecks, and formulates service improvements.',
    benefits: [
      'Monthly stipend of ₹65,000 plus ₹10,000 monthly travel and research allowance',
      'PG Diploma in Public Policy awarded by Bharathidasan Institute of Management',
      'Direct interaction and policy mentoring with senior IAS officers and ministers',
    ],
    minimumAge: 18,
    maximumAge: 32,
    requiredDocuments: [
      'Degree certificates and academic transcripts',
      'Aadhaar card and residency proof of Tamil Nadu',
      'Statement of Purpose and published research works (if available)',
    ],
    applicationProcess: [
      'Register for CMFP Entrance Examination online (cmfp.tn.gov.in)',
      'Stage 1: Online computer-based comprehensive aptitude test',
      'Stage 2: Personal interview and case study evaluation at Chennai',
    ],
    applicationProcedure: [
      'Register for CMFP Entrance Examination online (cmfp.tn.gov.in)',
      'Stage 1: Online computer-based comprehensive aptitude test',
      'Stage 2: Personal interview and case study evaluation at Chennai',
    ],
    officialUrl: 'https://cmfp.tn.gov.in',
    officialWebsite: 'https://cmfp.tn.gov.in',
    officialApplicationUrl: 'https://cmfp.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/cmfp-tamil-nadu',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-candidate-age',
        label: 'Candidate Age (18 to 32 years)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const ok = age >= 18 && age <= 32;
          return {
            satisfied: ok,
            reason: ok ? `Age (${age} years) qualifies for fellowship program.` : 'Requires age between 18 and 32 years.',
          };
        },
      },
      {
        id: 'tn-postgrad-pref',
        label: 'Secondary Qualification Preference: Completed Postgraduate Degree',
        isMandatory: false,
        evaluate: (p: ProfileData) => {
          const ok = ['Postgraduate', 'PhD'].includes(p.educationLevel);
          return {
            satisfied: ok,
            reason: ok ? 'Holds postgraduate qualification.' : 'Preferred secondary qualification: Master degree completed (Profile: Undergraduate).',
          };
        },
      },
    ],
  },

  // (c) Not Matching Schemes for this Profile (4)
  {
    id: 'tn-pudhumai-penn-state',
    name: 'Moovalur Ramamirtham Ammaiyar Higher Education Assurance Scheme (Pudhumai Penn)',
    schemeName: 'Pudhumai Penn Scheme',
    department: 'Department of Social Welfare and Women Empowerment',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Education',
    subCategory: 'Girls Higher Education Assistance',
    description:
      'Provides financial incentive of ₹1,00,0 per month directly into bank accounts of girl students who studied Classes 6 to 12 in Tamil Nadu government schools until completion of their undergraduate degree or diploma.',
    shortDescription: 'Monthly grant of ₹1,000 for girl students pursuing college education in Tamil Nadu.',
    detailedDescription:
      'The Pudhumai Penn scheme launched by the Government of Tamil Nadu aims to eliminate early child marriages and encourage girl students from government schools to pursue higher degrees and professional diploma courses.',
    benefits: [
      '₹1,000 transferred every month directly into the girl student bank account via DBT',
      'Covers tuition, books, exam fees, and travel costs throughout higher education',
      'Valid for 3 to 5 academic years for BA, BSc, BCom, BE, BTech, MBBS, and Diploma programs',
    ],
    gender: ['Female'],
    minimumAge: 17,
    maximumAge: 25,
    studentRequirement: true,
    requiredDocuments: [
      'Aadhaar card of the student',
      'Government School Study Certificate (EMIS verification for Classes 6 to 12)',
      'College admission fee receipt and identity card',
      'Bank passbook copy in student name',
    ],
    applicationProcess: [
      'Apply online on the official Penkalvi portal (penkalvi.tn.gov.in)',
      'College nodal officer verifies EMIS government school completion and enrollment',
      'District Social Welfare Officer sanctions monthly DBT disbursement',
    ],
    applicationProcedure: [
      'Apply online on the official Penkalvi portal (penkalvi.tn.gov.in)',
      'College nodal officer verifies EMIS government school completion and enrollment',
      'District Social Welfare Officer sanctions monthly DBT disbursement',
    ],
    officialUrl: 'https://penkalvi.tn.gov.in',
    officialWebsite: 'https://penkalvi.tn.gov.in',
    officialApplicationUrl: 'https://penkalvi.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/pudhumai-penn-scheme',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-gender-female',
        label: 'Designated Beneficiary Group (Girl Students from Govt Schools)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = p.gender === 'Female';
          return {
            satisfied: ok,
            reason: ok ? 'Citizen is female student.' : 'Scheme is exclusively for female girl students (Profile gender: Male).',
          };
        },
      },
    ],
  },

  {
    id: 'tn-magalir-urimai-thittam-state',
    name: 'Kalaignar Magalir Urimai Thittam (Basic Income Scheme for Women)',
    schemeName: 'Kalaignar Magalir Urimai Thittam',
    department: 'Special Programme Implementation Department',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Financial Assistance',
    subCategory: 'Direct Cash Transfer for Women Heads of Family',
    description:
      'Provides a monthly rights grant of ₹1,000 directly into the bank accounts of over 1.15 Crore eligible women heads of families across Tamil Nadu.',
    shortDescription: 'Monthly basic income rights grant of ₹1,000 for women head of families in Tamil Nadu.',
    detailedDescription:
      'Recognizes the unpaid domestic labor and economic contribution of women. Disbursed electronically on the 15th of every month directly to Aadhaar-seeded accounts.',
    benefits: [
      '₹1,000 monthly unconditional financial transfer directly via DBT',
      'Annual financial entitlement of ₹12,000 per family head',
      'Direct SMS alerts and automated grievance redressal via helpline 1100',
    ],
    gender: ['Female'],
    minimumAge: 21,
    maximumAge: 65,
    requiredDocuments: [
      'Smart Family Ration Card showing female head of family',
      'Aadhaar card of woman applicant',
      'Electricity consumer connection number and bank passbook',
    ],
    applicationProcess: [
      'Special camp organized at local ration shops / ward centers',
      'Volunteers register application electronically with biometric authentication',
      'Field verification conducted for household eligibility criteria',
    ],
    applicationProcedure: [
      'Special camp organized at local ration shops / ward centers',
      'Volunteers register application electronically with biometric authentication',
      'Field verification conducted for household eligibility criteria',
    ],
    officialUrl: 'https://kmut.tn.gov.in',
    officialWebsite: 'https://kmut.tn.gov.in',
    officialApplicationUrl: 'https://kmut.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/kmut',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-gender-female-head',
        label: 'Designated Beneficiary (Woman Head of Family)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = p.gender === 'Female';
          return {
            satisfied: ok,
            reason: ok ? 'Applicant is female.' : 'Exclusively for women heads of household (Profile gender: Male).',
          };
        },
      },
      {
        id: 'tn-min-age-21',
        label: 'Minimum Age Requirement (21+ years)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const ok = age >= 21;
          return {
            satisfied: ok,
            reason: ok ? 'Age satisfies 21+ requirement.' : `Applicant age (${age} years) is below minimum required 21 years.`,
          };
        },
      },
    ],
  },

  {
    id: 'tn-uzhavar-pathukappu-thittam-state',
    name: 'Tamil Nadu Chief Minister Uzhavar Pathukappu Thittam (Farmers Social Security Scheme)',
    schemeName: 'Uzhavar Pathukappu Thittam',
    department: 'Department of Revenue and Disaster Management',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Agriculture',
    subCategory: 'Farmer Social Insurance & Welfare',
    description:
      'Provides comprehensive social security pensions, accidental death relief, disability compensation, and marriage assistance for registered agricultural farmers and agricultural laborers.',
    shortDescription: 'Comprehensive social security and accident relief for farmers in Tamil Nadu.',
    detailedDescription:
      'Mandatory registration for practicing agricultural cultivators, small/marginal landholders, and agricultural farm laborers with direct benefits transferred by the Revenue administration.',
    benefits: [
      'Accidental death compensation of ₹1,00,000 to nominee',
      'Permanent disability assistance up to ₹50,000',
      'Old age pension of ₹1,000 per month after reaching 60 years for landless agricultural laborers',
    ],
    farmerRequirement: true,
    requiredDocuments: [
      'Uzhavar Pathukappu Thittam membership identity card',
      'Patta/Chitta land documents or VAO certificate of agricultural labor',
      'Aadhaar card and bank account details',
    ],
    applicationProcess: [
      'Apply through Special Tahsildar (Social Security Scheme) or e-Sevai centers',
      'Village Administrative Officer (VAO) verifies land cultivation status',
      'Disbursement sanctioned through District Treasury',
    ],
    applicationProcedure: [
      'Apply through Special Tahsildar (Social Security Scheme) or e-Sevai centers',
      'Village Administrative Officer (VAO) verifies land cultivation status',
      'Disbursement sanctioned through District Treasury',
    ],
    officialUrl: 'https://revenue.tn.gov.in',
    officialWebsite: 'https://revenue.tn.gov.in',
    officialApplicationUrl: 'https://revenue.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/uzhavar-pathukappu',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-farmer-status',
        label: 'Agricultural Farmer / Cultivator Status Requirement',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = p.isFarmer === 'Yes' || p.employmentStatus === 'Farmer';
          return {
            satisfied: ok,
            reason: ok ? 'Verified active agricultural farmer.' : 'Exclusively for agricultural farmers and land cultivators (Profile status: Student).',
          };
        },
      },
    ],
  },

  {
    id: 'tn-old-age-pension-state',
    name: 'Tamil Nadu Indira Gandhi National Old Age Pension Scheme (IGNOAPS - TN)',
    schemeName: 'Tamil Nadu Old Age Pension Scheme',
    department: 'Department of Social Welfare and Women Empowerment',
    ministry: 'Government of Tamil Nadu',
    governmentLevel: 'State',
    state: 'Tamil Nadu',
    category: 'Pension & Senior Citizen',
    subCategory: 'Senior Citizen Monthly Subsistence Pension',
    description:
      'Provides a monthly subsistence pension of ₹1,200 directly to destitute elderly citizens aged 60 years and above residing in Tamil Nadu.',
    shortDescription: 'Monthly pension of ₹1,200 for destitute senior citizens aged 60+ in Tamil Nadu.',
    detailedDescription:
      'Social assistance pension administered by the Revenue Department for elderly citizens with no family financial support or independent means of livelihood.',
    benefits: [
      'Direct monthly pension of ₹1,200 credited directly to postal or bank account',
      'Free distribution of 2 dhotis/saris annually during Pongal and Diwali',
      'Free rice quota under public distribution system (PDS)',
    ],
    minimumAge: 60,
    requiredDocuments: [
      'Age proof / Birth certificate or voter identity card confirming age 60+',
      'Tamil Nadu residence certificate and Aadhaar card',
      'Income/destitute certificate issued by Revenue Inspector / Tahsildar',
    ],
    applicationProcess: [
      'Apply at local e-Sevai center or submit Form to Taluk Office Tahsildar',
      'Social Security Scheme Tahsildar conducts enquiry and field verification',
      'Monthly pension sanctioned and disbursed through electronic DBT',
    ],
    applicationProcedure: [
      'Apply at local e-Sevai center or submit Form to Taluk Office Tahsildar',
      'Social Security Scheme Tahsildar conducts enquiry and field verification',
      'Monthly pension sanctioned and disbursed through electronic DBT',
    ],
    officialUrl: 'https://revenue.tn.gov.in',
    officialWebsite: 'https://revenue.tn.gov.in',
    officialApplicationUrl: 'https://revenue.tn.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/tn-oap',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [
      {
        id: 'tn-domicile',
        label: 'Tamil Nadu State Domicile',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const ok = isStateMatching('Tamil Nadu', p.state);
          return {
            satisfied: ok,
            reason: ok ? 'Verified resident of Tamil Nadu.' : 'Requires Tamil Nadu domicile.',
          };
        },
      },
      {
        id: 'tn-senior-citizen-age',
        label: 'Senior Citizen Age Requirement (60+ years)',
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const age = parseAge(p.age);
          const ok = age >= 60;
          return {
            satisfied: ok,
            reason: ok ? 'Senior citizen age verified.' : `Applicant age (${age} years) is below 60 years requirement.`,
          };
        },
      },
    ],
  },

  {
    id: 'maha-ladki-bahin-state',
    name: 'Mukhyamantri Majhi Ladki Bahin Yojana',
    schemeName: 'Majhi Ladki Bahin Yojana',
    department: 'Women and Child Development Department',
    ministry: 'Government of Maharashtra',
    governmentLevel: 'State',
    state: 'Maharashtra',
    category: 'Women & Child Development',
    subCategory: 'Direct Cash Transfer for Women',
    description:
      'Direct benefit transfer of ₹1,500 per month directly into bank accounts of eligible women aged 21 to 65 years residing in Maharashtra from low-income households.',
    shortDescription: 'Monthly financial assistance of ₹1,500 for women aged 21 to 65 in Maharashtra.',
    detailedDescription:
      'Initiated by the Government of Maharashtra to empower women economically, improve health and nutrition standards, and support self-reliance among women from economically weaker households.',
    benefits: [
      'Monthly grant of ₹1,500 directly transferred to Aadhaar-linked bank accounts',
      'Annual financial empowerment support of ₹18,000 per woman',
      'Direct benefit without requirement of intermediaries or physical document visits',
    ],
    gender: ['Female'],
    minimumAge: 21,
    maximumAge: 65,
    familyIncomeLimit: 250000,
    requiredDocuments: [
      'Aadhaar card of woman applicant',
      'Maharashtra domicile certificate or 15-year residence proof (Ration card / Voter card)',
      'Yellow or Orange Ration Card or verified income certificate under ₹2.5 Lakhs',
      'Aadhaar-seeded bank account passbook',
    ],
    applicationProcess: [
      'Apply online via Nari Shakti Doot mobile app or official portal ladkibahin.maharashtra.gov.in',
      'Local Anganwadi worker or Setu Kendra assists in digital submission',
      'District collectorate validation and direct monthly DBT release',
    ],
    applicationProcedure: [
      'Apply online via Nari Shakti Doot mobile app or official portal ladkibahin.maharashtra.gov.in',
      'Local Anganwadi worker or Setu Kendra assists in digital submission',
      'District collectorate validation and direct monthly DBT release',
    ],
    officialUrl: 'https://ladkibahin.maharashtra.gov.in',
    officialWebsite: 'https://ladkibahin.maharashtra.gov.in',
    officialApplicationUrl: 'https://ladkibahin.maharashtra.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/mmlby',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'karnataka-yuva-nidhi-state',
    name: 'Karnataka Yuva Nidhi Scheme',
    schemeName: 'Yuva Nidhi Scheme',
    department: 'Department of Skill Development, Entrepreneurship and Livelihood',
    ministry: 'Government of Karnataka',
    governmentLevel: 'State',
    state: 'Karnataka',
    category: 'Employment',
    subCategory: 'Unemployment Allowance & Skill Training',
    description:
      'Unemployment allowance of ₹3,000 per month for degree holders and ₹1,500 per month for diploma holders in Karnataka who remain unemployed after passing out.',
    shortDescription: 'Monthly allowance of ₹3,000 for graduates and ₹1,500 for diploma holders.',
    detailedDescription:
      'Yuva Nidhi provides temporary income support to educated youth of Karnataka while they search for employment or prepare for competitive examinations, alongside mandatory free skill development courses.',
    benefits: [
      '₹3,000 per month for unemployed graduates (BA, BSc, BCom, BE, etc.) for up to 2 years',
      '₹1,500 per month for unemployed diploma holders for up to 2 years',
      'Free skill enhancement training provided through Karnataka Skill Development Corporation',
    ],
    minimumAge: 20,
    maximumAge: 30,
    employmentRequirement: 'Unemployed',
    requiredDocuments: [
      'Aadhaar card with Karnataka domicile address',
      'Degree or Diploma passing certificate from Karnataka recognized university/board',
      'Self-declaration of unemployment status',
      'Aadhaar-seeded bank account details',
    ],
    applicationProcess: [
      'Register on Seva Sindhu portal (sevasindhuservices.karnataka.gov.in)',
      'Upload university registration number and Aadhaar verification',
      'Allowance credited on the 10th of every month via DBT',
    ],
    applicationProcedure: [
      'Register on Seva Sindhu portal (sevasindhuservices.karnataka.gov.in)',
      'Upload university registration number and Aadhaar verification',
      'Allowance credited on the 10th of every month via DBT',
    ],
    officialUrl: 'https://sevasindhuservices.karnataka.gov.in',
    officialWebsite: 'https://sevasindhuservices.karnataka.gov.in',
    officialApplicationUrl: 'https://sevasindhu.karnataka.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/yuva-nidhi',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'up-kanya-sumangala-state',
    name: 'Mukhyamantri Kanya Sumangala Yojana',
    schemeName: 'Kanya Sumangala Yojana',
    department: 'Women and Child Development Department',
    ministry: 'Government of Uttar Pradesh',
    governmentLevel: 'State',
    state: 'Uttar Pradesh',
    category: 'Women & Child Development',
    subCategory: 'Conditional Cash Transfers for Girl Child',
    description:
      'Provides graded financial assistance totaling ₹25,000 in six installments across birth, vaccination, school admission, and higher education for girl children in UP.',
    shortDescription: 'Financial grant up to ₹25,000 for girl children across educational milestones.',
    detailedDescription:
      'A pioneering initiative of the Uttar Pradesh Government to improve the child sex ratio, promote institutional delivery, eliminate female foeticide, and support girl education from birth through graduation.',
    benefits: [
      'Phase 1: ₹5,000 at birth of the girl child',
      'Phase 2: ₹2,000 upon completion of full immunization',
      'Phase 3: ₹3,000 upon admission to Class 1',
      'Phase 4: ₹3,000 upon admission to Class 6',
      'Phase 5: ₹5,000 upon admission to Class 9',
      'Phase 6: ₹7,000 upon admission to undergraduate degree or two-year diploma course',
    ],
    gender: ['Female'],
    familyIncomeLimit: 300000,
    requiredDocuments: [
      'Aadhaar card of parent and girl child',
      'UP domicile certificate',
      'Income certificate showing family income under ₹3 Lakhs',
      'Birth certificate or school admission certificate for corresponding phase',
      'Joint bank account passbook with mother',
    ],
    applicationProcess: [
      'Apply online on mksy.up.gov.in',
      'Submit stage application corresponding to the childs current educational milestone',
      'Verification by Block Development Officer / SDM and direct DBT release',
    ],
    applicationProcedure: [
      'Apply online on mksy.up.gov.in',
      'Submit stage application corresponding to the childs current educational milestone',
      'Verification by Block Development Officer / SDM and direct DBT release',
    ],
    officialUrl: 'https://mksy.up.gov.in',
    officialWebsite: 'https://mksy.up.gov.in',
    officialApplicationUrl: 'https://mksy.up.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/mksy',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'wb-kanyashree-prakalpa-state',
    name: 'Kanyashree Prakalpa',
    schemeName: 'Kanyashree Prakalpa Scheme',
    department: 'Department of Women and Child Development and Social Welfare',
    ministry: 'Government of West Bengal',
    governmentLevel: 'State',
    state: 'West Bengal',
    category: 'Education',
    subCategory: 'Conditional Girl Student Cash Incentives',
    description:
      'United Nations Public Service Award-winning scheme offering annual scholarships and a one-time grant of ₹25,000 to keep adolescent girls in school and prevent underage marriages.',
    shortDescription: 'Annual scholarship of ₹1,000 (K1) and one-time grant of ₹25,000 (K2) for girls in WB.',
    detailedDescription:
      'Kanyashree Prakalpa seeks to improve the status of adolescent girls in West Bengal. It provides K1 (annual grant of ₹1,000 for unmarried girls in Classes 8-12) and K2 (one-time grant of ₹25,000 on reaching 18 years while studying).',
    benefits: [
      'K1: Annual stipend of ₹1,000 for girls aged 13 to 18 enrolled in Classes 8 to 12',
      'K2: One-time lump sum grant of ₹25,000 upon turning 18, provided the girl remains unmarried and enrolled in education',
      'Direct bank credit with personal ATM card in student name',
    ],
    gender: ['Female'],
    minimumAge: 13,
    maximumAge: 19,
    maritalStatus: ['Single'],
    studentRequirement: true,
    requiredDocuments: [
      'Birth certificate and Aadhaar card of the girl',
      'Declaration of unmarried status signed by parent and candidate',
      'Bonafide school/college enrollment certificate',
      'Personal bank account passbook copy',
    ],
    applicationProcess: [
      'Obtain and submit Kanyashree Form from the head of the recognized school/institution',
      'Institution uploads data directly to official Kanyashree portal (wbkanyashree.gov.in)',
      'Funds disbursed directly to student bank accounts',
    ],
    applicationProcedure: [
      'Obtain and submit Kanyashree Form from the head of the recognized school/institution',
      'Institution uploads data directly to official Kanyashree portal (wbkanyashree.gov.in)',
      'Funds disbursed directly to student bank accounts',
    ],
    officialUrl: 'https://www.wbkanyashree.gov.in',
    officialWebsite: 'https://www.wbkanyashree.gov.in',
    officialApplicationUrl: 'https://www.wbkanyashree.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/kanyashree-prakalpa',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },

  {
    id: 'telangana-rythu-bharosa-state',
    name: 'Telangana Rythu Bharosa (Agricultural Investment Support)',
    schemeName: 'Rythu Bharosa Scheme',
    department: 'Department of Agriculture',
    ministry: 'Government of Telangana',
    governmentLevel: 'State',
    state: 'Telangana',
    category: 'Agriculture',
    subCategory: 'Crop Investment Grant',
    description:
      'Provides ₹15,000 per acre per year (₹7,500 per crop season) to landholding farmers and tenant cultivators in Telangana for purchase of agricultural inputs.',
    shortDescription: '₹15,000 per acre/year input subsidy for agricultural farmers in Telangana.',
    detailedDescription:
      'Rythu Bharosa provides direct financial assistance to agricultural landholders and verified tenant farmers to meet initial seasonal costs for seeds, fertilizer, pesticides, labor, and field preparations.',
    benefits: [
      '₹7,500 per acre paid before the start of the Kharif crop season',
      '₹7,500 per acre paid before the start of the Rabi crop season',
      'Covers both small and marginal farmers as well as verified landless tenant cultivators',
      'Direct DBT credit directly to farmer bank accounts before sowing begins',
    ],
    farmerRequirement: true,
    requiredDocuments: [
      'Pattadar passbook number or Dharani portal registration ID',
      'Aadhaar card of farmer',
      'Aadhaar-seeded active bank savings account',
    ],
    applicationProcess: [
      'Verification against Telangana digital land records on Dharani portal',
      'Agriculture Extension Officers (AEO) prepare village-level beneficiary lists',
      'Automatic seasonal treasury DBT disbursement directly to accounts',
    ],
    applicationProcedure: [
      'Verification against Telangana digital land records on Dharani portal',
      'Agriculture Extension Officers (AEO) prepare village-level beneficiary lists',
      'Automatic seasonal treasury DBT disbursement directly to accounts',
    ],
    officialUrl: 'https://rythubandhu.telangana.gov.in',
    officialWebsite: 'https://rythubandhu.telangana.gov.in',
    officialApplicationUrl: 'https://dharani.telangana.gov.in',
    sourceUrl: 'https://www.myscheme.gov.in/schemes/rythu-bandhu',
    lastUpdated: '2026-03-01',
    activeStatus: true,
    isVerifiedOfficial: true,
    rules: [],
  },
];
