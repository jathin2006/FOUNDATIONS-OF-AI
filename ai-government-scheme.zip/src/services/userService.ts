import { AuthenticatedUser, ProfileData, ProfileStep } from '../types';

export interface UserAccount {
  uid: string;
  email: string;
  fullName: string;
  profileCompleted: boolean;
  lastActiveStep: ProfileStep;
  profile: ProfileData;
  updatedAt: string;
}

const STORAGE_KEY_TOKEN = 'gov_scheme_advisor_auth_token_v1';
const STORAGE_KEY_CACHED_USER = 'gov_scheme_advisor_cached_user_v1';

export const createDefaultProfile = (fullName: string = ''): ProfileData => ({
  fullName: fullName || '',
  age: '',
  gender: '',
  state: '',
  district: '',

  religion: '',
  casteCategory: '',
  minorityCommunity: '',

  personalIncome: '',
  familyIncome: '',
  bplRationCard: '',

  educationLevel: '',
  courseStream: '',
  currentStudent: '',
  currentGradeYear: '',

  employmentStatus: '',
  otherEmploymentStatus: '',
  occupation: '',
  farmerLandOwnership: '',

  maritalStatus: '',
  familyMembersCount: '',
  earningMembersCount: '',

  personWithDisability: '',
  disabilityPercentage: '',
  isFarmer: '',
  ownAgriculturalLand: '',
  ownHouse: '',
});

export const normalizeEmail = (email: string): string => {
  return (email || '').trim().toLowerCase();
};

export const checkIsProfileComplete = (p: ProfileData | null | undefined): boolean => {
  if (!p) return false;
  return Boolean(
    p.fullName?.trim() &&
      p.age?.trim() &&
      p.gender &&
      p.state?.trim() &&
      p.district?.trim() &&
      p.casteCategory &&
      p.familyIncome?.trim() &&
      p.educationLevel &&
      p.employmentStatus
  );
};

// ---------------- TOKEN & LOCAL SESSION ----------------

export const getAuthToken = (): string | null => {
  if (typeof localStorage !== 'undefined') {
    try {
      return localStorage.getItem(STORAGE_KEY_TOKEN);
    } catch {
      return null;
    }
  }
  return null;
};

export const setAuthToken = (token: string | null): void => {
  if (typeof localStorage !== 'undefined') {
    try {
      if (token) {
        localStorage.setItem(STORAGE_KEY_TOKEN, token);
      } else {
        localStorage.removeItem(STORAGE_KEY_TOKEN);
        localStorage.removeItem(STORAGE_KEY_CACHED_USER);
      }
    } catch {
      // Ignored
    }
  }
};

export const getCachedUser = (): AuthenticatedUser | null => {
  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_CACHED_USER);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }
  return null;
};

export const setCachedUser = (user: AuthenticatedUser | null): void => {
  if (typeof localStorage !== 'undefined') {
    try {
      if (user) {
        localStorage.setItem(STORAGE_KEY_CACHED_USER, JSON.stringify(user));
      } else {
        localStorage.removeItem(STORAGE_KEY_CACHED_USER);
      }
    } catch {
      // Ignored
    }
  }
};

export const clearActiveSession = (): void => {
  setAuthToken(null);
  setCachedUser(null);
};

export const getActiveSessionEmail = (): string | null => {
  return getCachedUser()?.email || null;
};

export const setActiveSessionEmail = (_email: string | null): void => {
  // Maintained for backward compatibility
};

// ---------------- REAL BACKEND API CALLS ----------------

export interface AuthApiResponse {
  success: boolean;
  error?: string;
  token?: string;
  user?: AuthenticatedUser;
}

/**
 * Sends credentials to the backend authentication API.
 * Uses bcrypt verification on the server.
 */
export const authenticateUser = async (
  email: string,
  password: string
): Promise<AuthApiResponse> => {
  const normalized = normalizeEmail(email);
  if (!normalized) {
    return { success: false, error: 'Please enter a valid email address.' };
  }
  if (!password) {
    return { success: false, error: 'Password is required.' };
  }

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: normalized, password }),
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok || !data.success) {
      return {
        success: false,
        error:
          data.error ||
          (res.status === 404
            ? 'No account found with this email address. Please create an account first.'
            : res.status === 401
              ? 'Incorrect email or password. Please try again.'
              : 'Authentication failed. Please verify your credentials.'),
      };
    }

    if (data.token) {
      setAuthToken(data.token);
    }
    if (data.user) {
      setCachedUser(data.user);
    }

    return {
      success: true,
      token: data.token,
      user: data.user,
    };
  } catch (err) {
    console.error('Network error during authentication:', err);
    return {
      success: false,
      error: 'Authentication service is temporarily unavailable. Please try again.',
    };
  }
};

/**
 * Registers a new citizen account on the backend.
 * Encrypts and securely hashes passwords on the server using bcrypt.
 */
export const registerUserAccount = async (
  email: string,
  fullName: string,
  password: string
): Promise<AuthApiResponse> => {
  const normalized = normalizeEmail(email);

  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: normalized,
        fullName: fullName.trim(),
        password,
      }),
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok || !data.success) {
      return {
        success: false,
        error:
          data.error ||
          (res.status === 409
            ? 'An account with this email address already exists. Please sign in instead.'
            : 'Registration failed. Please check your information and try again.'),
      };
    }

    if (data.token) {
      setAuthToken(data.token);
    }
    if (data.user) {
      setCachedUser(data.user);
    }

    return {
      success: true,
      token: data.token,
      user: data.user,
    };
  } catch (err) {
    console.error('Network error during registration:', err);
    return {
      success: false,
      error: 'Registration service is temporarily unreachable. Please try again.',
    };
  }
};

/**
 * Verifies the existing session token against the backend session store.
 */
export const verifySession = async (): Promise<{
  authenticated: boolean;
  user: AuthenticatedUser | null;
}> => {
  const token = getAuthToken();
  if (!token) {
    clearActiveSession();
    return { authenticated: false, user: null };
  }

  try {
    const res = await fetch('/api/auth/session', {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!res.ok) {
      clearActiveSession();
      return { authenticated: false, user: null };
    }

    const data = await res.json();
    if (data.authenticated && data.user) {
      setCachedUser(data.user);
      return { authenticated: true, user: data.user };
    }

    clearActiveSession();
    return { authenticated: false, user: null };
  } catch (err) {
    console.warn('Session verification error:', err);
    // In case of transient network failure on refresh, use cached user if available
    const cached = getCachedUser();
    if (cached) {
      return { authenticated: true, user: cached };
    }
    return { authenticated: false, user: null };
  }
};

/**
 * Logs out the active user and terminates the session on the backend.
 */
export const logoutUser = async (): Promise<void> => {
  const token = getAuthToken();
  if (token) {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    } catch {
      // Ignored
    }
  }
  clearActiveSession();
};

/**
 * Persists user profile to their isolated database record on the backend.
 */
export const saveUserProfile = async (
  _email: string,
  profile: ProfileData,
  completed: boolean,
  step: ProfileStep = 8
): Promise<AuthenticatedUser | null> => {
  const token = getAuthToken();
  if (!token) return null;

  try {
    const res = await fetch('/api/user/profile', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ profile, completed, step }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.user) {
        setCachedUser(data.user);
        return data.user;
      }
    }
  } catch (err) {
    console.error('Failed to save profile to server:', err);
  }

  // Update local cache
  const cached = getCachedUser();
  if (cached) {
    cached.profile = { ...profile };
    cached.profileCompleted = completed;
    cached.lastActiveStep = step;
    setCachedUser(cached);
    return cached;
  }
  return null;
};

/**
 * Saves in-progress draft profile to the backend.
 */
export const saveUserDraft = async (
  _email: string,
  profileFields: Partial<ProfileData>,
  step: ProfileStep
): Promise<AuthenticatedUser | null> => {
  const token = getAuthToken();
  if (!token) return null;

  try {
    const res = await fetch('/api/user/draft', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ profileFields, step }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.user) {
        setCachedUser(data.user);
        return data.user;
      }
    }
  } catch (err) {
    console.error('Failed to save draft to server:', err);
  }

  const cached = getCachedUser();
  if (cached) {
    cached.profile = { ...cached.profile, ...profileFields };
    cached.lastActiveStep = step;
    setCachedUser(cached);
    return cached;
  }
  return null;
};

/**
 * Synchronous backward-compatibility getter for cached user account.
 */
export const getUserAccount = (email: string): UserAccount | null => {
  const cached = getCachedUser();
  if (cached && normalizeEmail(cached.email) === normalizeEmail(email)) {
    return {
      uid: cached.uid,
      email: cached.email,
      fullName: cached.fullName,
      profileCompleted: cached.profileCompleted,
      lastActiveStep: cached.lastActiveStep,
      profile: cached.profile,
      updatedAt: new Date().toISOString(),
    };
  }
  return null;
};

export const getOrCreateUserAccount = (
  email: string,
  fullName: string = ''
): UserAccount => {
  const cached = getCachedUser();
  if (cached && normalizeEmail(cached.email) === normalizeEmail(email)) {
    return {
      uid: cached.uid,
      email: cached.email,
      fullName: cached.fullName,
      profileCompleted: cached.profileCompleted,
      lastActiveStep: cached.lastActiveStep,
      profile: cached.profile,
      updatedAt: new Date().toISOString(),
    };
  }

  return {
    uid: `cached_${normalizeEmail(email)}`,
    email: email.trim(),
    fullName: fullName.trim() || email.split('@')[0],
    profileCompleted: false,
    lastActiveStep: 1,
    profile: createDefaultProfile(fullName),
    updatedAt: new Date().toISOString(),
  };
};
