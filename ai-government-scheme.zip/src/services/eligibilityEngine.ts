import { EvaluatedScheme, GovernmentScheme, ProfileData, RuleResult } from '../types';
import { synthesizeSchemeRules } from './ruleSynthesizer';
import { loadAllGovernmentSchemes } from './schemeDatabaseService';
import { isStateMatching } from '../utils/stateNormalizer';

export interface EligibilitySummary {
  totalAnalyzed: number;
  potentiallyEligibleCount: number;
  partialMatchCount: number;
  notMatchingCount: number;
  evaluatedSchemes: EvaluatedScheme[];
}

/**
 * Deterministic rule-based evaluation engine.
 * Evaluates user profile data against defined criteria rules for every scheme.
 * Follows strict evaluation priority:
 * 1. Check Government Level & State requirement.
 * 2. If State/UT scheme and state mismatch: immediately NOT APPLICABLE / NOT MATCHING (score 0%).
 * 3. Only if state matches or Central: evaluate demographic and socio-economic rules.
 */
export const evaluateProfileEligibility = (
  profile: ProfileData,
  schemes?: GovernmentScheme[]
): EligibilitySummary => {
  const rawSchemes = schemes && schemes.length > 0 ? schemes : loadAllGovernmentSchemes();
  const activeSchemes = rawSchemes.filter((scheme) => scheme.activeStatus !== false);

  const evaluatedSchemes: EvaluatedScheme[] = activeSchemes.map((scheme) => {
    const isStateOrUt = scheme.governmentLevel === 'State' || scheme.governmentLevel === 'UT';
    const hasStateRequirement = scheme.state && scheme.state.trim().toLowerCase() !== 'all';

    // STEP 1, 2, 3: Strict state residency priority check
    if (isStateOrUt && hasStateRequirement) {
      const stateMatches = isStateMatching(scheme.state, profile.state);

      if (!stateMatches) {
        // State requirement failed: immediately classify as Not Matching with 0% score
        const stateRuleResult: RuleResult = {
          label: `State Domicile Requirement (${scheme.state})`,
          satisfied: false,
          reason: `Scheme is exclusively for residents of ${scheme.state}. Citizen profile state is ${profile.state || 'unspecified'}.`,
          isMandatory: true,
        };

        return {
          scheme,
          matchScore: 0,
          status: 'Not Matching' as const,
          matchedRules: [],
          unmetRules: [stateRuleResult],
        };
      }
    }

    // STEP 4: State passed or Central scheme -> evaluate remaining criteria
    const matchedRules: RuleResult[] = [];
    const unmetRules: RuleResult[] = [];

    // Use scheme's explicit rules if present, or synthesize from structured criteria
    const rulesToEvaluate =
      scheme.rules && scheme.rules.length > 0
        ? scheme.rules
        : synthesizeSchemeRules(scheme);

    rulesToEvaluate.forEach((rule) => {
      const evaluation = rule.evaluate(profile);
      const result: RuleResult = {
        label: rule.label,
        satisfied: evaluation.satisfied,
        reason: evaluation.reason,
        isMandatory: rule.isMandatory,
      };

      if (evaluation.satisfied) {
        matchedRules.push(result);
      } else {
        unmetRules.push(result);
      }
    });

    const totalRules = rulesToEvaluate.length;
    const satisfiedRulesCount = matchedRules.length;

    // STEP 5: Calculate match score using applicable criteria
    const matchScore = totalRules > 0 ? Math.round((satisfiedRulesCount / totalRules) * 100) : 0;

    const hasFailedMandatory = unmetRules.some((r) => r.isMandatory);

    // Determine status:
    // If ANY mandatory criterion fails, the scheme CANNOT be classified as Potentially Eligible or Partial Match.
    // It MUST be classified as 'Not Matching'.
    let status: 'Potentially Eligible' | 'Partial Match' | 'Not Matching';
    if (hasFailedMandatory) {
      status = 'Not Matching';
    } else if (matchScore >= 75) {
      status = 'Potentially Eligible';
    } else if (matchScore >= 50) {
      status = 'Partial Match';
    } else {
      status = 'Not Matching';
    }

    return {
      scheme,
      matchScore,
      status,
      matchedRules,
      unmetRules,
    };
  });

  // Calculate dynamic stats
  const potentiallyEligibleCount = evaluatedSchemes.filter((s) => s.status === 'Potentially Eligible').length;
  const partialMatchCount = evaluatedSchemes.filter((s) => s.status === 'Partial Match').length;
  const notMatchingCount = evaluatedSchemes.filter((s) => s.status === 'Not Matching').length;

  return {
    totalAnalyzed: evaluatedSchemes.length,
    potentiallyEligibleCount,
    partialMatchCount,
    notMatchingCount,
    evaluatedSchemes,
  };
};
