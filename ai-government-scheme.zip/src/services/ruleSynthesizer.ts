import { GovernmentScheme, ProfileData, SchemeRule } from '../types';
import { parseAge, parseIncome, parsePercentage } from '../data/schemesDatabase';
import { isStateMatching } from '../utils/stateNormalizer';

/**
 * Deterministically synthesizes strict eligibility rules from structured criteria fields.
 * Follows official policy: Missing criteria are never assumed to be eligible.
 */
export const synthesizeSchemeRules = (scheme: Partial<GovernmentScheme>): SchemeRule[] => {
  // If scheme already has explicit rules defined, return them directly
  if (scheme.rules && scheme.rules.length > 0) {
    return scheme.rules;
  }

  const rules: SchemeRule[] = [];

  // 1. Government Level & State residency requirement
  if (scheme.governmentLevel === 'State' || scheme.governmentLevel === 'UT') {
    if (scheme.state && scheme.state !== 'All') {
      const targetState = scheme.state;
      rules.push({
        id: 'state-domicile',
        label: `State Domicile Requirement (${targetState})`,
        isMandatory: true,
        evaluate: (p: ProfileData) => {
          const match = isStateMatching(targetState, p.state);
          return {
            satisfied: match,
            reason: match
              ? `Citizen is verified as a bona fide resident of ${targetState}.`
              : `Scheme is exclusively for residents of ${targetState} (Profile state: ${p.state || 'unspecified'}).`,
          };
        },
      });
    }
  }

  // 2. Age Requirement
  if (scheme.minimumAge !== undefined || scheme.maximumAge !== undefined) {
    const min = scheme.minimumAge ?? 0;
    const max = scheme.maximumAge ?? 120;
    rules.push({
      id: 'age-criteria',
      label: `Age Requirement (${min}${max < 120 ? ` to ${max}` : '+'} years)`,
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const age = parseAge(p.age);
        if (!p.age) {
          return {
            satisfied: false,
            reason: 'Applicant age is not specified in citizen profile.',
          };
        }
        const satisfied = age >= min && age <= max;
        return {
          satisfied,
          reason: satisfied
            ? `Age (${age} years) is within the eligible age bracket of ${min} to ${max} years.`
            : `Age (${age} years) falls outside the mandated bracket of ${min} to ${max} years.`,
        };
      },
    });
  }

  // 3. Gender Requirement
  if (scheme.gender && scheme.gender !== 'All') {
    const allowed = Array.isArray(scheme.gender) ? scheme.gender : [scheme.gender];
    rules.push({
      id: 'gender-criteria',
      label: `Designated Gender Group (${allowed.join(', ')})`,
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const satisfied = allowed.includes(p.gender as any);
        return {
          satisfied,
          reason: satisfied
            ? `Citizen gender (${p.gender}) satisfies scheme eligibility.`
            : `Scheme is specifically designated for ${allowed.join('/')} citizens.`,
        };
      },
    });
  }

  // 4. Caste Category Requirement
  if (scheme.casteCategory && scheme.casteCategory !== 'All') {
    const allowed = Array.isArray(scheme.casteCategory) ? scheme.casteCategory : [scheme.casteCategory];
    rules.push({
      id: 'caste-category',
      label: `Social Category Requirement (${allowed.join(', ')})`,
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const satisfied = allowed.includes(p.casteCategory as any);
        return {
          satisfied,
          reason: satisfied
            ? `Social category (${p.casteCategory}) is eligible for this welfare benefit.`
            : `Requires ${allowed.join('/')} category (Profile category: ${p.casteCategory || 'unspecified'}).`,
        };
      },
    });
  }

  // 5. Minority Community Requirement
  if (scheme.minorityRequirement === true || scheme.minorityRequirement === 'Yes') {
    rules.push({
      id: 'minority-status',
      label: 'Minority Community Requirement',
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const satisfied = p.minorityCommunity === 'Yes';
        return {
          satisfied,
          reason: satisfied
            ? 'Citizen belongs to a notified minority community.'
            : 'Candidate must belong to a recognized minority community.',
        };
      },
    });
  }

  // 6. Family Income Ceiling
  if (scheme.familyIncomeLimit !== undefined && scheme.familyIncomeLimit > 0) {
    const limit = scheme.familyIncomeLimit;
    rules.push({
      id: 'family-income-limit',
      label: `Family Annual Income Ceiling (₹ ${limit.toLocaleString('en-IN')})`,
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const inc = parseIncome(p.familyIncome);
        const satisfied = inc <= limit;
        return {
          satisfied,
          reason: satisfied
            ? `Family income (₹ ${inc.toLocaleString('en-IN')}) is within ₹ ${limit.toLocaleString('en-IN')}.`
            : `Family annual income (₹ ${inc.toLocaleString('en-IN')}) exceeds limit of ₹ ${limit.toLocaleString('en-IN')}.`,
        };
      },
    });
  }

  // 7. Personal Income Ceiling
  if (scheme.personalIncomeLimit !== undefined && scheme.personalIncomeLimit > 0) {
    const limit = scheme.personalIncomeLimit;
    rules.push({
      id: 'personal-income-limit',
      label: `Personal Annual Income Ceiling (₹ ${limit.toLocaleString('en-IN')})`,
      isMandatory: false,
      evaluate: (p: ProfileData) => {
        const inc = parseIncome(p.personalIncome);
        const satisfied = inc <= limit;
        return {
          satisfied,
          reason: satisfied
            ? `Personal income (₹ ${inc.toLocaleString('en-IN')}) is within allowable limit.`
            : `Personal income exceeds ceiling of ₹ ${limit.toLocaleString('en-IN')}.`,
        };
      },
    });
  }

  // 8. BPL / Priority Ration Card Requirement
  if (
    scheme.bplRequirement === true ||
    scheme.bplRequirement === 'Yes' ||
    scheme.rationCardRequirement === true ||
    scheme.rationCardRequirement === 'Yes'
  ) {
    rules.push({
      id: 'bpl-ration-card',
      label: 'BPL / Priority Ration Card Requirement',
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const satisfied = p.bplRationCard === 'Yes';
        return {
          satisfied,
          reason: satisfied
            ? 'Citizen possesses an active BPL / Priority Ration Card.'
            : 'Requires an active Below Poverty Line (BPL) or Antyodaya/Priority Ration Card.',
        };
      },
    });
  }

  // 9. Student Status Requirement
  if (scheme.studentRequirement === true || scheme.studentRequirement === 'Yes') {
    rules.push({
      id: 'student-enrollment',
      label: 'Active Student Enrollment',
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const satisfied = p.currentStudent === 'Yes';
        return {
          satisfied,
          reason: satisfied
            ? 'Citizen is actively enrolled in an educational institution.'
            : 'Must be an enrolled student in an accredited school, college, or university.',
        };
      },
    });
  }

  // 10. Education Level Requirement
  if (scheme.educationRequirement) {
    const allowed = Array.isArray(scheme.educationRequirement)
      ? scheme.educationRequirement
      : [scheme.educationRequirement];
    rules.push({
      id: 'education-level',
      label: `Educational Qualification (${allowed.join(', ')})`,
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const satisfied = allowed.includes(p.educationLevel);
        return {
          satisfied,
          reason: satisfied
            ? `Education level (${p.educationLevel}) satisfies requirement.`
            : `Requires qualification in: ${allowed.join(', ')} (Profile: ${p.educationLevel || 'unspecified'}).`,
        };
      },
    });
  }

  // 11. Employment Status Requirement
  if (scheme.employmentRequirement) {
    const allowed = Array.isArray(scheme.employmentRequirement)
      ? scheme.employmentRequirement
      : [scheme.employmentRequirement];
    rules.push({
      id: 'employment-status',
      label: `Employment Status (${allowed.join(', ')})`,
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const satisfied = allowed.includes(p.employmentStatus);
        return {
          satisfied,
          reason: satisfied
            ? `Employment status (${p.employmentStatus}) satisfies criteria.`
            : `Targeted towards ${allowed.join(', ')} individuals (Profile: ${p.employmentStatus || 'unspecified'}).`,
        };
      },
    });
  }

  // 12. Farmer Requirement
  if (scheme.farmerRequirement === true || scheme.farmerRequirement === 'Yes') {
    rules.push({
      id: 'farmer-status',
      label: 'Agricultural Farmer Requirement',
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const satisfied = p.isFarmer === 'Yes' || p.employmentStatus === 'Farmer';
        return {
          satisfied,
          reason: satisfied
            ? 'Citizen is verified as an active agricultural farmer.'
            : 'Applicant must be an agricultural cultivator or farmer.',
        };
      },
    });
  }

  // 13. Land Ownership Requirement
  if (scheme.landOwnershipRequirement === true || scheme.landOwnershipRequirement === 'Yes') {
    rules.push({
      id: 'land-ownership',
      label: 'Agricultural Land Holding Requirement',
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const satisfied = p.ownAgriculturalLand === 'Yes' || p.farmerLandOwnership === 'Yes';
        return {
          satisfied,
          reason: satisfied
            ? 'Citizen holds cultivable agricultural land.'
            : 'Requires ownership or operational holding of cultivable agricultural land.',
        };
      },
    });
  }

  // 14. Disability Requirement
  if (scheme.disabilityRequirement === true || scheme.disabilityRequirement === 'Yes') {
    const minPct = scheme.disabilityPercentage ?? 40;
    rules.push({
      id: 'disability-criteria',
      label: `Persons with Benchmark Disability (PwD ≥ ${minPct}%)`,
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const isPwd = p.personWithDisability === 'Yes';
        const pct = parsePercentage(p.disabilityPercentage);
        const satisfied = isPwd && (pct >= minPct || !p.disabilityPercentage);
        return {
          satisfied,
          reason: satisfied
            ? `Candidate qualifies as PwD with valid benchmark disability percentage.`
            : `Requires benchmark disability (minimum ${minPct}%).`,
        };
      },
    });
  }

  // 15. Marital Status
  if (scheme.maritalStatus && scheme.maritalStatus !== 'All') {
    const allowed = Array.isArray(scheme.maritalStatus) ? scheme.maritalStatus : [scheme.maritalStatus];
    rules.push({
      id: 'marital-status',
      label: `Marital Status (${allowed.join(', ')})`,
      isMandatory: true,
      evaluate: (p: ProfileData) => {
        const satisfied = allowed.includes(p.maritalStatus as any);
        return {
          satisfied,
          reason: satisfied
            ? `Marital status (${p.maritalStatus}) matches scheme criteria.`
            : `Scheme is designated for ${allowed.join(', ')} persons (Profile: ${p.maritalStatus || 'unspecified'}).`,
        };
      },
    });
  }

  // If no criteria were matched at all, provide a default policy rule
  if (rules.length === 0) {
    rules.push({
      id: 'general-welfare-rule',
      label: 'General Citizen Welfare Criterion',
      isMandatory: false,
      evaluate: () => ({
        satisfied: true,
        reason: 'Broad-based universal welfare program accessible to all Indian citizens.',
      }),
    });
  }

  return rules;
};
