import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, ShieldAlert, Loader2, Check } from 'lucide-react';
import { ValidationErrors } from '../types';
import { authenticateUser } from '../services/userService';

interface LoginFormProps {
  onNavigateToRegister: () => void;
  onNavigateToForgotPassword: () => void;
  onLoginSuccess: (email: string) => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({
  onNavigateToRegister,
  onNavigateToForgotPassword,
  onLoginSuccess,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [touched, setTouched] = useState<{ email?: boolean; password?: boolean }>({});

  const validateEmail = (val: string): string | undefined => {
    const trimmed = val.trim();
    if (!trimmed) {
      return 'Please enter a valid email address.';
    }
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(trimmed)) {
      return 'Please enter a valid email address.';
    }
    return undefined;
  };

  const validatePassword = (val: string): string | undefined => {
    if (!val) {
      return 'Password is required.';
    }
    if (val.length < 6) {
      return 'Password must be at least 6 characters.';
    }
    return undefined;
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setEmail(val);
    if (generalError) setGeneralError(null);
    if (touched.email) {
      setErrors((prev) => ({ ...prev, email: validateEmail(val) }));
    }
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setPassword(val);
    if (generalError) setGeneralError(null);
    if (touched.password) {
      setErrors((prev) => ({ ...prev, password: validatePassword(val) }));
    }
  };

  const handleBlur = (field: 'email' | 'password') => {
    setTouched((prev) => ({ ...prev, [field]: true }));
    if (field === 'email') {
      if (email.trim().length > 0) {
        setErrors((prev) => ({ ...prev, email: validateEmail(email) }));
      }
    } else if (field === 'password') {
      if (password.length > 0) {
        setErrors((prev) => ({ ...prev, password: validatePassword(password) }));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTouched({ email: true, password: true });
    setGeneralError(null);

    const emailErr = validateEmail(email);
    const passErr = validatePassword(password);

    if (emailErr || passErr) {
      setErrors({ email: emailErr, password: passErr });
      return;
    }

    setErrors({});
    setIsLoading(true);

    try {
      const authResult = await authenticateUser(email, password);
      if (!authResult.success) {
        setIsLoading(false);
        setGeneralError(authResult.error || 'Authentication failed. Please verify your credentials.');
        return;
      }

      setIsLoading(false);
      onLoginSuccess(email.trim());
    } catch {
      setIsLoading(false);
      setGeneralError('Authentication service is temporarily unavailable. Please try again.');
    }
  };

  return (
    <div className="relative w-full max-w-[390px] mx-auto">
      {/* Specular Edge Glows */}
      <div
        className="absolute -left-[3px] top-1/3 w-[5px] h-24 bg-cyan-300 rounded-full blur-[3px] opacity-80 pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute -right-[3px] top-1/2 w-[5px] h-20 bg-cyan-400 rounded-full blur-[3px] opacity-75 pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute -top-[2px] left-1/4 w-28 h-[3px] bg-cyan-200/60 rounded-full blur-[2px] pointer-events-none"
        aria-hidden="true"
      />

      {/* Main Glassmorphism Card */}
      <div className="glass-card rounded-[32px] p-7 sm:p-9 relative">
        {/* Subtle interior glow housed in an overflow-hidden backdrop layer so popup bounds aren't clipped */}
        <div className="absolute inset-0 rounded-[32px] overflow-hidden pointer-events-none" aria-hidden="true">
          <div
            className="absolute -top-16 -right-16 w-48 h-48 bg-blue-500/15 rounded-full blur-3xl pointer-events-none"
          />
          <div
            className="absolute -bottom-16 -left-16 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"
          />
        </div>

        {/* Circular Top Emblem */}
        <div className="flex flex-col items-center justify-center mb-6 relative z-10">
          <div className="relative w-24 h-24 rounded-full border border-cyan-400/40 flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.2)] bg-blue-950/20">
            {/* Inner secondary circle ring */}
            <div className="w-[82px] h-[82px] rounded-full border border-cyan-300/20 flex items-center justify-center">
              {/* Civic Seal Pediment & Emblem */}
              <svg
                className="w-10 h-10 text-cyan-300 drop-shadow-[0_0_8px_rgba(56,189,248,0.5)]"
                viewBox="0 0 48 48"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M24 7L8 16H40L24 7Z" />
                <line x1="9" y1="18" x2="39" y2="18" />
                <line x1="13" y1="21" x2="13" y2="33" />
                <line x1="20" y1="21" x2="20" y2="33" />
                <line x1="28" y1="21" x2="28" y2="33" />
                <line x1="35" y1="21" x2="35" y2="33" />
                <rect x="8" y="34" width="32" height="4" rx="1" />
              </svg>
            </div>
          </div>

          <h2 className="mt-4 text-xl font-bold text-white tracking-wide">
            Welcome Back
          </h2>
          <p className="text-xs text-blue-200/70 text-center mt-1 max-w-[280px]">
            Sign in to access your personalized government scheme advisor.
          </p>
        </div>

        {/* General Authentication Error */}
        {generalError && (
          <div className="mb-4 p-3 rounded-lg bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-center gap-2 relative z-10">
            <ShieldAlert className="w-4 h-4 text-red-400 flex-shrink-0" />
            <span className="leading-tight">{generalError}</span>
          </div>
        )}

        {/* Form Fields */}
        <form onSubmit={handleSubmit} noValidate className="space-y-4 relative z-10">
          {/* Email Address Field */}
          <div>
            <label htmlFor="login-email" className="block text-xs font-semibold text-blue-200/90 mb-1.5 pl-0.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-blue-300/80 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none z-10" />
              <input
                id="login-email"
                name="username"
                type="email"
                autoComplete="username"
                value={email}
                onChange={handleEmailChange}
                onBlur={() => handleBlur('email')}
                placeholder="Enter your email address"
                disabled={isLoading}
                className={`auth-input pl-10.5 pr-4 py-3 text-sm ${
                  errors.email ? 'border-red-400/80 shadow-[0_0_12px_rgba(248,113,113,0.3)]' : ''
                }`}
              />
            </div>
            {errors.email && (
              <p className="mt-1 text-xs text-red-300 font-medium pl-1">{errors.email}</p>
            )}
          </div>

          {/* Password Field */}
          <div>
            <label htmlFor="login-password" className="block text-xs font-semibold text-blue-200/90 mb-1.5 pl-0.5">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-blue-300/80 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none z-10" />
              <input
                id="login-password"
                name="password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                value={password}
                onChange={handlePasswordChange}
                onBlur={() => handleBlur('password')}
                placeholder="Enter your password"
                disabled={isLoading}
                className={`auth-input pl-10.5 pr-11 py-3 text-sm tracking-wider ${
                  errors.password ? 'border-red-400/80 shadow-[0_0_12px_rgba(248,113,113,0.3)]' : ''
                }`}
              />
              <button
                type="button"
                tabIndex={-1}
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-blue-300/60 hover:text-cyan-300 focus:outline-none cursor-pointer z-10"
                title={showPassword ? 'Hide password' : 'Show password'}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {errors.password && (
              <p className="mt-1 text-xs text-red-300 font-medium pl-1">{errors.password}</p>
            )}
          </div>

          {/* Remember me & Forgot Password */}
          <div className="flex items-center justify-between text-xs pt-0.5 text-blue-200/80">
            <label className="flex items-center gap-2 cursor-pointer group">
              <div
                className={`w-4 h-4 rounded flex items-center justify-center transition-colors border ${
                  rememberMe
                    ? 'bg-blue-600 border-cyan-400/80 text-white'
                    : 'bg-blue-950/70 border-blue-400/30 group-hover:border-cyan-400'
                }`}
                onClick={() => setRememberMe(!rememberMe)}
              >
                {rememberMe && <Check className="w-3 h-3 stroke-[3]" />}
              </div>
              <span className="group-hover:text-white transition-colors">Remember me</span>
            </label>

            <button
              type="button"
              onClick={onNavigateToForgotPassword}
              className="text-cyan-300/90 hover:text-white transition-colors hover:underline cursor-pointer"
            >
              Forgot Password?
            </button>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full neon-btn py-3 px-4 rounded-md text-white font-bold tracking-widest text-sm flex items-center justify-center gap-2 cursor-pointer mt-5 uppercase"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-white" />
                <span>AUTHENTICATING...</span>
              </>
            ) : (
              <span>LOGIN</span>
            )}
          </button>
        </form>

        {/* Alternative Actions */}
        <div className="mt-5 pt-4 border-t border-blue-400/15 text-center">
          <p className="text-xs text-blue-200/70">
            Don&apos;t have an account?{' '}
            <button
              type="button"
              onClick={onNavigateToRegister}
              className="text-cyan-300 font-semibold hover:text-white hover:underline cursor-pointer ml-1"
            >
              Create Account
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};
