import React, { useState, useMemo, useRef } from 'react';
import {
  ShieldAlert,
  Database,
  Building2,
  Clock,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Upload,
  Download,
  Plus,
  Search,
  Filter,
  ArrowLeft,
  FileCode,
  Sparkles,
  ExternalLink,
  Edit2,
  Power,
  RotateCcw,
  Check,
  X,
  Layers,
  Info,
  ShieldCheck,
  Landmark,
} from 'lucide-react';
import { GovernmentScheme, SchemeCategory, GovernmentLevel } from '../../types';
import {
  loadAllGovernmentSchemes,
  getDatasetMetadata,
  importGovernmentSchemes,
  resetToOfficialDatabase,
  exportSchemesAsJSON,
  toggleSchemeActiveStatus,
  addOrUpdateScheme,
  checkDataQuality,
  findDuplicateSchemes,
  deduplicateSchemes,
} from '../../services/schemeDatabaseService';

interface AdminSchemesViewProps {
  onBackToCitizenPortal: () => void;
}

const CATEGORIES: SchemeCategory[] = [
  'Education',
  'Financial Assistance',
  'Employment',
  'Agriculture',
  'Housing',
  'Health',
  'Social Welfare',
  'Women & Child Development',
  'Skill Development',
  'Pension & Senior Citizen',
  'Other',
];

export const AdminSchemesView: React.FC<AdminSchemesViewProps> = ({ onBackToCitizenPortal }) => {
  const [activeTab, setActiveTab] = useState<'inventory' | 'import' | 'audit' | 'maintenance'>('inventory');
  const [refreshKey, setRefreshKey] = useState(0);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<'All' | 'Central' | 'State'>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Deactivated'>('All');

  // Edit / Add Scheme Modal
  const [editingScheme, setEditingScheme] = useState<Partial<GovernmentScheme> | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  // Import State
  const [jsonInput, setJsonInput] = useState('');
  const [isProcessingImport, setIsProcessingImport] = useState(false);
  const [importResult, setImportResult] = useState<any | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Maintenance & Audit
  const [auditMessage, setAuditMessage] = useState<string | null>(null);

  // Load live scheme dataset & metadata
  const schemes = useMemo(() => {
    return loadAllGovernmentSchemes();
  }, [refreshKey]);

  const metadata = useMemo(() => {
    return getDatasetMetadata();
  }, [refreshKey, schemes]);

  const qualityReport = useMemo(() => {
    return checkDataQuality();
  }, [schemes]);

  const duplicateReport = useMemo(() => {
    return findDuplicateSchemes();
  }, [schemes]);

  const activeCount = useMemo(() => schemes.filter((s) => s.activeStatus !== false).length, [schemes]);
  const deactivatedCount = schemes.length - activeCount;

  // Filtered scheme records
  const filteredSchemes = useMemo(() => {
    return schemes.filter((s) => {
      if (selectedLevel === 'Central' && s.governmentLevel !== 'Central') return false;
      if (selectedLevel === 'State' && s.governmentLevel !== 'State' && s.governmentLevel !== 'UT') return false;

      const isActive = s.activeStatus !== false;
      if (statusFilter === 'Active' && !isActive) return false;
      if (statusFilter === 'Deactivated' && isActive) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = (s.schemeName || s.name || '').toLowerCase().includes(q);
        const matchDept = (s.department || '').toLowerCase().includes(q);
        const matchState = (s.state || '').toLowerCase().includes(q);
        const matchCat = (s.category || '').toLowerCase().includes(q);
        if (!matchName && !matchDept && !matchState && !matchCat) return false;
      }

      return true;
    });
  }, [schemes, selectedLevel, statusFilter, searchQuery]);

  // Handle status toggle
  const handleToggleStatus = (id: string, currentActive: boolean) => {
    const success = toggleSchemeActiveStatus(id, !currentActive);
    if (success) {
      setRefreshKey((k) => k + 1);
    }
  };

  // Handle import via file
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingImport(true);
    setImportResult(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const res = importGovernmentSchemes(text);
        setImportResult(res);
        if (res.success) {
          setRefreshKey((k) => k + 1);
        }
      } catch (err) {
        setImportResult({
          success: false,
          importedCount: 0,
          skippedCount: 0,
          errors: ['Failed to read dataset file: ' + (err as Error).message],
          totalDatabaseCount: metadata.totalSchemesCount,
        });
      } finally {
        setIsProcessingImport(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  // Handle import via paste
  const handleJsonPaste = (e: React.FormEvent) => {
    e.preventDefault();
    if (!jsonInput.trim()) return;

    setIsProcessingImport(true);
    setImportResult(null);

    try {
      const res = importGovernmentSchemes(jsonInput);
      setImportResult(res);
      if (res.success) {
        setRefreshKey((k) => k + 1);
        setJsonInput('');
      }
    } catch (err) {
      setImportResult({
        success: false,
        importedCount: 0,
        skippedCount: 0,
        errors: ['Import parsing error: ' + (err as Error).message],
        totalDatabaseCount: metadata.totalSchemesCount,
      });
    } finally {
      setIsProcessingImport(false);
    }
  };

  // Handle saving scheme (Add or Edit)
  const handleSaveScheme = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingScheme) return;

    setFormError(null);
    setFormSuccess(null);

    const res = addOrUpdateScheme(editingScheme);
    if (!res.success) {
      setFormError(res.error || 'Failed to save scheme. Please check required fields.');
      return;
    }

    setFormSuccess(isAddingNew ? 'Verified scheme successfully created!' : 'Scheme record updated successfully!');
    setRefreshKey((k) => k + 1);

    setTimeout(() => {
      setEditingScheme(null);
      setIsAddingNew(false);
      setFormSuccess(null);
    }, 900);
  };

  // Handle Deduplicate
  const handleResolveDuplicates = () => {
    const res = deduplicateSchemes();
    setAuditMessage(`Deduplication completed: Removed ${res.removedCount} duplicate records. ${res.remainingCount} unique schemes maintained.`);
    setRefreshKey((k) => k + 1);
  };

  // Handle Export
  const handleDownloadDataset = () => {
    const jsonStr = exportSchemesAsJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `government_schemes_verified_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Handle Reset
  const handleResetToBaseline = () => {
    if (window.confirm('Reset database to the official verified baseline snapshot? Any uncommitted local overrides will be cleared.')) {
      const count = resetToOfficialDatabase();
      setAuditMessage(`Database reset to verified snapshot (${count} schemes active).`);
      setRefreshKey((k) => k + 1);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans flex flex-col">
      {/* Top Admin Header */}
      <header className="bg-slate-950 border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-600/20 text-cyan-400 border border-blue-500/30">
              <Landmark className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  National Scheme Registry • Data Admin
                </h1>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  /admin/schemes
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Data pipeline, verified dataset ingestion, quality auditing & scheme deactivation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBackToCitizenPortal}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Return to Citizen Advisor</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Admin Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Dynamic Metric Status Cards */}
        <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3.5 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Total Indexed
            </span>
            <div className="text-2xl font-black text-cyan-300">
              {metadata.totalSchemesCount.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-400">Government schemes</p>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3.5 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Active Status
            </span>
            <div className="text-2xl font-black text-emerald-400">
              {activeCount}
            </div>
            <p className="text-[11px] text-slate-400">Available to citizens</p>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3.5 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Deactivated
            </span>
            <div className={`text-2xl font-black ${deactivatedCount > 0 ? 'text-amber-400' : 'text-slate-500'}`}>
              {deactivatedCount}
            </div>
            <p className="text-[11px] text-slate-400">Hidden from citizens</p>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3.5 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Central Programs
            </span>
            <div className="text-2xl font-black text-blue-300">
              {metadata.centralSchemesCount}
            </div>
            <p className="text-[11px] text-slate-400">Central Ministries</p>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3.5 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              State / UT
            </span>
            <div className="text-2xl font-black text-indigo-300">
              {metadata.stateSchemesCount}
            </div>
            <p className="text-[11px] text-slate-400">State Governments</p>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3.5 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Quality Score
            </span>
            <div className="text-2xl font-black text-emerald-400">
              {qualityReport.score}%
            </div>
            <p className="text-[11px] text-slate-400">Completeness check</p>
          </div>
        </section>

        {/* Global Alert / Audit Message if any */}
        {auditMessage && (
          <div className="p-3.5 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-200 text-xs flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
              <span>{auditMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setAuditMessage(null)}
              className="text-cyan-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Admin Navigation Tabs */}
        <div className="border-b border-slate-800 flex items-center gap-4 sm:gap-8 overflow-x-auto no-scrollbar">
          {[
            { id: 'inventory', label: 'Scheme Inventory & Records', count: schemes.length },
            { id: 'import', label: 'Dataset Ingestion Pipeline' },
            { id: 'audit', label: 'Data Quality & Duplicate Audit', badge: duplicateReport.duplicates.length > 0 ? `${duplicateReport.duplicates.length} duplicate` : undefined },
            { id: 'maintenance', label: 'Export & Baseline Maintenance' },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 text-sm font-semibold whitespace-nowrap border-b-2 transition-colors cursor-pointer flex items-center gap-2 ${
                  isActive
                    ? 'border-cyan-400 text-cyan-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${isActive ? 'bg-cyan-500/20 text-cyan-200' : 'bg-slate-800 text-slate-400'}`}>
                    {tab.count}
                  </span>
                )}
                {tab.badge && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* TAB 1: SCHEME INVENTORY */}
        {activeTab === 'inventory' && (
          <section className="space-y-4">
            {/* Toolbar */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              <div className="flex-1 relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search scheme name, ministry, department, state..."
                  className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs placeholder:text-slate-500 focus:outline-hidden focus:border-cyan-400"
                />
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <select
                  value={selectedLevel}
                  onChange={(e) => setSelectedLevel(e.target.value as any)}
                  className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 text-xs focus:outline-hidden focus:border-cyan-400"
                >
                  <option value="All">All Levels</option>
                  <option value="Central">Central Govt</option>
                  <option value="State">State / UT</option>
                </select>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 text-xs focus:outline-hidden focus:border-cyan-400"
                >
                  <option value="All">All Statuses</option>
                  <option value="Active">Active Only</option>
                  <option value="Deactivated">Deactivated Only</option>
                </select>

                <button
                  type="button"
                  onClick={() => {
                    setIsAddingNew(true);
                    setEditingScheme({
                      id: `scheme-verified-${Date.now()}`,
                      name: '',
                      schemeName: '',
                      shortDescription: '',
                      detailedDescription: '',
                      department: '',
                      ministry: '',
                      governmentLevel: 'Central',
                      state: 'All',
                      category: 'Social Welfare',
                      benefits: [''],
                      eligibilityCriteria: [''],
                      officialUrl: 'https://',
                      sourceUrl: 'https://',
                      activeStatus: true,
                      isVerifiedOfficial: true,
                    });
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-colors shadow-xs cursor-pointer ml-auto"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Verified Scheme</span>
                </button>
              </div>
            </div>

            {/* Scheme Table */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950/80 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Scheme Name & Ministry</th>
                      <th className="py-3 px-4">Level & State</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Last Updated</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {filteredSchemes.map((s) => {
                      const isActive = s.activeStatus !== false;
                      return (
                        <tr key={s.id} className="hover:bg-slate-800/50 transition-colors">
                          <td className="py-3.5 px-4">
                            <div className="font-bold text-white text-sm">
                              {s.schemeName || s.name}
                            </div>
                            <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2">
                              <span>{s.department || s.ministry || 'Government Department'}</span>
                              <span className="text-slate-600">•</span>
                              <code className="text-[10px] text-cyan-300/80">{s.id}</code>
                            </div>
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                              s.governmentLevel === 'Central' ? 'bg-blue-900/40 text-blue-300 border border-blue-700/40' : 'bg-indigo-900/40 text-indigo-300 border border-indigo-700/40'
                            }`}>
                              {s.governmentLevel || 'Central'}
                            </span>
                            <div className="text-[11px] text-slate-400 mt-0.5">
                              {s.state || 'All States'}
                            </div>
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <span className="text-slate-300 font-medium">
                              {s.category}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              isActive
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : 'bg-red-500/20 text-red-300 border border-red-500/30'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-emerald-400' : 'bg-red-400'}`} />
                              <span>{isActive ? 'Active' : 'Deactivated'}</span>
                            </span>
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap text-slate-400">
                            {s.lastUpdated || '28 Sep 2026'}
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap text-right space-x-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setIsAddingNew(false);
                                setEditingScheme({ ...s });
                              }}
                              className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 font-semibold text-xs transition-colors cursor-pointer inline-flex items-center gap-1"
                              title="Edit Scheme Record"
                            >
                              <Edit2 className="w-3 h-3 text-cyan-400" />
                              <span>Edit</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleToggleStatus(s.id, isActive)}
                              className={`px-2.5 py-1 rounded font-semibold text-xs transition-colors cursor-pointer inline-flex items-center gap-1 ${
                                isActive
                                  ? 'bg-amber-900/30 hover:bg-amber-900/50 text-amber-300 border border-amber-700/40'
                                  : 'bg-emerald-900/30 hover:bg-emerald-900/50 text-emerald-300 border border-emerald-700/40'
                              }`}
                              title={isActive ? 'Deactivate (Hide from Citizens)' : 'Activate (Show to Citizens)'}
                            >
                              <Power className="w-3 h-3" />
                              <span>{isActive ? 'Deactivate' : 'Activate'}</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {filteredSchemes.length === 0 && (
                <div className="py-12 text-center text-slate-400">
                  <Database className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                  <p className="font-semibold text-slate-300">No schemes match the selected filters</p>
                  <p className="text-xs text-slate-500 mt-1">Try broadening your search query or status filter.</p>
                </div>
              )}
            </div>
          </section>
        )}

        {/* TAB 2: DATASET INGESTION */}
        {activeTab === 'import' && (
          <section className="space-y-6">
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-cyan-600/20 text-cyan-300 border border-cyan-500/30">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">
                    Verified Scheme Dataset Ingestion Pipeline
                  </h2>
                  <p className="text-xs text-slate-400">
                    Ingest authentic government schemes with automated schema validation and strict anti-fabrication rejection.
                  </p>
                </div>
              </div>

              {/* Upload Dropzone */}
              <div className="border-2 border-dashed border-slate-700 hover:border-cyan-500/60 rounded-xl p-8 text-center transition-colors bg-slate-900/50">
                <FileCode className="w-10 h-10 text-cyan-400 mx-auto mb-3" />
                <h3 className="font-bold text-white text-sm mb-1">
                  Upload Official Dataset File (.json)
                </h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto mb-4">
                  Accepts machine-readable JSON array of government scheme records. Supports large datasets up to 5,000+ schemes.
                </p>

                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".json,application/json"
                  className="hidden"
                  id="admin-dataset-file"
                />

                <label
                  htmlFor="admin-dataset-file"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Choose JSON File</span>
                </label>
              </div>

              {/* Paste JSON Form */}
              <form onSubmit={handleJsonPaste} className="space-y-3 pt-4 border-t border-slate-700/80">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300">
                    Or Paste Raw JSON Array
                  </label>
                  <span className="text-[11px] text-slate-500">
                    Auto-validates required government fields
                  </span>
                </div>
                <textarea
                  rows={6}
                  value={jsonInput}
                  onChange={(e) => setJsonInput(e.target.value)}
                  placeholder={`[\n  {\n    "id": "pm-kisan-2026",\n    "schemeName": "Pradhan Mantri Kisan Samman Nidhi",\n    "department": "Department of Agriculture and Farmers Welfare",\n    "governmentLevel": "Central",\n    "benefits": ["Financial benefit of ₹6,000 per year in three 4-monthly installments"],\n    "officialUrl": "https://pmkisan.gov.in",\n    "sourceUrl": "https://www.myscheme.gov.in/schemes/pm-kisan"\n  }\n]`}
                  className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-cyan-200 focus:outline-hidden focus:border-cyan-400"
                />

                <div className="flex items-center justify-end gap-3">
                  <button
                    type="submit"
                    disabled={isProcessingImport || !jsonInput.trim()}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isProcessingImport ? 'Validating & Ingesting...' : 'Validate & Ingest Dataset'}</span>
                  </button>
                </div>
              </form>

              {/* Import Result Notification */}
              {importResult && (
                <div className={`p-4 rounded-xl border ${importResult.success ? 'bg-emerald-950/40 border-emerald-500/40' : 'bg-red-950/40 border-red-500/40'}`}>
                  <div className="flex items-center gap-2 mb-2 font-bold text-sm">
                    {importResult.success ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span className="text-emerald-300">Ingestion Successful</span>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-4 h-4 text-red-400" />
                        <span className="text-red-300">Ingestion Failed or Had Validation Errors</span>
                      </>
                    )}
                  </div>

                  <div className="text-xs space-y-1 text-slate-300">
                    <p>• Successfully Ingested: <strong className="text-white">{importResult.importedCount}</strong> schemes</p>
                    <p>• Skipped / Invalid: <strong className="text-white">{importResult.skippedCount}</strong> schemes</p>
                    <p>• Total Schemes Now Indexed: <strong className="text-white">{importResult.totalDatabaseCount}</strong></p>

                    {importResult.errors && importResult.errors.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-slate-700">
                        <span className="font-semibold text-amber-300 block mb-1">Validation Warnings / Rejections:</span>
                        <ul className="list-disc pl-4 space-y-0.5 text-slate-400 text-[11px]">
                          {importResult.errors.map((err: string, i: number) => (
                            <li key={i}>{err}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </section>
        )}

        {/* TAB 3: AUDIT & DUPLICATES */}
        {activeTab === 'audit' && (
          <section className="space-y-6">
            {/* Duplicates Section */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-white flex items-center gap-2">
                    <ShieldAlert className="w-5 h-5 text-amber-400" />
                    <span>Duplicate Scheme Detection</span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Ensures every government scheme program has an authoritative unique record in the database.
                  </p>
                </div>

                {duplicateReport.duplicates.length > 0 && (
                  <button
                    type="button"
                    onClick={handleResolveDuplicates}
                    className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                  >
                    1-Click Resolve & Deduplicate
                  </button>
                )}
              </div>

              {duplicateReport.duplicates.length === 0 ? (
                <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                  <div className="text-xs">
                    <span className="font-bold text-emerald-300 block">No duplicate schemes detected</span>
                    <span className="text-slate-400">All {schemes.length} scheme records maintain unique identity and naming standards.</span>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-xs text-amber-300 font-semibold">
                    Found {duplicateReport.duplicates.length} scheme names with multiple entries:
                  </p>
                  <div className="divide-y divide-slate-700 border border-slate-700 rounded-xl overflow-hidden">
                    {duplicateReport.duplicates.map((dup, i) => (
                      <div key={i} className="p-3 bg-slate-900/60 flex items-center justify-between text-xs">
                        <div>
                          <strong className="text-white">{dup.name}</strong>
                          <span className="text-slate-400 ml-2">({dup.count} duplicate records)</span>
                        </div>
                        <code className="text-[10px] text-cyan-300 font-mono">
                          {dup.ids.join(', ')}
                        </code>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Quality Report Section */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-white flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    <span>Data Quality & Completeness Audit</span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Checks for complete descriptions, official URLs, benefits, and departmental attribution.
                  </p>
                </div>
                <div className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-700 text-xs font-bold text-emerald-300">
                  {qualityReport.score}% Health Rating
                </div>
              </div>

              {qualityReport.issues.length === 0 ? (
                <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-xs text-emerald-300">
                  ✓ Perfect completeness: All {schemes.length} schemes have verified departments, URLs, and benefits.
                </div>
              ) : (
                <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                  <div className="text-xs text-slate-400 mb-2">
                    Flagged {qualityReport.issues.length} records needing review:
                  </div>
                  {qualityReport.issues.map((iss, i) => (
                    <div key={i} className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-semibold text-white">{iss.name}</span>
                        <span className="text-slate-400 ml-2">— {iss.issue}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        iss.severity === 'high' ? 'bg-red-500/20 text-red-300' : 'bg-amber-500/20 text-amber-300'
                      }`}>
                        {iss.severity}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        {/* TAB 4: MAINTENANCE & BACKUP */}
        {activeTab === 'maintenance' && (
          <section className="space-y-6">
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 space-y-6">
              <div>
                <h2 className="text-base font-bold text-white">
                  Scheme Registry Maintenance & Snapshot Export
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Export complete snapshots or reset database state to verified baseline.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-700 space-y-3">
                  <Download className="w-6 h-6 text-cyan-400" />
                  <h3 className="font-bold text-white text-sm">Export Full JSON Dataset</h3>
                  <p className="text-xs text-slate-400">
                    Download a standardized, machine-readable JSON file containing all {schemes.length} indexed schemes.
                  </p>
                  <button
                    type="button"
                    onClick={handleDownloadDataset}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download JSON Snapshot</span>
                  </button>
                </div>

                <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-700 space-y-3">
                  <RotateCcw className="w-6 h-6 text-amber-400" />
                  <h3 className="font-bold text-white text-sm">Reset to Official Baseline</h3>
                  <p className="text-xs text-slate-400">
                    Clears unverified custom imports and overrides, restoring the authoritative verified baseline dataset.
                  </p>
                  <button
                    type="button"
                    onClick={handleResetToBaseline}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold text-xs transition-colors cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Restore Baseline Snapshot</span>
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Add / Edit Scheme Modal */}
      {editingScheme && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs"
        >
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-white text-base">
                  {isAddingNew ? 'Add Verified Government Scheme' : 'Edit Scheme Record'}
                </h3>
                <p className="text-xs text-slate-400">
                  Only authentic, non-placeholder government schemes may be saved.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditingScheme(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveScheme} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
              {formError && (
                <div className="p-3 rounded-xl bg-red-950/50 border border-red-500/40 text-red-300">
                  {formError}
                </div>
              )}
              {formSuccess && (
                <div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300">
                  {formSuccess}
                </div>
              )}

              <div className="space-y-1">
                <label className="font-bold text-slate-300 block">Scheme Name *</label>
                <input
                  type="text"
                  required
                  value={editingScheme.schemeName || editingScheme.name || ''}
                  onChange={(e) => setEditingScheme({ ...editingScheme, schemeName: e.target.value, name: e.target.value })}
                  placeholder="e.g. Pradhan Mantri Awas Yojana"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-hidden focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">Government Level *</label>
                  <select
                    value={editingScheme.governmentLevel || 'Central'}
                    onChange={(e) => setEditingScheme({ ...editingScheme, governmentLevel: e.target.value as GovernmentLevel })}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-hidden focus:border-cyan-400"
                  >
                    <option value="Central">Central Government</option>
                    <option value="State">State Government</option>
                    <option value="UT">Union Territory</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">State / Jurisdiction</label>
                  <input
                    type="text"
                    value={editingScheme.state || ''}
                    onChange={(e) => setEditingScheme({ ...editingScheme, state: e.target.value })}
                    placeholder="All (for Central) or state name"
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-hidden focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">Department / Ministry *</label>
                  <input
                    type="text"
                    required
                    value={editingScheme.department || ''}
                    onChange={(e) => setEditingScheme({ ...editingScheme, department: e.target.value, ministry: e.target.value })}
                    placeholder="e.g. Ministry of Housing and Urban Affairs"
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-hidden focus:border-cyan-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">Category *</label>
                  <select
                    value={editingScheme.category || 'Social Welfare'}
                    onChange={(e) => setEditingScheme({ ...editingScheme, category: e.target.value as SchemeCategory })}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-hidden focus:border-cyan-400"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-300 block">Short Description</label>
                <textarea
                  rows={2}
                  value={editingScheme.shortDescription || editingScheme.description || ''}
                  onChange={(e) => setEditingScheme({ ...editingScheme, shortDescription: e.target.value, description: e.target.value })}
                  placeholder="Summary of the welfare program"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-hidden focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">Official Website URL</label>
                  <input
                    type="url"
                    value={editingScheme.officialUrl || ''}
                    onChange={(e) => setEditingScheme({ ...editingScheme, officialUrl: e.target.value })}
                    placeholder="https://..."
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-hidden focus:border-cyan-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">Source Reference URL</label>
                  <input
                    type="url"
                    value={editingScheme.sourceUrl || ''}
                    onChange={(e) => setEditingScheme({ ...editingScheme, sourceUrl: e.target.value })}
                    placeholder="https://www.myscheme.gov.in/..."
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-hidden focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="active-status-cb"
                  checked={editingScheme.activeStatus !== false}
                  onChange={(e) => setEditingScheme({ ...editingScheme, activeStatus: e.target.checked })}
                  className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-400 bg-slate-950 border-slate-700"
                />
                <label htmlFor="active-status-cb" className="text-slate-300 font-semibold cursor-pointer">
                  Active in citizen eligibility assessments
                </label>
              </div>

              <div className="p-4 border-t border-slate-800 flex items-center justify-end gap-3 mt-4">
                <button
                  type="button"
                  onClick={() => setEditingScheme(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold transition-colors cursor-pointer"
                >
                  {isAddingNew ? 'Create Scheme Record' : 'Save Record Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
