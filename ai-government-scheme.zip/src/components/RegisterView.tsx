import React, { useState } from 'react';
import { ArrowLeft, Mail, Lock, User, CheckCircle2, Loader2, Eye, EyeOff, ShieldAlert } from 'lucide-react';
import { ValidationErrors } from '../types';
import { registerUserAccount } from '../services/userService';

interface RegisterViewProps {
  onBackToLogin: () => void;
  onRegisterSuccess: (email: string) => void;
}

export const RegisterView: React.FC<RegisterViewProps> = ({
  onBackToLogin,
  onRegisterSuccess,
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeneralError(null);
    const newErrors: ValidationErrors = {};

    if (!fullName.trim()) {
      newErrors.fullName = 'Full legal name is required.';
    }
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!email.trim() || !emailPattern.test(email.trim())) {
      newErrors.email = 'Please enter a valid official citizen email address.';
    }
    if (!password || password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters.';
    }
    if (confirmPassword !== password) {
      newErrors.confirmPassword = 'Passwords do not match.';
    }
    if (!agreeTerms) {
      newErrors.terms = 'You must agree to the data protection guidelines.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsLoading(true);

    try {
      const res = await registerUserAccount(email, fullName, password);
      if (!res.success) {
        setIsLoading(false);
        setGeneralError(res.error || 'Registration failed. Please check your information.');
        return;
      }

      setIsLoading(false);
      setSubmitted(true);
    } catch {
      setIsLoading(false);
      setGeneralError('Registration service is temporarily unavailable. Please try again.');
    }
  };

  return (
    <div className="relative w-full max-w-[440px] mx-auto">
      {/* Specular Edge Glows */}
      <div
        className="absolute -left-[3px] top-1/4 w-[4px] h-20 bg-cyan-300 rounded-full blur-[3px] opacity-75 pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute -right-[3px] top-1/2 w-[4px] h-20 bg-cyan-400 rounded-full blur-[3px] opacity-75 pointer-events-none"
        aria-hidden="true"
      />

      <button
        type="button"
        onClick={onBackToLogin}
        className="inline-flex items-center gap-1.5 text-xs font-medium text-cyan-300 hover:text-white mb-4 cursor-pointer transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Sign In</span>
      </button>

      <div className="glass-card rounded-[32px] p-6 sm:p-8 relative">
        {/* Subtle interior glow housed in an overflow-hidden layer so popup bounds aren't clipped */}
        <div className="absolute inset-0 rounded-[32px] overflow-hidden pointer-events-none" aria-hidden="true">
          <div className="absolute -top-16 -right-16 w-48 h-48 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-16 -left-16 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        </div>

        {submitted ? (
          <div className="text-center py-6 relative z-10">
            <div className="w-14 h-14 rounded-full border border-cyan-400/50 bg-cyan-950/40 text-cyan-300 flex items-center justify-center mx-auto mb-4 shadow-[0_0_20px_rgba(34,211,238,0.3)]">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">
              Registration Received
            </h2>
            <p className="text-xs text-blue-200/80 max-w-sm mx-auto mb-6 leading-relaxed">
              An activation link has been sent to <strong className="text-cyan-300">{email}</strong>. Please confirm your email to complete citizen onboarding.
            </p>
            <button
              type="button"
              onClick={onBackToLogin}
              className="w-full neon-btn py-2.5 px-4 rounded-md text-white font-bold tracking-wider text-xs uppercase cursor-pointer"
            >
              Proceed to Sign In
            </button>
          </div>
        ) : (
          <div className="relative z-10">
            <div className="text-center mb-6">
              <h1 className="text-2xl font-bold text-white tracking-wide">
                Create Account
              </h1>
              <p className="text-xs text-blue-200/70 mt-1">
                Register to track applications and access personalized schemes.
              </p>
            </div>

            {generalError && (
              <div className="mb-4 p-3 rounded-lg bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-red-400 flex-shrink-0" />
                <span className="leading-tight">{generalError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} noValidate className="space-y-3.5">
              {/* Full Name */}
              <div>
                <label htmlFor="register-fullname" className="block text-xs font-semibold text-blue-200/90 mb-1 pl-0.5">
                  Full Legal Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-blue-300/80 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none z-10" />
                  <input
                    id="register-fullname"
                    name="name"
                    type="text"
                    autoComplete="name"
                    value={fullName}
                    onChange={(e) => {
                      setFullName(e.target.value);
                      if (errors.fullName) setErrors((prev) => ({ ...prev, fullName: undefined }));
                    }}
                    placeholder="Full Legal Name"
                    disabled={isLoading}
                    className={`auth-input pl-10.5 pr-4 py-2.5 text-xs sm:text-sm ${
                      errors.fullName ? 'border-red-400/80 shadow-[0_0_12px_rgba(248,113,113,0.3)]' : ''
                    }`}
                  />
                </div>
                {errors.fullName && (
                  <p className="mt-1 text-xs text-red-300 pl-1">{errors.fullName}</p>
                )}
              </div>

              {/* Email Address */}
              <div>
                <label htmlFor="register-email" className="block text-xs font-semibold text-blue-200/90 mb-1 pl-0.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-blue-300/80 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none z-10" />
                  <input
                    id="register-email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
                    }}
                    placeholder="citizen@example.gov"
                    disabled={isLoading}
                    className={`auth-input pl-10.5 pr-4 py-2.5 text-xs sm:text-sm ${
                      errors.email ? 'border-red-400/80 shadow-[0_0_12px_rgba(248,113,113,0.3)]' : ''
                    }`}
                  />
                </div>
                {errors.email && (
                  <p className="mt-1 text-xs text-red-300 pl-1">{errors.email}</p>
                )}
              </div>

              {/* Password */}
              <div>
                <label htmlFor="register-password" className="block text-xs font-semibold text-blue-200/90 mb-1 pl-0.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-blue-300/80 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none z-10" />
                  <input
                    id="register-password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="new-password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (errors.password) setErrors((prev) => ({ ...prev, password: undefined }));
                    }}
                    placeholder="Password (minimum 8 characters)"
                    disabled={isLoading}
                    className={`auth-input pl-10.5 pr-10 py-2.5 text-xs sm:text-sm tracking-wider ${
                      errors.password ? 'border-red-400/80 shadow-[0_0_12px_rgba(248,113,113,0.3)]' : ''
                    }`}
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-blue-300/60 hover:text-cyan-300 cursor-pointer focus:outline-none z-10"
                    title={showPassword ? 'Hide password' : 'Show password'}
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
                {errors.password && (
                  <p className="mt-1 text-xs text-red-300 pl-1">{errors.password}</p>
                )}
              </div>

              {/* Confirm Password */}
              <div>
                <label htmlFor="register-confirm-password" className="block text-xs font-semibold text-blue-200/90 mb-1 pl-0.5">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-blue-300/80 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none z-10" />
                  <input
                    id="register-confirm-password"
                    name="confirmPassword"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="new-password"
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      if (errors.confirmPassword) setErrors((prev) => ({ ...prev, confirmPassword: undefined }));
                    }}
                    placeholder="Confirm Password"
                    disabled={isLoading}
                    className={`auth-input pl-10.5 pr-4 py-2.5 text-xs sm:text-sm tracking-wider ${
                      errors.confirmPassword ? 'border-red-400/80 shadow-[0_0_12px_rgba(248,113,113,0.3)]' : ''
                    }`}
                  />
                </div>
                {errors.confirmPassword && (
                  <p className="mt-1 text-xs text-red-300 pl-1">{errors.confirmPassword}</p>
                )}
              </div>

              {/* Terms Checkbox */}
              <div className="pt-1">
                <label className="flex items-start gap-2.5 cursor-pointer text-xs text-blue-200/80">
                  <input
                    type="checkbox"
                    checked={agreeTerms}
                    onChange={(e) => setAgreeTerms(e.target.checked)}
                    className="mt-0.5 rounded border-blue-400/40 text-blue-600 focus:ring-0 cursor-pointer"
                  />
                  <span>
                    I accept the Public Service Data Protection Charter.
                  </span>
                </label>
                {errors.terms && (
                  <p className="mt-1 text-xs text-red-300 pl-1">{errors.terms}</p>
                )}
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full neon-btn py-3 px-4 rounded-md text-white font-bold tracking-widest text-xs uppercase flex items-center justify-center gap-2 cursor-pointer mt-4"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>CREATING CITIZEN ACCOUNT...</span>
                  </>
                ) : (
                  <span>REGISTER</span>
                )}
              </button>
            </form>

            <div className="mt-5 pt-4 border-t border-blue-400/15 text-center text-xs text-blue-200/70">
              Already have an account?{' '}
              <button
                type="button"
                onClick={onBackToLogin}
                className="text-cyan-300 font-semibold hover:text-white hover:underline cursor-pointer ml-1"
              >
                Sign In
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

