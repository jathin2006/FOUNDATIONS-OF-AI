import React from 'react';
import { Lock, PhoneCall, ShieldCheck } from 'lucide-react';

interface OfficialHeaderProps {
  onContactClick: () => void;
  onResetView?: () => void;
}

export const OfficialHeader: React.FC<OfficialHeaderProps> = ({
  onContactClick,
  onResetView,
}) => {
  return (
    <header className="border-b border-cyan-500/20 bg-blue-950/40 backdrop-blur-md text-white sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-3.5">
        <div className="flex items-center justify-between">
          {/* Logo and Title */}
          <button
            type="button"
            onClick={onResetView}
            className="flex items-center gap-3 text-left group cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded-lg p-1 -m-1"
            title="Return to Government Scheme Advisor Sign In"
          >
            {/* Government Public Service Emblem */}
            <div className="w-10 h-10 rounded-full border border-cyan-400/50 bg-blue-900/60 flex items-center justify-center flex-shrink-0 shadow-[0_0_15px_rgba(56,189,248,0.25)]">
              <svg
                className="w-6 h-6 text-cyan-300"
                viewBox="0 0 40 40"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-label="Government Public Service Seal"
              >
                <path d="M20 7L7 15H33L20 7Z" fill="currentColor" />
                <rect x="8" y="16" width="24" height="2" fill="currentColor" opacity="0.9" />
                <rect x="10" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="16" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="22" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="28" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="7" y="30" width="26" height="3" rx="0.5" fill="currentColor" />
              </svg>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-base sm:text-lg font-bold tracking-wide text-white group-hover:text-cyan-300 transition-colors">
                  Government Scheme Advisor
                </span>
                <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-cyan-950/70 border border-cyan-400/30 text-cyan-300">
                  <ShieldCheck className="w-3 h-3 text-cyan-400" />
                  Official Portal
                </span>
              </div>
              <p className="text-xs text-blue-200/70 font-normal">
                Citizen Welfare & Public Assistance Portal
              </p>
            </div>
          </button>

          {/* Right Status / Helpline Info */}
          <div className="flex items-center gap-4 sm:gap-6 text-xs sm:text-sm">
            <div className="hidden md:flex items-center gap-2 text-blue-200/80">
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-blue-900/60 border border-cyan-400/20 text-cyan-300">
                <Lock className="w-3.5 h-3.5" />
              </span>
              <div className="text-left">
                <p className="text-xs font-semibold text-white">256-Bit SSL/TLS</p>
                <p className="text-[11px] text-blue-200/60">Encrypted Gateway</p>
              </div>
            </div>

            <div className="h-6 w-px bg-cyan-500/20 hidden md:block" aria-hidden="true" />

            <button
              type="button"
              onClick={onContactClick}
              className="flex items-center gap-2 text-left hover:text-cyan-300 transition-colors cursor-pointer group"
            >
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-blue-900/60 border border-cyan-400/30 text-cyan-300 group-hover:bg-blue-800/80">
                <PhoneCall className="w-3.5 h-3.5" />
              </span>
              <div>
                <p className="text-[11px] text-blue-200/60">Citizen Helpline</p>
                <p className="text-xs font-semibold text-cyan-300 group-hover:underline">
                  1800-SCHEME-GOV
                </p>
              </div>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
