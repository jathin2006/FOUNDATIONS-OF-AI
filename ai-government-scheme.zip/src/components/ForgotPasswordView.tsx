import React, { useState } from 'react';
import { ArrowLeft, Mail, CheckCircle2, Loader2, Info } from 'lucide-react';

interface ForgotPasswordViewProps {
  onBackToLogin: () => void;
}

export const ForgotPasswordView: React.FC<ForgotPasswordViewProps> = ({ onBackToLogin }) => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!email.trim()) {
      setError('Please provide your registered citizen email.');
      return;
    }

    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email.trim())) {
      setError('Please enter a valid email format.');
      return;
    }

    setError(null);
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      setIsSubmitted(true);
    }, 1200);
  };

  return (
    <div className="relative w-full max-w-[390px] mx-auto">
      {/* Specular Edge Glows */}
      <div
        className="absolute -left-[3px] top-1/3 w-[4px] h-20 bg-cyan-300 rounded-full blur-[3px] opacity-75 pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute -right-[3px] top-1/2 w-[4px] h-20 bg-cyan-400 rounded-full blur-[3px] opacity-75 pointer-events-none"
        aria-hidden="true"
      />

      <button
        type="button"
        onClick={onBackToLogin}
        className="inline-flex items-center gap-1.5 text-xs font-medium text-cyan-300 hover:text-white mb-4 cursor-pointer transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Sign In</span>
      </button>

      <div className="glass-card rounded-[32px] p-6 sm:p-8 relative">
        {/* Subtle interior glow housed in an overflow-hidden layer so popup bounds aren't clipped */}
        <div className="absolute inset-0 rounded-[32px] overflow-hidden pointer-events-none" aria-hidden="true">
          <div className="absolute -top-16 -right-16 w-48 h-48 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-16 -left-16 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        </div>

        {isSubmitted ? (
          <div className="text-center py-4 relative z-10">
            <div className="w-14 h-14 rounded-full border border-cyan-400/50 bg-cyan-950/40 text-cyan-300 flex items-center justify-center mx-auto mb-4 shadow-[0_0_20px_rgba(34,211,238,0.3)]">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="text-lg font-bold text-white mb-2">
              Recovery Link Sent
            </h2>
            <p className="text-xs text-blue-200/80 mb-5 leading-relaxed">
              If an account is associated with <strong className="text-cyan-300">{email}</strong>, a secure reset link has been dispatched.
            </p>

            <button
              type="button"
              onClick={onBackToLogin}
              className="w-full neon-btn py-2.5 px-4 rounded-md text-white font-bold tracking-wider text-xs uppercase cursor-pointer"
            >
              Return to Sign In
            </button>
          </div>
        ) : (
          <div className="relative z-10">
            <div className="text-center mb-6">
              <h1 className="text-xl font-bold text-white tracking-wide">
                Reset Password
              </h1>
              <p className="text-xs text-blue-200/70 mt-1">
                Enter your email address to receive password reset instructions.
              </p>
            </div>

            <form onSubmit={handleSubmit} noValidate className="space-y-4">
              <div>
                <label htmlFor="forgot-email" className="block text-xs font-semibold text-blue-200/90 mb-1.5 pl-0.5">
                  Citizen Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-blue-300/80 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none z-10" />
                  <input
                    id="forgot-email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="Enter your email address"
                    disabled={isLoading}
                    className={`auth-input pl-10.5 pr-4 py-3 text-sm ${
                      error ? 'border-red-400/80 shadow-[0_0_12px_rgba(248,113,113,0.3)]' : ''
                    }`}
                  />
                </div>
                {error && (
                  <p className="mt-1 text-xs text-red-300 pl-1">{error}</p>
                )}
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full neon-btn py-3 px-4 rounded-md text-white font-bold tracking-widest text-xs uppercase flex items-center justify-center gap-2 cursor-pointer mt-5"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>CHECKING EMAIL...</span>
                  </>
                ) : (
                  <span>SEND RESET LINK</span>
                )}
              </button>
            </form>

            <div className="mt-5 pt-4 border-t border-blue-400/15 text-center text-xs text-blue-200/70">
              Remember your credentials?{' '}
              <button
                type="button"
                onClick={onBackToLogin}
                className="text-cyan-300 font-semibold hover:text-white hover:underline cursor-pointer ml-1"
              >
                Sign In
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
