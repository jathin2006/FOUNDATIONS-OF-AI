import React from 'react';
import { ShieldCheck, Lock } from 'lucide-react';
import { ModalType } from '../types';

interface OfficialFooterProps {
  onOpenModal: (type: ModalType) => void;
  onOpenAdmin?: () => void;
}

export const OfficialFooter: React.FC<OfficialFooterProps> = ({ onOpenModal, onOpenAdmin }) => {
  return (
    <footer className="border-t border-cyan-500/20 bg-blue-950/30 backdrop-blur-md text-blue-200/70 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pb-4 border-b border-blue-900/30 text-center md:text-left">
          <div>
            <div className="flex items-center justify-center md:justify-start gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_6px_rgba(34,211,238,0.8)] inline-block" />
              <h2 className="text-sm sm:text-base font-bold tracking-wide text-white">
                Government Scheme Eligibility Advisor
              </h2>
            </div>
            <p className="text-xs text-blue-300/60">
              Helping citizens discover relevant government schemes.
            </p>
          </div>

          {/* Navigation Links */}
          <nav
            aria-label="Footer Navigation"
            className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs font-medium"
          >
            <button
              type="button"
              onClick={() => onOpenModal('privacy')}
              className="text-blue-200/80 hover:text-cyan-300 hover:underline cursor-pointer transition-colors"
            >
              Privacy Policy
            </button>
            <span className="text-blue-500/40" aria-hidden="true">•</span>
            <button
              type="button"
              onClick={() => onOpenModal('terms')}
              className="text-blue-200/80 hover:text-cyan-300 hover:underline cursor-pointer transition-colors"
            >
              Terms of Use
            </button>
            <span className="text-blue-500/40" aria-hidden="true">•</span>
            <button
              type="button"
              onClick={() => onOpenModal('contact')}
              className="text-blue-200/80 hover:text-cyan-300 hover:underline cursor-pointer transition-colors"
            >
              Contact
            </button>
            {onOpenAdmin && (
              <>
                <span className="text-blue-500/40" aria-hidden="true">•</span>
                <button
                  type="button"
                  onClick={onOpenAdmin}
                  className="text-blue-300/50 hover:text-cyan-300 hover:underline cursor-pointer transition-colors text-[11px]"
                  title="Administrative Scheme Registry & Dataset Management"
                >
                  Admin Portal
                </button>
              </>
            )}
          </nav>
        </div>

        {/* Bottom Attribution */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-blue-300/50">
          <p>© 2026 Public Service Information Portal. Citizen Data Protected.</p>
          <div className="flex items-center gap-2">
            <Lock className="w-3 h-3 text-cyan-400" />
            <span>256-bit TLS Encrypted Citizen Gateway</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
