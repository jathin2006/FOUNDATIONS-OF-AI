import React from 'react';
import { UserCheck, ShieldCheck, ArrowLeft, LogOut, Info } from 'lucide-react';

interface AuthStatusCardProps {
  mode: 'guest' | 'authenticated';
  userEmail?: string;
  onReturnToLogin: () => void;
  onProceedToProfile?: () => void;
}

export const AuthStatusCard: React.FC<AuthStatusCardProps> = ({
  mode,
  userEmail,
  onReturnToLogin,
  onProceedToProfile,
}) => {
  const isGuest = mode === 'guest';

  return (
    <div className="relative w-full max-w-[420px] mx-auto select-none">
      <div
        className="absolute -left-[3px] top-1/3 w-[4px] h-20 bg-cyan-300 rounded-full blur-[3px] opacity-75 pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute -right-[3px] top-1/2 w-[4px] h-20 bg-cyan-400 rounded-full blur-[3px] opacity-75 pointer-events-none"
        aria-hidden="true"
      />

      <div className="glass-card rounded-[32px] p-7 sm:p-9 backdrop-blur-2xl text-center">
        <div className="w-16 h-16 rounded-full border border-cyan-400/50 bg-cyan-950/40 text-cyan-300 flex items-center justify-center mx-auto mb-4 shadow-[0_0_20px_rgba(34,211,238,0.3)]">
          {isGuest ? <UserCheck className="w-8 h-8" /> : <ShieldCheck className="w-8 h-8" />}
        </div>

        <span className="inline-block px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-400/30 text-cyan-300 text-xs font-semibold mb-3">
          {isGuest ? 'Guest Access Granted' : 'Citizen Authenticated'}
        </span>

        <h2 className="text-xl font-bold text-white tracking-wide">
          {isGuest ? 'Public Guest Session' : 'Welcome, Citizen'}
        </h2>

        <p className="text-xs text-blue-200/80 mt-2 max-w-sm mx-auto leading-relaxed">
          {isGuest
            ? 'Browsing in guest mode. You can explore published scheme guidelines anonymously.'
            : `Signed in as ${userEmail}. Your citizen gateway connection is encrypted and active.`}
        </p>

        <div className="mt-5 p-3.5 rounded-lg bg-blue-950/60 border border-cyan-400/20 text-left text-xs text-blue-200/90 space-y-1.5">
          <div className="flex items-center gap-1.5 font-bold text-cyan-300">
            <Info className="w-4 h-4 text-cyan-400 flex-shrink-0" />
            <span>Next Phase: Scheme Eligibility Assessment</span>
          </div>
          <p className="text-[11px] text-blue-300/80 leading-normal">
            The interactive scheme questionnaire and eligibility evaluation logic will be activated in the subsequent module release.
          </p>
        </div>

        <div className="mt-6 pt-5 border-t border-blue-400/15 flex flex-col gap-2.5">
          {onProceedToProfile && (
            <button
              type="button"
              onClick={onProceedToProfile}
              className="w-full neon-btn py-3 px-4 rounded-md text-white font-bold tracking-wider text-xs uppercase flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_20px_rgba(37,117,232,0.5)]"
            >
              <span>Proceed to Profile Setup</span>
            </button>
          )}
          <button
            type="button"
            onClick={onReturnToLogin}
            className="w-full py-2.5 px-4 rounded-md border border-cyan-400/30 bg-blue-950/60 hover:bg-blue-900/60 text-cyan-200 hover:text-white font-semibold tracking-wider text-xs uppercase flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Login Screen</span>
          </button>
          <button
            type="button"
            onClick={onReturnToLogin}
            className="w-full py-2 px-3 rounded-md bg-blue-950/50 hover:bg-blue-900/60 border border-blue-400/20 text-blue-200 hover:text-white text-xs font-medium transition-colors cursor-pointer flex items-center justify-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};
