import React from 'react';
import { ShieldCheck, HelpCircle } from 'lucide-react';

interface OfficialTopBannerProps {
  fontSizeLevel?: number;
  setFontSizeLevel?: (fn: (prev: number) => number) => void;
  onOpenHelp: () => void;
}

export const OfficialTopBanner: React.FC<OfficialTopBannerProps> = ({
  onOpenHelp,
}) => {
  return (
    <div className="border-b border-cyan-500/15 bg-slate-950/60 text-blue-200/80 text-xs py-1.5 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 font-medium text-cyan-300">
            <span
              className="inline-block w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]"
              aria-hidden="true"
            />
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span>Official Citizen Portal</span>
          </div>
          <span className="text-blue-400/40 hidden sm:inline" aria-hidden="true">
            |
          </span>
          <span className="text-blue-200/60 hidden sm:inline">
            Public Service Access Gateway
          </span>
        </div>

        <div className="flex items-center text-xs">
          {/* Citizen Help */}
          <button
            type="button"
            onClick={onOpenHelp}
            className="inline-flex items-center gap-1 text-cyan-300 hover:text-white font-medium cursor-pointer transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Help Desk</span>
          </button>
        </div>
      </div>
    </div>
  );
};
