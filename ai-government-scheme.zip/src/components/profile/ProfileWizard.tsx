import React, { useState, useEffect } from 'react';
import { ProfileData, ProfileStep, ValidationErrors } from '../../types';
import { AssessmentSidebar } from './AssessmentSidebar';
import { AssessmentMobileHeader } from './AssessmentMobileHeader';
import { Step1Personal } from './Step1Personal';
import { Step2Social } from './Step2Social';
import { Step3Financial } from './Step3Financial';
import { Step4Education } from './Step4Education';
import { Step5Employment } from './Step5Employment';
import { Step6Family } from './Step6Family';
import { Step7Special } from './Step7Special';
import { Step8Review } from './Step8Review';
import { isValidDistrictForState } from '../../data/indianLocations';
import { parseNumericIncome } from '../../data/schemesDatabase';

interface ProfileWizardProps {
  userEmail?: string;
  onExitToLogin: () => void;
  onFindEligibleSchemes?: (data: ProfileData) => void;
  onSaveDraft?: (data: ProfileData, currentStep: ProfileStep) => void;
  initialProfileData?: ProfileData;
  initialStep?: ProfileStep;
}

const INITIAL_PROFILE: ProfileData = {
  fullName: '',
  age: '',
  gender: '',
  state: '',
  district: '',

  religion: '',
  casteCategory: '',
  minorityCommunity: '',

  personalIncome: '',
  familyIncome: '',
  bplRationCard: '',

  educationLevel: '',
  courseStream: '',
  currentStudent: '',
  currentGradeYear: '',

  employmentStatus: '',
  otherEmploymentStatus: '',
  occupation: '',
  farmerLandOwnership: '',

  maritalStatus: '',
  familyMembersCount: '',
  earningMembersCount: '',

  personWithDisability: '',
  disabilityPercentage: '',
  isFarmer: '',
  ownAgriculturalLand: '',
  ownHouse: '',
};

export const ProfileWizard: React.FC<ProfileWizardProps> = ({
  userEmail,
  onExitToLogin,
  onFindEligibleSchemes,
  onSaveDraft,
  initialProfileData,
  initialStep = 1,
}) => {
  // Stable, authoritative source of truth for the assessment step
  const [currentStep, setCurrentStep] = useState<ProfileStep>(initialStep);
  const [maxCompletedStep, setMaxCompletedStep] = useState<number>(initialStep >= 8 ? 8 : 1);
  const [profileData, setProfileData] = useState<ProfileData>(initialProfileData || INITIAL_PROFILE);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [isEditingFromReview, setIsEditingFromReview] = useState(false);

  const updateData = (fields: Partial<ProfileData>) => {
    let nextProfile: ProfileData = { ...profileData, ...fields };
    setProfileData((prev) => {
      const updated = { ...prev, ...fields };
      nextProfile = updated;
      onSaveDraft?.(updated, currentStep);
      return updated;
    });

    // Clear errors for modified fields and revalidate income relationship
    setErrors((prevErrors) => {
      const updatedErrors = { ...prevErrors };
      Object.keys(fields).forEach((key) => {
        delete updatedErrors[key];
      });

      // Real-time revalidation of income constraint when either field changes
      if ('personalIncome' in fields || 'familyIncome' in fields) {
        const pNum = parseNumericIncome(nextProfile.personalIncome);
        const fNum = parseNumericIncome(nextProfile.familyIncome);

        if (pNum !== null && fNum !== null) {
          if (fNum < pNum) {
            updatedErrors.familyIncome =
              'Family annual income must be greater than or equal to personal annual income.';
          } else if (
            updatedErrors.familyIncome ===
            'Family annual income must be greater than or equal to personal annual income.'
          ) {
            delete updatedErrors.familyIncome;
          }
        } else if (
          updatedErrors.familyIncome ===
          'Family annual income must be greater than or equal to personal annual income.'
        ) {
          delete updatedErrors.familyIncome;
        }
      }

      // If educationLevel changed to 'Not Studying', clear any courseStream and grade errors
      if (fields.educationLevel === 'Not Studying') {
        delete updatedErrors.courseStream;
        delete updatedErrors.currentGradeYear;
        delete updatedErrors.currentStudent;
      }

      // If employmentStatus changed away from 'Other', clear otherEmploymentStatus error
      if (fields.employmentStatus && fields.employmentStatus !== 'Other') {
        delete updatedErrors.otherEmploymentStatus;
      }

      // If employmentStatus changed to 'Student' or 'Unemployed', clear occupation error
      if (fields.employmentStatus === 'Student' || fields.employmentStatus === 'Unemployed') {
        delete updatedErrors.occupation;
      }

      // Real-time revalidation of family members vs earning members constraint
      if ('familyMembersCount' in fields || 'earningMembersCount' in fields) {
        const famStr = nextProfile.familyMembersCount?.trim();
        const earnStr = nextProfile.earningMembersCount?.trim();

        if (famStr && earnStr) {
          const famNum = parseInt(famStr, 10);
          const earnNum = parseInt(earnStr, 10);

          if (!isNaN(famNum) && !isNaN(earnNum)) {
            if (earnNum > famNum) {
              updatedErrors.earningMembersCount =
                'Number of earning members cannot exceed total number of family members.';
            } else if (
              updatedErrors.earningMembersCount ===
              'Number of earning members cannot exceed total number of family members.'
            ) {
              delete updatedErrors.earningMembersCount;
            }
          }
        } else if (
          updatedErrors.earningMembersCount ===
          'Number of earning members cannot exceed total number of family members.'
        ) {
          delete updatedErrors.earningMembersCount;
        }
      }

      return updatedErrors;
    });
  };

  const validateStep = (step: ProfileStep): boolean => {
    const newErrors: ValidationErrors = {};

    if (step === 1) {
      if (!profileData.fullName.trim()) newErrors.fullName = 'Full Name is required.';
      if (!profileData.age) {
        newErrors.age = 'Age is required.';
      } else {
        const numAge = parseInt(profileData.age, 10);
        if (isNaN(numAge) || numAge < 1 || numAge > 120) {
          newErrors.age = 'Please enter a valid age between 1 and 120.';
        }
      }
      if (!profileData.gender) newErrors.gender = 'Please select a gender option.';
      if (!profileData.state) newErrors.state = 'Please select your state or UT.';
      if (!profileData.district.trim()) {
        newErrors.district = 'Please select your district.';
      } else if (profileData.state && !isValidDistrictForState(profileData.state, profileData.district)) {
        newErrors.district = `Please select a valid district for ${profileData.state}.`;
      }
    }

    if (step === 2) {
      if (!profileData.religion) newErrors.religion = 'Please select your religion.';
      if (!profileData.casteCategory) newErrors.casteCategory = 'Please select your caste / category.';
      if (!profileData.minorityCommunity) newErrors.minorityCommunity = 'Please indicate minority community status.';
    }

    if (step === 3) {
      if (!profileData.personalIncome.trim()) {
        newErrors.personalIncome = 'Personal annual income is required (enter 0 if none).';
      }
      if (!profileData.familyIncome.trim()) {
        newErrors.familyIncome = 'Family annual income is required.';
      } else {
        const pNum = parseNumericIncome(profileData.personalIncome);
        const fNum = parseNumericIncome(profileData.familyIncome);
        if (pNum !== null && fNum !== null && fNum < pNum) {
          newErrors.familyIncome =
            'Family annual income must be greater than or equal to personal annual income.';
        }
      }
      if (!profileData.bplRationCard) {
        newErrors.bplRationCard = 'Please select BPL / Ration card status.';
      }
    }

    if (step === 4) {
      if (!profileData.educationLevel) {
        newErrors.educationLevel = 'Please select your highest education level.';
      }
      if (profileData.educationLevel === 'Not Studying') {
        // When Not Studying, active student is automatically No and course is not required
        if (profileData.currentStudent !== 'No') {
          profileData.currentStudent = 'No';
        }
      } else {
        if (!profileData.courseStream.trim()) {
          newErrors.courseStream = 'Course or stream is required.';
        }
        if (!profileData.currentStudent) {
          newErrors.currentStudent = 'Please select if you are currently an active student.';
        }
        if (profileData.currentStudent === 'Yes' && !profileData.currentGradeYear.trim()) {
          newErrors.currentGradeYear = 'Please enter your current year or grade.';
        }
      }
    }

    if (step === 5) {
      if (!profileData.employmentStatus) {
        newErrors.employmentStatus = 'Please select employment status.';
      }

      if (profileData.employmentStatus === 'Other') {
        if (!profileData.otherEmploymentStatus?.trim()) {
          newErrors.otherEmploymentStatus = 'Please specify your employment status.';
        }
      }

      // Occupation is required unless employmentStatus is Student or Unemployed
      if (profileData.employmentStatus !== 'Student' && profileData.employmentStatus !== 'Unemployed') {
        if (!profileData.occupation.trim()) {
          newErrors.occupation = 'Occupation is required.';
        }
      }

      if (profileData.employmentStatus === 'Farmer' && !profileData.farmerLandOwnership) {
        newErrors.farmerLandOwnership = 'Please indicate agricultural land ownership.';
      }
    }

    if (step === 6) {
      if (!profileData.maritalStatus) newErrors.maritalStatus = 'Please select marital status.';

      const famStr = profileData.familyMembersCount?.trim();
      if (!famStr) {
        newErrors.familyMembersCount = 'Number of family members is required.';
      } else {
        const count = parseInt(famStr, 10);
        if (isNaN(count) || count < 1) {
          newErrors.familyMembersCount = 'Must be at least 1 member.';
        }
      }

      const earnStr = profileData.earningMembersCount?.trim();
      if (!earnStr) {
        newErrors.earningMembersCount = 'Number of earning members is required (enter 0 if none).';
      } else {
        const earnCount = parseInt(earnStr, 10);
        if (isNaN(earnCount) || earnCount < 0) {
          newErrors.earningMembersCount = 'Number of earning members cannot be negative.';
        } else if (famStr) {
          const famCount = parseInt(famStr, 10);
          if (!isNaN(famCount) && earnCount > famCount) {
            newErrors.earningMembersCount =
              'Number of earning members cannot exceed total number of family members.';
          }
        }
      }
    }

    if (step === 7) {
      if (!profileData.personWithDisability) newErrors.personWithDisability = 'Please select disability status.';
      if (profileData.personWithDisability === 'Yes') {
        if (!profileData.disabilityPercentage) {
          newErrors.disabilityPercentage = 'Please enter disability percentage.';
        } else {
          const pct = parseInt(profileData.disabilityPercentage, 10);
          if (isNaN(pct) || pct < 1 || pct > 100) {
            newErrors.disabilityPercentage = 'Percentage must be between 1% and 100%.';
          }
        }
      }
      if (!profileData.isFarmer) newErrors.isFarmer = 'Please indicate farmer status.';
      if (profileData.isFarmer === 'Yes' && !profileData.ownAgriculturalLand) {
        newErrors.ownAgriculturalLand = 'Please select agricultural land ownership.';
      }
      if (!profileData.ownHouse) newErrors.ownHouse = 'Please indicate residential property status.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (!validateStep(currentStep)) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    setMaxCompletedStep((prev) => Math.max(prev, currentStep + 1));

    if (isEditingFromReview) {
      setCurrentStep(8);
      setIsEditingFromReview(false);
      onSaveDraft?.(profileData, 8);
    } else if (currentStep < 8) {
      const nextStep = (currentStep + 1) as ProfileStep;
      setCurrentStep(nextStep);
      onSaveDraft?.(profileData, nextStep);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBack = () => {
    if (currentStep === 1) {
      onExitToLogin();
    } else {
      const prevStep = (currentStep - 1) as ProfileStep;
      setCurrentStep(prevStep);
      onSaveDraft?.(profileData, prevStep);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStepClick = (targetStep: ProfileStep) => {
    if (targetStep > currentStep) {
      if (!validateStep(currentStep)) return;
    }
    setCurrentStep(targetStep);
    onSaveDraft?.(profileData, targetStep);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEditFromReview = (targetStep: ProfileStep) => {
    setIsEditingFromReview(true);
    setCurrentStep(targetStep);
    onSaveDraft?.(profileData, targetStep);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleReturnToReview = () => {
    if (!validateStep(currentStep)) return;
    setCurrentStep(8);
    setIsEditingFromReview(false);
    onSaveDraft?.(profileData, 8);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="w-full min-h-screen bg-slate-50 text-slate-800 flex flex-col lg:flex-row font-sans">
      {/* Mobile Top Header with Compact Progress */}
      <AssessmentMobileHeader
        currentStep={currentStep}
        onStepClick={handleStepClick}
        maxCompletedStep={maxCompletedStep}
        userEmail={userEmail}
        onExit={onExitToLogin}
      />

      {/* Desktop Sticky Sidebar */}
      <div className="hidden lg:block lg:sticky lg:top-0 lg:h-screen lg:overflow-y-auto">
        <AssessmentSidebar
          currentStep={currentStep}
          onStepClick={handleStepClick}
          maxCompletedStep={maxCompletedStep}
          userEmail={userEmail}
          onExit={onExitToLogin}
        />
      </div>

      {/* Main Content Area: Spacious, Full-Width Civic Assessment Form */}
      <main className="flex-1 flex flex-col justify-between py-6 sm:py-10 px-4 sm:px-8 lg:px-12 xl:px-16 overflow-y-auto">
        <div className="w-full max-w-4xl mx-auto">
          {/* Top Breadcrumb Context on Desktop */}
          <div className="hidden lg:flex items-center justify-between text-xs text-slate-500 mb-6 pb-3 border-b border-slate-200/80">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-700">Citizen Assessment</span>
              <span>/</span>
              <span className="text-blue-700 font-semibold">Step {currentStep} of 8</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>Secure Session Active</span>
            </div>
          </div>

          {/* Clean White Content Panel */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 sm:p-10 lg:p-12">
            {currentStep === 1 && (
              <Step1Personal
                data={profileData}
                updateData={updateData}
                errors={errors}
                onNext={handleNext}
                onBack={handleBack}
                isEditingFromReview={isEditingFromReview}
                onReturnToReview={handleReturnToReview}
              />
            )}

            {currentStep === 2 && (
              <Step2Social
                data={profileData}
                updateData={updateData}
                errors={errors}
                onNext={handleNext}
                onBack={handleBack}
                isEditingFromReview={isEditingFromReview}
                onReturnToReview={handleReturnToReview}
              />
            )}

            {currentStep === 3 && (
              <Step3Financial
                data={profileData}
                updateData={updateData}
                errors={errors}
                onNext={handleNext}
                onBack={handleBack}
                isEditingFromReview={isEditingFromReview}
                onReturnToReview={handleReturnToReview}
              />
            )}

            {currentStep === 4 && (
              <Step4Education
                data={profileData}
                updateData={updateData}
                errors={errors}
                onNext={handleNext}
                onBack={handleBack}
                isEditingFromReview={isEditingFromReview}
                onReturnToReview={handleReturnToReview}
              />
            )}

            {currentStep === 5 && (
              <Step5Employment
                data={profileData}
                updateData={updateData}
                errors={errors}
                onNext={handleNext}
                onBack={handleBack}
                isEditingFromReview={isEditingFromReview}
                onReturnToReview={handleReturnToReview}
              />
            )}

            {currentStep === 6 && (
              <Step6Family
                data={profileData}
                updateData={updateData}
                errors={errors}
                onNext={handleNext}
                onBack={handleBack}
                isEditingFromReview={isEditingFromReview}
                onReturnToReview={handleReturnToReview}
              />
            )}

            {currentStep === 7 && (
              <Step7Special
                data={profileData}
                updateData={updateData}
                errors={errors}
                onNext={handleNext}
                onBack={handleBack}
                isEditingFromReview={isEditingFromReview}
                onReturnToReview={handleReturnToReview}
              />
            )}

            {currentStep === 8 && (
              <Step8Review
                data={profileData}
                onEditStep={handleEditFromReview}
                onBack={handleBack}
                onFindEligibleSchemes={() => {
                  const pNum = parseNumericIncome(profileData.personalIncome);
                  const fNum = parseNumericIncome(profileData.familyIncome);
                  if (pNum !== null && fNum !== null && fNum < pNum) {
                    setCurrentStep(3);
                    setErrors({
                      familyIncome:
                        'Family annual income must be greater than or equal to personal annual income.',
                    });
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    return;
                  }
                  onFindEligibleSchemes?.(profileData);
                }}
              />
            )}
          </div>
        </div>

        {/* Subtle Bottom Footer in Assessment */}
        <footer className="mt-8 pt-6 border-t border-slate-200 text-center text-xs text-slate-500">
          <p>
            Government Scheme Eligibility Advisor • Public Welfare Information Services
          </p>
        </footer>
      </main>
    </div>
  );
};
