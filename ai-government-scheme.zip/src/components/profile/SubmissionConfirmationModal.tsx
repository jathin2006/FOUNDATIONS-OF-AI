import React from 'react';
import { CheckCircle2, Download, X, Info, ShieldCheck } from 'lucide-react';
import { ProfileData } from '../../types';

interface SubmissionConfirmationModalProps {
  data: ProfileData;
  onClose: () => void;
}

export const SubmissionConfirmationModal: React.FC<SubmissionConfirmationModalProps> = ({
  data,
  onClose,
}) => {
  const downloadSummary = () => {
    const summaryStr = JSON.stringify(data, null, 2);
    const blob = new Blob([summaryStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `citizen-profile-${data.fullName ? data.fullName.toLowerCase().replace(/\s+/g, '-') : 'record'}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden p-6 sm:p-8 text-slate-800"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center pt-2">
          {/* Emblem check */}
          <div className="w-16 h-16 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center mx-auto mb-4 shadow-sm">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <div className="inline-block px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-800 text-xs font-semibold mb-3">
            Profile Status: Verified & Recorded
          </div>

          <h2 id="confirm-modal-title" className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Citizen Information Saved
          </h2>

          <p className="text-sm text-slate-600 mt-2 max-w-sm mx-auto leading-relaxed">
            All 8 sections of your citizen eligibility assessment profile have been validated and saved in the active session.
          </p>

          {/* Staging Notice */}
          <div className="mt-5 p-4 rounded-xl bg-blue-50/80 border border-blue-200 text-left text-xs text-blue-950 space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-blue-900">
              <Info className="w-4 h-4 text-blue-700 flex-shrink-0" />
              <span>Next Phase: Scheme Eligibility Evaluation</span>
            </div>
            <p className="leading-relaxed text-blue-900/80">
              In accordance with project specifications, the government scheme matching engine and recommendation results page will be connected in the subsequent phase.
            </p>
          </div>

          {/* Summary Preview */}
          <div className="mt-5 p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-left text-xs text-slate-600 space-y-1.5">
            <div className="flex justify-between">
              <span>Citizen Name:</span>
              <strong className="text-slate-900">{data.fullName || 'Citizen User'}</strong>
            </div>
            <div className="flex justify-between">
              <span>Location:</span>
              <span className="text-slate-900">{data.district ? `${data.district}, ` : ''}{data.state}</span>
            </div>
            <div className="flex justify-between">
              <span>Social Category:</span>
              <span className="text-slate-900">{data.casteCategory || 'General'}</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={downloadSummary}
              className="flex-1 py-2.5 px-4 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export Profile (JSON)</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-6 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              Close & View Review
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
