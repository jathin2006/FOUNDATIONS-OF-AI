import React from 'react';
import { Check, ShieldCheck, User, LogOut, ChevronRight } from 'lucide-react';
import { ProfileStep } from '../../types';

interface AssessmentSidebarProps {
  currentStep: ProfileStep;
  onStepClick: (step: ProfileStep) => void;
  maxCompletedStep: number;
  userEmail?: string;
  onExit: () => void;
}

const STEPS: { step: ProfileStep; label: string; shortDesc: string }[] = [
  { step: 1, label: 'Personal Details', shortDesc: 'Basic demographics & location' },
  { step: 2, label: 'Social & Category', shortDesc: 'Caste & community criteria' },
  { step: 3, label: 'Financial', shortDesc: 'Income & ration card status' },
  { step: 4, label: 'Education', shortDesc: 'Academic level & course' },
  { step: 5, label: 'Employment', shortDesc: 'Work status & occupation' },
  { step: 6, label: 'Family', shortDesc: 'Household & earning members' },
  { step: 7, label: 'Special Conditions', shortDesc: 'Disability & property details' },
  { step: 8, label: 'Review', shortDesc: 'Verify all entered details' },
];

export const AssessmentSidebar: React.FC<AssessmentSidebarProps> = ({
  currentStep,
  onStepClick,
  maxCompletedStep,
  userEmail,
  onExit,
}) => {
  const percentComplete = Math.round(((currentStep - 1) / 7) * 100);

  return (
    <aside className="w-full lg:w-72 xl:w-80 flex-shrink-0 bg-white border-r border-slate-200 flex flex-col justify-between h-auto lg:min-h-screen">
      <div>
        {/* Portal Branding Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-800 text-white flex items-center justify-center flex-shrink-0 shadow-sm">
              <svg
                className="w-6 h-6"
                viewBox="0 0 40 40"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-label="Government Seal"
              >
                <path d="M20 7L7 15H33L20 7Z" fill="currentColor" />
                <rect x="8" y="16" width="24" height="2" fill="currentColor" opacity="0.9" />
                <rect x="10" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="16" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="22" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="28" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="7" y="30" width="26" height="3" rx="0.5" fill="currentColor" />
              </svg>
            </div>
            <div>
              <h1 className="text-sm font-bold text-slate-900 leading-tight">
                Government Scheme Advisor
              </h1>
              <p className="text-[11px] text-slate-500 font-medium">
                Public Welfare Assessment
              </p>
            </div>
          </div>
        </div>

        {/* Progress Overview Block */}
        <div className="px-5 sm:px-6 py-4 bg-slate-50/70 border-b border-slate-100">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1.5">
            <span>Your Progress</span>
            <span className="text-blue-700">{percentComplete}%</span>
          </div>
          {/* Progress bar */}
          <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
            <div
              className="h-full bg-blue-700 rounded-full transition-all duration-300"
              style={{ width: `${percentComplete}%` }}
            />
          </div>
          <p className="text-[11px] text-slate-500 mt-2">
            Step <strong className="text-slate-800">{currentStep}</strong> of 8:{' '}
            {STEPS[currentStep - 1]?.label}
          </p>
        </div>

        {/* Vertical Step Navigation */}
        <nav aria-label="Assessment Steps" className="p-3 sm:p-4 space-y-1">
          {STEPS.map((s) => {
            const isCompleted = s.step < currentStep || s.step <= maxCompletedStep;
            const isCurrent = s.step === currentStep;
            const isClickable = s.step <= maxCompletedStep || s.step <= currentStep;

            return (
              <button
                type="button"
                key={s.step}
                disabled={!isClickable}
                onClick={() => isClickable && onStepClick(s.step)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-left transition-all ${
                  isCurrent
                    ? 'bg-blue-50 border-l-4 border-blue-700 shadow-2xs font-semibold'
                    : isClickable
                    ? 'hover:bg-slate-50 text-slate-700 cursor-pointer'
                    : 'opacity-50 cursor-not-allowed text-slate-400'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  {/* Step status circle */}
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs flex-shrink-0 font-bold transition-all ${
                      isCurrent
                        ? 'bg-blue-700 text-white ring-2 ring-blue-100'
                        : isCompleted && s.step < currentStep
                        ? 'bg-emerald-600 text-white'
                        : 'border border-slate-300 text-slate-500 bg-white'
                    }`}
                  >
                    {isCompleted && s.step < currentStep ? (
                      <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                    ) : (
                      s.step
                    )}
                  </div>

                  <div className="truncate">
                    <span
                      className={`text-xs block truncate ${
                        isCurrent
                          ? 'text-blue-900 font-bold'
                          : isCompleted
                          ? 'text-slate-800 font-medium'
                          : 'text-slate-500'
                      }`}
                    >
                      {s.label}
                    </span>
                    <span className="hidden xl:block text-[10px] text-slate-400 truncate">
                      {s.shortDesc}
                    </span>
                  </div>
                </div>

                {isCurrent && (
                  <ChevronRight className="w-4 h-4 text-blue-700 flex-shrink-0" />
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer Info in Sidebar */}
      <div className="p-4 border-t border-slate-100 bg-slate-50/50 space-y-3">
        <div className="flex items-center gap-2 text-xs text-slate-600">
          <ShieldCheck className="w-4 h-4 text-blue-700 flex-shrink-0" />
          <span className="text-[11px] leading-tight">
            Encrypted citizen data. Used strictly for scheme eligibility assessment.
          </span>
        </div>

        <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 truncate max-w-[170px]">
            <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 flex-shrink-0">
              <User className="w-3.5 h-3.5" />
            </div>
            <span className="truncate text-slate-700 text-[11px] font-medium">
              {userEmail || 'Citizen User'}
            </span>
          </div>

          <button
            type="button"
            onClick={onExit}
            className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-500 hover:text-red-700 cursor-pointer"
            title="Exit assessment"
          >
            <LogOut className="w-3 h-3" />
            <span>Exit</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
