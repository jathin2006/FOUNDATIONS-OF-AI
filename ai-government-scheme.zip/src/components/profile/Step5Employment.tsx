import React from 'react';
import { ArrowRight, ArrowLeft, Briefcase, Tractor, Check } from 'lucide-react';
import { ProfileData, ValidationErrors } from '../../types';

interface Step5Props {
  data: ProfileData;
  updateData: (fields: Partial<ProfileData>) => void;
  errors: ValidationErrors;
  onNext: () => void;
  onBack: () => void;
  isEditingFromReview?: boolean;
  onReturnToReview?: () => void;
}

const EMPLOYMENT_STATUSES = [
  'Student',
  'Employed',
  'Unemployed',
  'Self-employed',
  'Farmer',
  'Daily Wage Worker',
  'Retired',
  'Other',
] as const;

export const Step5Employment: React.FC<Step5Props> = ({
  data,
  updateData,
  errors,
  onNext,
  onBack,
  isEditingFromReview,
  onReturnToReview,
}) => {
  return (
    <div className="space-y-8">
      {/* Step Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-blue-100 text-blue-800">
            Step 5 of 8
          </span>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Eligibility Assessment
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
          Employment Details
        </h2>
        <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
          Livelihood support, PMEGP loans, artisan PM Vishwakarma aid, unorganized worker e-Shram benefits, and agricultural schemes depend on your employment category.
        </p>
      </div>

      <div className="space-y-6">
        {/* Employment Status */}
        <div>
          <label className="block text-sm font-semibold text-slate-800 mb-1">
            Current Employment Status <span className="text-red-500">*</span>
          </label>
          <p className="text-xs text-slate-500 mb-2.5">
            Select the category that best describes your principal daily activity.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {EMPLOYMENT_STATUSES.map((status) => (
              <button
                type="button"
                key={status}
                onClick={() => {
                  updateData({
                    employmentStatus: status,
                    farmerLandOwnership: status === 'Farmer' ? data.farmerLandOwnership : '',
                  });
                }}
                className={`py-3 px-3 rounded-lg text-xs sm:text-sm font-medium border text-center transition-all cursor-pointer ${
                  data.employmentStatus === status
                    ? 'border-blue-600 bg-blue-50/60 text-blue-950 font-bold ring-2 ring-blue-600/20'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
          {errors.employmentStatus && (
            <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.employmentStatus}</p>
          )}
        </div>

        {/* Conditional Field: Specify Employment Status (If Employment Status = Other) */}
        {data.employmentStatus === 'Other' && (
          <div className="max-w-xl animate-fadeIn">
            <label htmlFor="w-other-employment-status" className="block text-sm font-semibold text-slate-800 mb-1">
              Specify Employment Status <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-slate-500 mb-2">
              Enter your specific employment category or profession.
            </p>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Briefcase className="w-4 h-4" />
              </div>
              <input
                id="w-other-employment-status"
                type="text"
                value={data.otherEmploymentStatus || ''}
                onChange={(e) => updateData({ otherEmploymentStatus: e.target.value })}
                placeholder="Enter your employment status"
                className={`w-full pl-10 pr-3.5 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                  errors.otherEmploymentStatus
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 placeholder:text-slate-400 focus:outline-none`}
              />
            </div>
            {errors.otherEmploymentStatus && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.otherEmploymentStatus}</p>
            )}
          </div>
        )}

        {/* Occupation / Line of Work - Hidden when Current Employment Status is Student or Unemployed */}
        {data.employmentStatus !== 'Student' && data.employmentStatus !== 'Unemployed' && (
          <div className="max-w-xl animate-fadeIn">
            <label htmlFor="w-occupation" className="block text-sm font-semibold text-slate-800 mb-1">
              Occupation / Line of Work <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-slate-500 mb-2">
              Specific job role or trade (e.g. Small Shopkeeper, Weaver, Farmer, Software Developer, Daily Labor, Homemaker).
            </p>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Briefcase className="w-4 h-4" />
              </div>
              <input
                id="w-occupation"
                type="text"
                value={data.occupation}
                onChange={(e) => updateData({ occupation: e.target.value })}
                placeholder="e.g. Small Grocery Store Owner"
                className={`w-full pl-10 pr-3.5 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                  errors.occupation
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 placeholder:text-slate-400 focus:outline-none`}
              />
            </div>
            {errors.occupation && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.occupation}</p>
            )}
          </div>
        )}

        {/* Conditional Field: Agricultural Land Ownership (If Employment Status = Farmer) */}
        {data.employmentStatus === 'Farmer' && (
          <div className="p-4 sm:p-5 rounded-xl border border-emerald-200 bg-emerald-50/40 space-y-3 animate-fadeIn max-w-lg">
            <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
              <Tractor className="w-4 h-4 text-emerald-700" />
              <span>Agricultural Land Ownership</span>
            </div>
            <p className="text-xs text-emerald-900/80">
              Do you own agricultural land in your name or family land records? (Determines PM-KISAN, crop insurance, or tenant farmer subsidies).
            </p>
            <div className="grid grid-cols-2 gap-3 max-w-xs">
              {(['Yes', 'No'] as const).map((opt) => (
                <button
                  type="button"
                  key={opt}
                  onClick={() => updateData({ farmerLandOwnership: opt })}
                  className={`py-2.5 px-4 rounded-lg text-sm font-medium border text-left flex items-center justify-between transition-all cursor-pointer ${
                    data.farmerLandOwnership === opt
                      ? 'border-emerald-600 bg-white text-emerald-950 font-bold ring-2 ring-emerald-600/20'
                      : 'border-emerald-200 bg-white/80 text-emerald-900 hover:bg-white'
                  }`}
                >
                  <span>{opt}</span>
                  <span
                    className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      data.farmerLandOwnership === opt
                        ? 'border-emerald-700 bg-emerald-700 text-white'
                        : 'border-slate-300 bg-white'
                    }`}
                  >
                    {data.farmerLandOwnership === opt && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                  </span>
                </button>
              ))}
            </div>
            {errors.farmerLandOwnership && (
              <p className="mt-1 text-xs text-red-600 font-medium">{errors.farmerLandOwnership}</p>
            )}
          </div>
        )}
      </div>

      {/* Separated Bottom Navigation Area */}
      <div className="pt-6 mt-8 border-t border-slate-200 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium text-sm hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-2xs flex items-center gap-2 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-3">
          {isEditingFromReview && onReturnToReview && (
            <button
              type="button"
              onClick={onReturnToReview}
              className="px-4 py-2.5 rounded-lg border border-blue-600 text-blue-700 bg-blue-50/50 hover:bg-blue-50 font-semibold text-sm transition-colors cursor-pointer"
            >
              Return to Review
            </button>
          )}

          <button
            type="button"
            onClick={onNext}
            className="px-6 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 active:bg-blue-900 text-white font-semibold text-sm transition-colors shadow-sm flex items-center gap-2 cursor-pointer"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
