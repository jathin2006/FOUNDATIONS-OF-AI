import React, { useState, useMemo } from 'react';
import { ArrowRight, ArrowLeft, User, Calendar, MapPin, ChevronDown, Search, X } from 'lucide-react';
import { ProfileData, ValidationErrors } from '../../types';
import {
  INDIAN_STATES,
  getDistrictsForState,
  isValidDistrictForState,
} from '../../data/indianLocations';

interface Step1Props {
  data: ProfileData;
  updateData: (fields: Partial<ProfileData>) => void;
  errors: ValidationErrors;
  onNext: () => void;
  onBack: () => void;
  isEditingFromReview?: boolean;
  onReturnToReview?: () => void;
}

export const GENDERS = ['Male', 'Female', 'Other'] as const;

export const Step1Personal: React.FC<Step1Props> = ({
  data,
  updateData,
  errors,
  onNext,
  onBack,
  isEditingFromReview,
  onReturnToReview,
}) => {
  const [districtSearch, setDistrictSearch] = useState<string>('');

  // Retrieve all verified districts for the currently selected State or UT
  const allDistricts = useMemo(() => {
    return data.state ? getDistrictsForState(data.state) : [];
  }, [data.state]);

  // Filter districts when user types into the quick search filter
  const filteredDistricts = useMemo(() => {
    if (!districtSearch.trim()) return allDistricts;
    const term = districtSearch.trim().toLowerCase();
    return allDistricts.filter((d) => d.toLowerCase().includes(term));
  }, [allDistricts, districtSearch]);

  const handleStateChange = (newState: string) => {
    // If state changes, clear district if it does not belong to the newly selected state
    const keepDistrict = isValidDistrictForState(newState, data.district) ? data.district : '';
    updateData({
      state: newState,
      district: keepDistrict,
    });
    setDistrictSearch('');
  };

  const handleDistrictChange = (newDistrict: string) => {
    updateData({ district: newDistrict });
  };

  return (
    <div className="space-y-8">
      {/* Step Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-blue-100 text-blue-800">
            Step 1 of 8
          </span>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Eligibility Assessment
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
          Personal Details
        </h2>
        <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
          Help us understand your basic information. These details ensure age- and location-specific schemes are accurately identified.
        </p>
      </div>

      {/* Form Content - 2-Column Responsive Grid */}
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Full Name (spans 8 cols on md) */}
          <div className="md:col-span-8">
            <label htmlFor="p-fullname" className="block text-sm font-semibold text-slate-800 mb-1">
              Full Legal Name <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-slate-500 mb-2">
              As printed on official identity documents (Aadhaar / Voter ID / Passport).
            </p>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <User className="w-4 h-4" />
              </div>
              <input
                id="p-fullname"
                type="text"
                value={data.fullName}
                onChange={(e) => updateData({ fullName: e.target.value })}
                placeholder="e.g. Ramesh Kumar Sharma"
                className={`w-full pl-10 pr-3.5 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                  errors.fullName
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 placeholder:text-slate-400 focus:outline-none`}
              />
            </div>
            {errors.fullName && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.fullName}</p>
            )}
          </div>

          {/* Age (spans 4 cols on md) */}
          <div className="md:col-span-4">
            <label htmlFor="p-age" className="block text-sm font-semibold text-slate-800 mb-1">
              Age (Years) <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-slate-500 mb-2">
              Completed years.
            </p>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Calendar className="w-4 h-4" />
              </div>
              <input
                id="p-age"
                type="number"
                min="1"
                max="120"
                value={data.age}
                onChange={(e) => updateData({ age: e.target.value })}
                placeholder="e.g. 28"
                className={`w-full pl-10 pr-3.5 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                  errors.age
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 placeholder:text-slate-400 focus:outline-none`}
              />
            </div>
            {errors.age && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.age}</p>
            )}
          </div>
        </div>

        {/* Gender Dropdown */}
        <div>
          <label htmlFor="p-gender" className="block text-sm font-semibold text-slate-800 mb-1">
            Gender <span className="text-red-500">*</span>
          </label>
          <p className="text-xs text-slate-500 mb-2">
            Several government schemes feature dedicated entitlements for women and gender diversity programs.
          </p>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <User className="w-4 h-4" />
            </div>
            <select
              id="p-gender"
              name="gender"
              value={data.gender}
              onChange={(e) => updateData({ gender: e.target.value as 'Male' | 'Female' | 'Other' })}
              className={`w-full pl-10 pr-9 py-2.5 text-sm bg-white rounded-lg border transition-colors cursor-pointer appearance-none ${
                errors.gender
                  ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                  : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
              } text-slate-900 focus:outline-none`}
            >
              <option value="">Select Gender</option>
              {GENDERS.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
              <ChevronDown className="w-4 h-4" />
            </div>
          </div>
          {errors.gender && (
            <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.gender}</p>
          )}
        </div>

        {/* State and District in 2-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          {/* State / UT */}
          <div>
            <label htmlFor="p-state" className="block text-sm font-semibold text-slate-800 mb-1">
              State / Union Territory <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-slate-500 mb-2">
              Select your permanent residential state or UT.
            </p>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <MapPin className="w-4 h-4" />
              </div>
              <select
                id="p-state"
                name="state"
                value={data.state}
                onChange={(e) => handleStateChange(e.target.value)}
                className={`w-full pl-10 pr-9 py-2.5 text-sm bg-white rounded-lg border transition-colors cursor-pointer appearance-none ${
                  errors.state
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 focus:outline-none`}
              >
                <option value="">Select State or UT</option>
                {INDIAN_STATES.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                <ChevronDown className="w-4 h-4" />
              </div>
            </div>
            {errors.state && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.state}</p>
            )}
          </div>

          {/* District */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="p-district" className="block text-sm font-semibold text-slate-800">
                District <span className="text-red-500">*</span>
              </label>
              {data.state && allDistricts.length > 0 && (
                <span className="text-[11px] font-medium text-slate-500">
                  {allDistricts.length} districts in {data.state}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mb-2">
              District administration of your residence.
            </p>

            {/* Quick Filter Search for states with many districts */}
            {data.state && allDistricts.length > 10 && (
              <div className="relative mb-2">
                <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
                  <Search className="w-3.5 h-3.5" />
                </div>
                <input
                  type="text"
                  value={districtSearch}
                  onChange={(e) => setDistrictSearch(e.target.value)}
                  placeholder={`Search ${data.state} districts...`}
                  className="w-full pl-8 pr-7 py-1.5 text-xs bg-slate-50 hover:bg-white rounded-md border border-slate-200 focus:border-blue-500 focus:bg-white focus:outline-none transition-colors text-slate-800 placeholder:text-slate-400"
                />
                {districtSearch && (
                  <button
                    type="button"
                    onClick={() => setDistrictSearch('')}
                    className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
                    aria-label="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            )}

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <MapPin className="w-4 h-4" />
              </div>
              <select
                id="p-district"
                name="district"
                value={data.district}
                onChange={(e) => handleDistrictChange(e.target.value)}
                disabled={!data.state}
                className={`w-full pl-10 pr-9 py-2.5 text-sm bg-white rounded-lg border transition-colors cursor-pointer appearance-none ${
                  errors.district
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 focus:outline-none disabled:bg-slate-50 disabled:text-slate-400 disabled:cursor-not-allowed`}
              >
                <option value="">
                  {!data.state
                    ? 'Select State / UT first'
                    : filteredDistricts.length === 0
                    ? 'No districts matching search'
                    : 'Select District'}
                </option>
                {/* Preserve current selection if outside filter */}
                {data.district && !filteredDistricts.includes(data.district) && (
                  <option value={data.district}>{data.district}</option>
                )}
                {filteredDistricts.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                <ChevronDown className="w-4 h-4" />
              </div>
            </div>
            {errors.district && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.district}</p>
            )}
          </div>
        </div>
      </div>

      {/* Separated Bottom Navigation Area */}
      <div className="pt-6 mt-8 border-t border-slate-200 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium text-sm hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-2xs flex items-center gap-2 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-3">
          {isEditingFromReview && onReturnToReview && (
            <button
              type="button"
              onClick={onReturnToReview}
              className="px-4 py-2.5 rounded-lg border border-blue-600 text-blue-700 bg-blue-50/50 hover:bg-blue-50 font-semibold text-sm transition-colors cursor-pointer"
            >
              Return to Review
            </button>
          )}

          <button
            type="button"
            onClick={onNext}
            className="px-6 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 active:bg-blue-900 text-white font-semibold text-sm transition-colors shadow-sm flex items-center gap-2 cursor-pointer"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
