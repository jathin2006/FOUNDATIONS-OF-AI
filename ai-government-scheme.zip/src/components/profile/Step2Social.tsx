import React from 'react';
import { ArrowRight, ArrowLeft, Shield, Users, Check } from 'lucide-react';
import { ProfileData, ValidationErrors } from '../../types';

interface Step2Props {
  data: ProfileData;
  updateData: (fields: Partial<ProfileData>) => void;
  errors: ValidationErrors;
  onNext: () => void;
  onBack: () => void;
  isEditingFromReview?: boolean;
  onReturnToReview?: () => void;
}

const RELIGIONS = [
  'Hindu',
  'Muslim',
  'Christian',
  'Sikh',
  'Buddhist',
  'Jain',
  'Parsi',
  'Other',
  'Prefer not to say',
];

const CASTE_CATEGORIES = [
  { id: 'General', label: 'General', desc: 'Open / Unreserved category' },
  { id: 'OBC', label: 'OBC', desc: 'Other Backward Classes (Central/State)' },
  { id: 'SC', label: 'SC', desc: 'Scheduled Castes' },
  { id: 'ST', label: 'ST', desc: 'Scheduled Tribes' },
  { id: 'EWS', label: 'EWS', desc: 'Economically Weaker Section' },
  { id: 'Other', label: 'Other', desc: 'Other recognized categories' },
] as const;

export const Step2Social: React.FC<Step2Props> = ({
  data,
  updateData,
  errors,
  onNext,
  onBack,
  isEditingFromReview,
  onReturnToReview,
}) => {
  return (
    <div className="space-y-8">
      {/* Step Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-blue-100 text-blue-800">
            Step 2 of 8
          </span>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Eligibility Assessment
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
          Social & Category Details
        </h2>
        <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
          These details help us identify schemes designed for specific communities, affirmative action grants, and social welfare programs.
        </p>
      </div>

      <div className="space-y-6">
        {/* Religion */}
        <div className="max-w-md">
          <label htmlFor="s-religion" className="block text-sm font-semibold text-slate-800 mb-1">
            Religion <span className="text-red-500">*</span>
          </label>
          <p className="text-xs text-slate-500 mb-2">
            Selected for schemes administered by Ministry of Minority Affairs and state welfare boards.
          </p>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <Shield className="w-4 h-4" />
            </div>
            <select
              id="s-religion"
              value={data.religion}
              onChange={(e) => updateData({ religion: e.target.value })}
              className={`w-full pl-10 pr-8 py-2.5 text-sm bg-white rounded-lg border transition-colors cursor-pointer appearance-none ${
                errors.religion
                  ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                  : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
              } text-slate-900 focus:outline-none`}
            >
              <option value="">Select Religion</option>
              {RELIGIONS.map((rel) => (
                <option key={rel} value={rel}>
                  {rel}
                </option>
              ))}
            </select>
          </div>
          {errors.religion && (
            <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.religion}</p>
          )}
        </div>

        {/* Caste / Category Cards */}
        <div>
          <label className="block text-sm font-semibold text-slate-800 mb-1">
            Caste / Category <span className="text-red-500">*</span>
          </label>
          <p className="text-xs text-slate-500 mb-2.5">
            Select the social category on your community certificate.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {CASTE_CATEGORIES.map((cat) => (
              <button
                type="button"
                key={cat.id}
                onClick={() => updateData({ casteCategory: cat.id })}
                className={`p-3.5 rounded-lg text-left border transition-all cursor-pointer flex flex-col justify-between ${
                  data.casteCategory === cat.id
                    ? 'border-blue-600 bg-blue-50/60 text-blue-950 font-semibold ring-2 ring-blue-600/20'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-bold text-slate-900">{cat.label}</span>
                  <span
                    className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      data.casteCategory === cat.id
                        ? 'border-blue-700 bg-blue-700 text-white'
                        : 'border-slate-300 bg-white'
                    }`}
                  >
                    {data.casteCategory === cat.id && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                  </span>
                </div>
                <p className="text-xs text-slate-500 font-normal">{cat.desc}</p>
              </button>
            ))}
          </div>
          {errors.casteCategory && (
            <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.casteCategory}</p>
          )}
        </div>

        {/* Minority Community */}
        <div>
          <label className="block text-sm font-semibold text-slate-800 mb-1">
            Do you belong to a Notified Minority Community? <span className="text-red-500">*</span>
          </label>
          <p className="text-xs text-slate-500 mb-2.5">
            Notified communities under Section 2(c) of the National Commission for Minorities Act.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-sm">
            {(['Yes', 'No'] as const).map((opt) => (
              <button
                type="button"
                key={opt}
                onClick={() => updateData({ minorityCommunity: opt })}
                className={`py-3 px-4 rounded-lg text-sm font-medium border text-left flex items-center justify-between transition-all cursor-pointer ${
                  data.minorityCommunity === opt
                    ? 'border-blue-600 bg-blue-50/60 text-blue-950 font-semibold ring-2 ring-blue-600/20'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                <span>{opt}</span>
                <span
                  className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    data.minorityCommunity === opt
                      ? 'border-blue-700 bg-blue-700 text-white'
                      : 'border-slate-300 bg-white'
                  }`}
                >
                  {data.minorityCommunity === opt && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                </span>
              </button>
            ))}
          </div>
          {errors.minorityCommunity && (
            <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.minorityCommunity}</p>
          )}
        </div>
      </div>

      {/* Separated Bottom Navigation Area */}
      <div className="pt-6 mt-8 border-t border-slate-200 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium text-sm hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-2xs flex items-center gap-2 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-3">
          {isEditingFromReview && onReturnToReview && (
            <button
              type="button"
              onClick={onReturnToReview}
              className="px-4 py-2.5 rounded-lg border border-blue-600 text-blue-700 bg-blue-50/50 hover:bg-blue-50 font-semibold text-sm transition-colors cursor-pointer"
            >
              Return to Review
            </button>
          )}

          <button
            type="button"
            onClick={onNext}
            className="px-6 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 active:bg-blue-900 text-white font-semibold text-sm transition-colors shadow-sm flex items-center gap-2 cursor-pointer"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
