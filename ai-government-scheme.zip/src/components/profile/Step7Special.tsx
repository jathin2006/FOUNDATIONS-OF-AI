import React from 'react';
import { ArrowRight, ArrowLeft, HeartHandshake, Home, Tractor, Check } from 'lucide-react';
import { ProfileData, ValidationErrors } from '../../types';

interface Step7Props {
  data: ProfileData;
  updateData: (fields: Partial<ProfileData>) => void;
  errors: ValidationErrors;
  onNext: () => void;
  onBack: () => void;
  isEditingFromReview?: boolean;
  onReturnToReview?: () => void;
}

export const Step7Special: React.FC<Step7Props> = ({
  data,
  updateData,
  errors,
  onNext,
  onBack,
  isEditingFromReview,
  onReturnToReview,
}) => {
  return (
    <div className="space-y-8">
      {/* Step Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-blue-100 text-blue-800">
            Step 7 of 8
          </span>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Eligibility Assessment
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
          Special Conditions
        </h2>
        <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
          These details help us identify additional schemes you may qualify for, including disability pensions, assistive device aid, agricultural grants, and housing subsidies.
        </p>
      </div>

      <div className="space-y-6">
        {/* 1. Person with Disability */}
        <div className="p-5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <HeartHandshake className="w-4 h-4 text-blue-700" />
              <label className="text-sm font-semibold text-slate-800">
                Person with Disability (Divyangjan) <span className="text-red-500">*</span>
              </label>
            </div>
            <p className="text-xs text-slate-500">
              Recognized benchmark disabilities under the Rights of Persons with Disabilities Act.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 max-w-xs">
            {(['Yes', 'No'] as const).map((opt) => (
              <button
                type="button"
                key={opt}
                onClick={() => {
                  updateData({
                    personWithDisability: opt,
                    disabilityPercentage: opt === 'No' ? '' : data.disabilityPercentage,
                  });
                }}
                className={`py-2.5 px-4 rounded-lg text-sm font-medium border text-left flex items-center justify-between transition-all cursor-pointer ${
                  data.personWithDisability === opt
                    ? 'border-blue-600 bg-white text-blue-950 font-bold ring-2 ring-blue-600/20'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <span>{opt}</span>
                <span
                  className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    data.personWithDisability === opt
                      ? 'border-blue-700 bg-blue-700 text-white'
                      : 'border-slate-300 bg-white'
                  }`}
                >
                  {data.personWithDisability === opt && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                </span>
              </button>
            ))}
          </div>
          {errors.personWithDisability && (
            <p className="text-xs text-red-600 font-medium">{errors.personWithDisability}</p>
          )}

          {/* Conditional Field: Disability Percentage */}
          {data.personWithDisability === 'Yes' && (
            <div className="pt-2 border-t border-slate-200/80 max-w-sm animate-fadeIn">
              <label htmlFor="sc-disability-pct" className="block text-sm font-semibold text-slate-800 mb-1">
                Disability Percentage (%) <span className="text-red-500">*</span>
              </label>
              <p className="text-xs text-slate-500 mb-2">
                As certified on your UDID card / medical certificate (40%+ standard benchmark).
              </p>
              <div className="relative">
                <input
                  id="sc-disability-pct"
                  type="number"
                  min="1"
                  max="100"
                  value={data.disabilityPercentage}
                  onChange={(e) => updateData({ disabilityPercentage: e.target.value })}
                  placeholder="e.g. 40"
                  className={`w-full pl-3.5 pr-8 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                    errors.disabilityPercentage
                      ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                      : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                  } text-slate-900 placeholder:text-slate-400 focus:outline-none`}
                />
                <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400 text-sm font-semibold">
                  %
                </span>
              </div>
              {errors.disabilityPercentage && (
                <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.disabilityPercentage}</p>
              )}
            </div>
          )}
        </div>

        {/* 2. Farmer Status */}
        <div className="p-5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Tractor className="w-4 h-4 text-emerald-700" />
              <label className="text-sm font-semibold text-slate-800">
                Are you a Farmer / Engaged in Agricultural Cultivation? <span className="text-red-500">*</span>
              </label>
            </div>
            <p className="text-xs text-slate-500">
              Evaluates eligibility for PM-KISAN, Kisan Credit Card, subsidized inputs, and farm mechanization.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 max-w-xs">
            {(['Yes', 'No'] as const).map((opt) => (
              <button
                type="button"
                key={opt}
                onClick={() => {
                  updateData({
                    isFarmer: opt,
                    ownAgriculturalLand: opt === 'No' ? '' : data.ownAgriculturalLand,
                  });
                }}
                className={`py-2.5 px-4 rounded-lg text-sm font-medium border text-left flex items-center justify-between transition-all cursor-pointer ${
                  data.isFarmer === opt
                    ? 'border-emerald-600 bg-white text-emerald-950 font-bold ring-2 ring-emerald-600/20'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <span>{opt}</span>
                <span
                  className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    data.isFarmer === opt
                      ? 'border-emerald-700 bg-emerald-700 text-white'
                      : 'border-slate-300 bg-white'
                  }`}
                >
                  {data.isFarmer === opt && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                </span>
              </button>
            ))}
          </div>
          {errors.isFarmer && (
            <p className="text-xs text-red-600 font-medium">{errors.isFarmer}</p>
          )}

          {/* Conditional Field: Own Agricultural Land */}
          {data.isFarmer === 'Yes' && (
            <div className="pt-2 border-t border-slate-200/80 max-w-sm animate-fadeIn">
              <label className="block text-sm font-semibold text-slate-800 mb-1">
                Do you Own Agricultural Land? <span className="text-red-500">*</span>
              </label>
              <p className="text-xs text-slate-500 mb-2">
                Select No if tenant farmer or sharecropper.
              </p>
              <div className="grid grid-cols-2 gap-3">
                {(['Yes', 'No'] as const).map((opt) => (
                  <button
                    type="button"
                    key={opt}
                    onClick={() => updateData({ ownAgriculturalLand: opt })}
                    className={`py-2 px-3 rounded-lg text-sm font-medium border text-left flex items-center justify-between transition-all cursor-pointer ${
                      data.ownAgriculturalLand === opt
                        ? 'border-emerald-600 bg-white text-emerald-950 font-bold ring-2 ring-emerald-600/20'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <span>{opt}</span>
                    <span
                      className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        data.ownAgriculturalLand === opt
                          ? 'border-emerald-700 bg-emerald-700 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {data.ownAgriculturalLand === opt && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                    </span>
                  </button>
                ))}
              </div>
              {errors.ownAgriculturalLand && (
                <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.ownAgriculturalLand}</p>
              )}
            </div>
          )}
        </div>

        {/* 3. Own House */}
        <div className="p-5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Home className="w-4 h-4 text-blue-700" />
              <label className="text-sm font-semibold text-slate-800">
                Do you Own a Pucca House / Residential Property? <span className="text-red-500">*</span>
              </label>
            </div>
            <p className="text-xs text-slate-500">
              Crucial criteria for Pradhan Mantri Awas Yojana (PMAY - Urban & Gramin) housing grants and home loan subsidies.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 max-w-xs">
            {(['Yes', 'No'] as const).map((opt) => (
              <button
                type="button"
                key={opt}
                onClick={() => updateData({ ownHouse: opt })}
                className={`py-2.5 px-4 rounded-lg text-sm font-medium border text-left flex items-center justify-between transition-all cursor-pointer ${
                  data.ownHouse === opt
                    ? 'border-blue-600 bg-white text-blue-950 font-bold ring-2 ring-blue-600/20'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <span>{opt}</span>
                <span
                  className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    data.ownHouse === opt
                      ? 'border-blue-700 bg-blue-700 text-white'
                      : 'border-slate-300 bg-white'
                  }`}
                >
                  {data.ownHouse === opt && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                </span>
              </button>
            ))}
          </div>
          {errors.ownHouse && (
            <p className="text-xs text-red-600 font-medium">{errors.ownHouse}</p>
          )}
        </div>
      </div>

      {/* Separated Bottom Navigation Area */}
      <div className="pt-6 mt-8 border-t border-slate-200 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium text-sm hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-2xs flex items-center gap-2 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-3">
          {isEditingFromReview && onReturnToReview && (
            <button
              type="button"
              onClick={onReturnToReview}
              className="px-4 py-2.5 rounded-lg border border-blue-600 text-blue-700 bg-blue-50/50 hover:bg-blue-50 font-semibold text-sm transition-colors cursor-pointer"
            >
              Return to Review
            </button>
          )}

          <button
            type="button"
            onClick={onNext}
            className="px-6 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 active:bg-blue-900 text-white font-semibold text-sm transition-colors shadow-sm flex items-center gap-2 cursor-pointer"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
