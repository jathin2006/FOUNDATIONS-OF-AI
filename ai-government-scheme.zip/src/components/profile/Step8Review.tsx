import React, { useState } from 'react';
import {
  ArrowLeft,
  Edit2,
  User,
  Shield,
  CreditCard,
  GraduationCap,
  Briefcase,
  Users,
  Award,
  Lock,
  Loader2,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { ProfileData, ProfileStep } from '../../types';
import { SubmissionConfirmationModal } from './SubmissionConfirmationModal';

interface Step8Props {
  data: ProfileData;
  onEditStep: (step: ProfileStep) => void;
  onBack: () => void;
  onFindEligibleSchemes?: () => void;
}

export const Step8Review: React.FC<Step8Props> = ({
  data,
  onEditStep,
  onBack,
  onFindEligibleSchemes,
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleFinalSubmit = () => {
    if (onFindEligibleSchemes) {
      onFindEligibleSchemes();
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1200);
  };

  return (
    <div className="space-y-8">
      {/* Step Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-blue-100 text-blue-800">
            Step 8 of 8
          </span>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Final Verification
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
          Review Your Information
        </h2>
        <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
          Please confirm that your assessment details are accurate. You can edit any individual section before initiating scheme matching.
        </p>
      </div>

      {/* Summary Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* 1. Personal Details */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <User className="w-4 h-4 text-blue-700" />
                <span>PERSONAL DETAILS</span>
              </div>
              <button
                type="button"
                onClick={() => onEditStep(1)}
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            </div>
            <dl className="space-y-2 text-xs">
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Name:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.fullName || '—'}</dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Age:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.age ? `${data.age} years` : '—'}</dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Gender:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.gender || '—'}</dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">State:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.state || '—'}</dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">District:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.district || '—'}</dd>
              </div>
            </dl>
          </div>
        </div>

        {/* 2. Social Details */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <Shield className="w-4 h-4 text-blue-700" />
                <span>SOCIAL DETAILS</span>
              </div>
              <button
                type="button"
                onClick={() => onEditStep(2)}
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            </div>
            <dl className="space-y-2 text-xs">
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Religion:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.religion || '—'}</dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Category:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.casteCategory || '—'}</dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Minority Status:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.minorityCommunity || '—'}</dd>
              </div>
            </dl>
          </div>
        </div>

        {/* 3. Financial Details */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <CreditCard className="w-4 h-4 text-blue-700" />
                <span>FINANCIAL DETAILS</span>
              </div>
              <button
                type="button"
                onClick={() => onEditStep(3)}
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            </div>
            <dl className="space-y-2 text-xs">
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Personal Income:</dt>
                <dd className="font-bold text-blue-800 text-right">
                  {data.personalIncome ? `₹ ${data.personalIncome}` : '—'}
                </dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Family Income:</dt>
                <dd className="font-bold text-blue-800 text-right">
                  {data.familyIncome ? `₹ ${data.familyIncome}` : '—'}
                </dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">BPL / Ration Card:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.bplRationCard || '—'}</dd>
              </div>
            </dl>
          </div>
        </div>

        {/* 4. Educational Details */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <GraduationCap className="w-4 h-4 text-blue-700" />
                <span>EDUCATIONAL DETAILS</span>
              </div>
              <button
                type="button"
                onClick={() => onEditStep(4)}
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            </div>
            <dl className="space-y-2 text-xs">
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Level:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.educationLevel || '—'}</dd>
              </div>
              {data.educationLevel !== 'Not Studying' && (
                <div className="flex justify-between py-0.5">
                  <dt className="text-slate-500">Course / Stream:</dt>
                  <dd className="font-semibold text-slate-900 text-right">{data.courseStream || '—'}</dd>
                </div>
              )}
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Current Student:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.currentStudent || '—'}</dd>
              </div>
              {data.currentStudent === 'Yes' && (
                <div className="flex justify-between py-0.5 text-blue-900">
                  <dt className="text-slate-500">Year / Grade:</dt>
                  <dd className="font-bold text-right">{data.currentGradeYear || '—'}</dd>
                </div>
              )}
            </dl>
          </div>
        </div>

        {/* 5. Employment Details */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <Briefcase className="w-4 h-4 text-blue-700" />
                <span>EMPLOYMENT DETAILS</span>
              </div>
              <button
                type="button"
                onClick={() => onEditStep(5)}
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            </div>
            <dl className="space-y-2 text-xs">
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Status:</dt>
                <dd className="font-semibold text-slate-900 text-right">
                  {data.employmentStatus === 'Other' && data.otherEmploymentStatus
                    ? `Other (${data.otherEmploymentStatus})`
                    : data.employmentStatus || '—'}
                </dd>
              </div>
              {data.employmentStatus !== 'Student' && data.employmentStatus !== 'Unemployed' && (
                <div className="flex justify-between py-0.5">
                  <dt className="text-slate-500">Occupation:</dt>
                  <dd className="font-semibold text-slate-900 text-right">{data.occupation || '—'}</dd>
                </div>
              )}
              {data.employmentStatus === 'Farmer' && (
                <div className="flex justify-between py-0.5 text-emerald-800">
                  <dt className="text-slate-500">Agri Land Ownership:</dt>
                  <dd className="font-bold text-right">{data.farmerLandOwnership || '—'}</dd>
                </div>
              )}
            </dl>
          </div>
        </div>

        {/* 6. Family Details */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <Users className="w-4 h-4 text-blue-700" />
                <span>FAMILY DETAILS</span>
              </div>
              <button
                type="button"
                onClick={() => onEditStep(6)}
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            </div>
            <dl className="space-y-2 text-xs">
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Marital Status:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.maritalStatus || '—'}</dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Family Members:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.familyMembersCount || '—'}</dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-slate-500">Earning Members:</dt>
                <dd className="font-semibold text-slate-900 text-right">{data.earningMembersCount || '—'}</dd>
              </div>
            </dl>
          </div>
        </div>

        {/* 7. Special Conditions (Spans 2 cols on md) */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 md:col-span-2">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
            <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
              <Award className="w-4 h-4 text-blue-700" />
              <span>SPECIAL CONDITIONS</span>
            </div>
            <button
              type="button"
              onClick={() => onEditStep(7)}
              className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>Edit</span>
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200/60">
              <span className="text-slate-500 block mb-0.5">Person with Disability:</span>
              <span className="font-bold text-slate-900 text-sm">
                {data.personWithDisability || 'No'}
                {data.personWithDisability === 'Yes' && data.disabilityPercentage && (
                  <span className="text-blue-700 text-xs ml-1 font-semibold">({data.disabilityPercentage}%)</span>
                )}
              </span>
            </div>

            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200/60">
              <span className="text-slate-500 block mb-0.5">Farmer / Cultivator:</span>
              <span className="font-bold text-slate-900 text-sm">
                {data.isFarmer || 'No'}
                {data.isFarmer === 'Yes' && data.ownAgriculturalLand && (
                  <span className="text-emerald-700 text-xs ml-1 font-semibold">(Land: {data.ownAgriculturalLand})</span>
                )}
              </span>
            </div>

            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200/60">
              <span className="text-slate-500 block mb-0.5">Own House:</span>
              <span className="font-bold text-slate-900 text-sm">{data.ownHouse || '—'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Prominent Bottom Action Area */}
      <div className="pt-8 border-t border-slate-200 text-center space-y-4">
        <p className="text-sm text-slate-600 max-w-xl mx-auto leading-relaxed">
          Your information will be used to identify government schemes that may be relevant to your profile.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            type="button"
            onClick={onBack}
            className="w-full sm:w-auto px-5 py-3 rounded-lg border border-slate-300 bg-white text-slate-700 font-semibold text-sm hover:bg-slate-50 transition-colors shadow-2xs flex items-center justify-center gap-2 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Special Conditions</span>
          </button>

          <button
            type="button"
            disabled={isSubmitting}
            onClick={handleFinalSubmit}
            className="w-full sm:w-auto px-8 py-3.5 rounded-lg bg-blue-700 hover:bg-blue-800 active:bg-blue-900 text-white font-bold text-base transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2.5 cursor-pointer"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin text-white" />
                <span>Analyzing Scheme Eligibility...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5" />
                <span>Find My Eligible Schemes</span>
              </>
            )}
          </button>
        </div>

        <div className="flex items-center justify-center gap-2 text-xs text-slate-500 pt-2">
          <Lock className="w-3.5 h-3.5 text-blue-700" />
          <span>Protected under National Citizen Data Privacy Standards • 256-Bit SSL/TLS</span>
        </div>
      </div>

      {/* Confirmation Modal */}
      {isSubmitted && (
        <SubmissionConfirmationModal
          data={data}
          onClose={() => setIsSubmitted(false)}
        />
      )}
    </div>
  );
};
