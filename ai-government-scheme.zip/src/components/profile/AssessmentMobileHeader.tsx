import React from 'react';
import { Check, LogOut, ChevronLeft, ChevronRight } from 'lucide-react';
import { ProfileStep } from '../../types';

interface AssessmentMobileHeaderProps {
  currentStep: ProfileStep;
  onStepClick: (step: ProfileStep) => void;
  maxCompletedStep: number;
  userEmail?: string;
  onExit: () => void;
}

const STEP_NAMES = [
  'Personal Details',
  'Social & Category',
  'Financial Details',
  'Educational Details',
  'Employment Details',
  'Family Details',
  'Special Conditions',
  'Review & Submit',
];

export const AssessmentMobileHeader: React.FC<AssessmentMobileHeaderProps> = ({
  currentStep,
  onStepClick,
  maxCompletedStep,
  userEmail,
  onExit,
}) => {
  const percentComplete = Math.round(((currentStep - 1) / 7) * 100);

  return (
    <div className="lg:hidden bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
      {/* Top row */}
      <div className="px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-md bg-blue-800 text-white flex items-center justify-center flex-shrink-0">
            <svg
              className="w-5 h-5"
              viewBox="0 0 40 40"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M20 7L7 15H33L20 7Z" fill="currentColor" />
              <rect x="8" y="16" width="24" height="2" fill="currentColor" opacity="0.9" />
              <rect x="10" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
              <rect x="16" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
              <rect x="22" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
              <rect x="28" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
              <rect x="7" y="30" width="26" height="3" rx="0.5" fill="currentColor" />
            </svg>
          </div>
          <div>
            <h1 className="text-xs font-bold text-slate-900">Government Scheme Advisor</h1>
            <p className="text-[10px] text-slate-500">Eligibility Assessment</p>
          </div>
        </div>

        <button
          type="button"
          onClick={onExit}
          className="text-xs text-slate-500 hover:text-red-700 font-medium flex items-center gap-1 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Exit</span>
        </button>
      </div>

      {/* Progress sub-bar */}
      <div className="px-4 pb-2.5 pt-1">
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="font-semibold text-slate-800">
            Step {currentStep} of 8: {STEP_NAMES[currentStep - 1]}
          </span>
          <span className="text-blue-700 font-bold">{percentComplete}%</span>
        </div>
        <div className="w-full h-1.5 rounded-full bg-slate-200 overflow-hidden">
          <div
            className="h-full bg-blue-700 rounded-full transition-all duration-300"
            style={{ width: `${percentComplete}%` }}
          />
        </div>
      </div>

      {/* Horizontal pill navigation on mobile */}
      <div className="px-4 pb-2.5 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
        {Array.from({ length: 8 }).map((_, i) => {
          const stepNum = (i + 1) as ProfileStep;
          const isCompleted = stepNum < currentStep || stepNum <= maxCompletedStep;
          const isCurrent = stepNum === currentStep;
          const isClickable = stepNum <= maxCompletedStep || stepNum <= currentStep;

          return (
            <button
              type="button"
              key={stepNum}
              disabled={!isClickable}
              onClick={() => isClickable && onStepClick(stepNum)}
              className={`flex-shrink-0 px-2.5 py-1 rounded text-[11px] font-semibold flex items-center gap-1 border transition-all ${
                isCurrent
                  ? 'bg-blue-700 border-blue-700 text-white'
                  : isCompleted && stepNum < currentStep
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-white border-slate-200 text-slate-500 opacity-70'
              }`}
            >
              {isCompleted && stepNum < currentStep ? (
                <Check className="w-3 h-3 stroke-[3]" />
              ) : (
                <span>{stepNum}</span>
              )}
              <span>{STEP_NAMES[stepNum - 1]?.split(' ')[0]}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
