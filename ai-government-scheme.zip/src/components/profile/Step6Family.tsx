import React from 'react';
import { ArrowRight, ArrowLeft, Heart, Users, Briefcase, Check } from 'lucide-react';
import { ProfileData, ValidationErrors } from '../../types';

interface Step6Props {
  data: ProfileData;
  updateData: (fields: Partial<ProfileData>) => void;
  errors: ValidationErrors;
  onNext: () => void;
  onBack: () => void;
  isEditingFromReview?: boolean;
  onReturnToReview?: () => void;
}

const MARITAL_STATUSES = [
  'Single',
  'Married',
  'Widowed',
  'Divorced',
  'Separated',
] as const;

export const Step6Family: React.FC<Step6Props> = ({
  data,
  updateData,
  errors,
  onNext,
  onBack,
  isEditingFromReview,
  onReturnToReview,
}) => {
  return (
    <div className="space-y-8">
      {/* Step Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-blue-100 text-blue-800">
            Step 6 of 8
          </span>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Eligibility Assessment
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
          Family Details
        </h2>
        <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
          Household size and earning ratio determine per-capita dependency, maternity allowances, widow pensions, and family welfare support.
        </p>
      </div>

      <div className="space-y-6">
        {/* Marital Status */}
        <div>
          <label className="block text-sm font-semibold text-slate-800 mb-1">
            Marital Status <span className="text-red-500">*</span>
          </label>
          <p className="text-xs text-slate-500 mb-2.5">
            Key parameter for dedicated family welfare, widow assistance, and single-parent benefits.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
            {MARITAL_STATUSES.map((status) => (
              <button
                type="button"
                key={status}
                onClick={() => updateData({ maritalStatus: status })}
                className={`py-3 px-3 rounded-lg text-xs sm:text-sm font-medium border text-center transition-all cursor-pointer ${
                  data.maritalStatus === status
                    ? 'border-blue-600 bg-blue-50/60 text-blue-950 font-bold ring-2 ring-blue-600/20'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
          {errors.maritalStatus && (
            <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.maritalStatus}</p>
          )}
        </div>

        {/* 2-Column Grid for Family Count & Earning Count */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Family Members Count */}
          <div>
            <label htmlFor="fm-total" className="block text-sm font-semibold text-slate-800 mb-1">
              Total Number of Family Members <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-slate-500 mb-2">
              Living in the same household (including yourself).
            </p>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Users className="w-4 h-4" />
              </div>
              <input
                id="fm-total"
                type="number"
                min="1"
                max="30"
                value={data.familyMembersCount}
                onChange={(e) => updateData({ familyMembersCount: e.target.value })}
                placeholder="e.g. 4"
                className={`w-full pl-10 pr-3.5 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                  errors.familyMembersCount
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 placeholder:text-slate-400 focus:outline-none`}
              />
            </div>
            {errors.familyMembersCount && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.familyMembersCount}</p>
            )}
          </div>

          {/* Earning Members Count */}
          <div>
            <label htmlFor="fm-earning" className="block text-sm font-semibold text-slate-800 mb-1">
              Number of Earning Members <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-slate-500 mb-2">
              Members with regular wages or business earnings (enter 0 if none).
            </p>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Briefcase className="w-4 h-4" />
              </div>
              <input
                id="fm-earning"
                type="number"
                min="0"
                max="30"
                value={data.earningMembersCount}
                onChange={(e) => updateData({ earningMembersCount: e.target.value })}
                placeholder="e.g. 1"
                className={`w-full pl-10 pr-3.5 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                  errors.earningMembersCount
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 placeholder:text-slate-400 focus:outline-none`}
              />
            </div>
            {errors.earningMembersCount && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.earningMembersCount}</p>
            )}
          </div>
        </div>
      </div>

      {/* Separated Bottom Navigation Area */}
      <div className="pt-6 mt-8 border-t border-slate-200 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium text-sm hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-2xs flex items-center gap-2 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-3">
          {isEditingFromReview && onReturnToReview && (
            <button
              type="button"
              onClick={onReturnToReview}
              className="px-4 py-2.5 rounded-lg border border-blue-600 text-blue-700 bg-blue-50/50 hover:bg-blue-50 font-semibold text-sm transition-colors cursor-pointer"
            >
              Return to Review
            </button>
          )}

          <button
            type="button"
            onClick={onNext}
            className="px-6 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 active:bg-blue-900 text-white font-semibold text-sm transition-colors shadow-sm flex items-center gap-2 cursor-pointer"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
