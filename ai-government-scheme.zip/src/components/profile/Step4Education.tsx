import React, { useEffect } from 'react';
import { ArrowRight, ArrowLeft, BookOpen, Clock, Check } from 'lucide-react';
import { ProfileData, ValidationErrors } from '../../types';

interface Step4Props {
  data: ProfileData;
  updateData: (fields: Partial<ProfileData>) => void;
  errors: ValidationErrors;
  onNext: () => void;
  onBack: () => void;
  isEditingFromReview?: boolean;
  onReturnToReview?: () => void;
}

const EDUCATION_LEVELS = [
  'Primary School',
  'Secondary School',
  'Higher Secondary',
  'Diploma',
  'Undergraduate',
  'Postgraduate',
  'PhD',
  'Not Studying',
] as const;

export const Step4Education: React.FC<Step4Props> = ({
  data,
  updateData,
  errors,
  onNext,
  onBack,
  isEditingFromReview,
  onReturnToReview,
}) => {
  const isNotStudying = data.educationLevel === 'Not Studying';

  // Automatically ensure currentStudent is 'No' whenever 'Not Studying' is selected
  useEffect(() => {
    if (isNotStudying && data.currentStudent !== 'No') {
      updateData({
        currentStudent: 'No',
        currentGradeYear: '',
      });
    }
  }, [isNotStudying, data.currentStudent, updateData]);

  const handleEducationLevelChange = (lvl: typeof EDUCATION_LEVELS[number]) => {
    if (lvl === 'Not Studying') {
      updateData({
        educationLevel: lvl,
        currentStudent: 'No',
        currentGradeYear: '',
      });
    } else {
      updateData({
        educationLevel: lvl,
      });
    }
  };

  return (
    <div className="space-y-8">
      {/* Step Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-blue-100 text-blue-800">
            Step 4 of 8
          </span>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Eligibility Assessment
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
          Educational Details
        </h2>
        <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
          National & state scholarships, free higher education coaching, tuition fee waivers, and apprenticeship stipends rely on your education profile.
        </p>
      </div>

      <div className="space-y-6">
        {/* Highest Completed / Ongoing Education Level */}
        <div>
          <label className="block text-sm font-semibold text-slate-800 mb-1">
            Highest Completed / Ongoing Education Level <span className="text-red-500">*</span>
          </label>
          <p className="text-xs text-slate-500 mb-2.5">
            Select your formal education tier.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {EDUCATION_LEVELS.map((lvl) => (
              <button
                type="button"
                key={lvl}
                onClick={() => handleEducationLevelChange(lvl)}
                className={`py-3 px-3 rounded-lg text-xs sm:text-sm font-medium border text-center transition-all cursor-pointer ${
                  data.educationLevel === lvl
                    ? 'border-blue-600 bg-blue-50/60 text-blue-950 font-bold ring-2 ring-blue-600/20'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
          {errors.educationLevel && (
            <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.educationLevel}</p>
          )}
        </div>

        {/* Course Stream and Student Status */}
        <div className={!isNotStudying ? 'grid grid-cols-1 md:grid-cols-2 gap-6' : 'max-w-md'}>
          {/* Course / Stream / Specialization (Completely hidden when 'Not Studying' is selected) */}
          {!isNotStudying && (
            <div>
              <label htmlFor="e-stream" className="block text-sm font-semibold text-slate-800 mb-1">
                Course / Stream / Specialization <span className="text-red-500">*</span>
              </label>
              <p className="text-xs text-slate-500 mb-2">
                e.g. Science, Commerce, Arts, B.Tech, General, Polytechnic, Medical.
              </p>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <BookOpen className="w-4 h-4" />
                </div>
                <input
                  id="e-stream"
                  type="text"
                  value={data.courseStream}
                  onChange={(e) => updateData({ courseStream: e.target.value })}
                  placeholder="e.g. B.Tech Computer Science or Class 12 Science"
                  className={`w-full pl-10 pr-3.5 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                    errors.courseStream
                      ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                      : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                  } text-slate-900 placeholder:text-slate-400 focus:outline-none`}
                />
              </div>
              {errors.courseStream && (
                <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.courseStream}</p>
              )}
            </div>
          )}

          {/* Current Student (Yes / No) */}
          <div>
            <label className="block text-sm font-semibold text-slate-800 mb-1">
              Are you currently an active student? <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-slate-500 mb-2">
              Indicate whether you are actively enrolled in a recognized institution.
            </p>
            <div className="grid grid-cols-2 gap-3">
              {(['Yes', 'No'] as const).map((opt) => {
                const isYesDisabled = isNotStudying && opt === 'Yes';
                return (
                  <button
                    type="button"
                    key={opt}
                    disabled={isYesDisabled}
                    onClick={() => {
                      if (isYesDisabled) return;
                      updateData({
                        currentStudent: opt,
                        currentGradeYear: opt === 'No' ? '' : data.currentGradeYear,
                      });
                    }}
                    className={`py-2.5 px-4 rounded-lg text-sm font-medium border text-left flex items-center justify-between transition-all ${
                      isYesDisabled
                        ? 'opacity-40 bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed'
                        : 'cursor-pointer hover:border-slate-300 hover:bg-slate-50/50'
                    } ${
                      data.currentStudent === opt
                        ? 'border-blue-600 bg-blue-50/60 text-blue-950 font-semibold ring-2 ring-blue-600/20'
                        : isYesDisabled
                        ? ''
                        : 'border-slate-200 bg-white text-slate-700'
                    }`}
                  >
                    <span>{opt}</span>
                    <span
                      className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        data.currentStudent === opt
                          ? 'border-blue-700 bg-blue-700 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {data.currentStudent === opt && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                    </span>
                  </button>
                );
              })}
            </div>
            {errors.currentStudent && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.currentStudent}</p>
            )}
          </div>
        </div>

        {/* Conditional Field: Current Year / Grade (Only if Current Student = Yes and not 'Not Studying') */}
        {!isNotStudying && data.currentStudent === 'Yes' && (
          <div className="p-4 sm:p-5 rounded-xl border border-blue-200 bg-blue-50/40 space-y-2 animate-fadeIn max-w-md">
            <label htmlFor="e-grade-year" className="block text-sm font-semibold text-blue-950">
              Current Year / Grade <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-blue-800/80">
              Required for pre-matric, post-matric, or final-year scholarship grants.
            </p>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Clock className="w-4 h-4" />
              </div>
              <input
                id="e-grade-year"
                type="text"
                value={data.currentGradeYear}
                onChange={(e) => updateData({ currentGradeYear: e.target.value })}
                placeholder="e.g. 2nd Year, 4th Semester, Class 10, Final Year"
                className={`w-full pl-10 pr-3.5 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                  errors.currentGradeYear
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 placeholder:text-slate-400 focus:outline-none`}
              />
            </div>
            {errors.currentGradeYear && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.currentGradeYear}</p>
            )}
          </div>
        )}
      </div>

      {/* Separated Bottom Navigation Area */}
      <div className="pt-6 mt-8 border-t border-slate-200 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium text-sm hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-2xs flex items-center gap-2 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-3">
          {isEditingFromReview && onReturnToReview && (
            <button
              type="button"
              onClick={onReturnToReview}
              className="px-4 py-2.5 rounded-lg border border-blue-600 text-blue-700 bg-blue-50/50 hover:bg-blue-50 font-semibold text-sm transition-colors cursor-pointer"
            >
              Return to Review
            </button>
          )}

          <button
            type="button"
            onClick={onNext}
            className="px-6 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 active:bg-blue-900 text-white font-semibold text-sm transition-colors shadow-sm flex items-center gap-2 cursor-pointer"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
