import React from 'react';
import { ArrowRight, ArrowLeft, CreditCard, Check } from 'lucide-react';
import { ProfileData, ValidationErrors } from '../../types';

interface Step3Props {
  data: ProfileData;
  updateData: (fields: Partial<ProfileData>) => void;
  errors: ValidationErrors;
  onNext: () => void;
  onBack: () => void;
  isEditingFromReview?: boolean;
  onReturnToReview?: () => void;
}

const formatIndianCurrency = (val: string): string => {
  const clean = val.replace(/\D/g, '');
  if (!clean) return '';
  const num = parseInt(clean, 10);
  if (isNaN(num)) return '';
  return num.toLocaleString('en-IN');
};

const getLakhsHelper = (val: string): string => {
  const clean = val.replace(/\D/g, '');
  const num = parseInt(clean, 10);
  if (isNaN(num) || num <= 0) return '';
  if (num >= 10000000) {
    return `≈ ₹ ${(num / 10000000).toFixed(2)} Crore / year`;
  }
  if (num >= 100000) {
    return `≈ ₹ ${(num / 100000).toFixed(2)} Lakhs / year`;
  }
  return `≈ ₹ ${num.toLocaleString('en-IN')} / year`;
};

export const Step3Financial: React.FC<Step3Props> = ({
  data,
  updateData,
  errors,
  onNext,
  onBack,
  isEditingFromReview,
  onReturnToReview,
}) => {
  const handleIncomeChange = (field: 'personalIncome' | 'familyIncome', raw: string) => {
    const formatted = formatIndianCurrency(raw);
    updateData({ [field]: formatted });
  };

  return (
    <div className="space-y-8">
      {/* Step Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-blue-100 text-blue-800">
            Step 3 of 8
          </span>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Eligibility Assessment
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
          Financial Details
        </h2>
        <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
          Income thresholds govern income certificate ceilings, interest subsidies, fee concessions, and direct benefit transfers (DBT).
        </p>
      </div>

      <div className="space-y-6">
        {/* 2-Column Grid for Incomes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Personal Annual Income */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="f-personal-income" className="block text-sm font-semibold text-slate-800">
                Personal Annual Income <span className="text-red-500">*</span>
              </label>
              {data.personalIncome && (
                <span className="text-xs font-bold text-blue-700">
                  {getLakhsHelper(data.personalIncome)}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mb-2">
              Enter individual income (enter 0 if dependent or student).
            </p>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-600 font-bold text-base">
                ₹
              </div>
              <input
                id="f-personal-income"
                type="text"
                value={data.personalIncome}
                onChange={(e) => handleIncomeChange('personalIncome', e.target.value)}
                placeholder="e.g. 1,50,000"
                className={`w-full pl-9 pr-3.5 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                  errors.personalIncome
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 placeholder:text-slate-400 focus:outline-none font-medium`}
              />
            </div>
            {errors.personalIncome && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.personalIncome}</p>
            )}

            {/* Quick chips */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {['0', '1,20,000', '2,50,000', '5,00,000', '8,00,000'].map((chip) => (
                <button
                  type="button"
                  key={chip}
                  onClick={() => updateData({ personalIncome: chip === '0' ? '0' : chip })}
                  className="text-[11px] py-0.5 px-2 rounded-md bg-slate-100 border border-slate-200 text-slate-700 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-800 transition-colors cursor-pointer"
                >
                  {chip === '0' ? '₹ 0 (No Income)' : `₹ ${chip}`}
                </button>
              ))}
            </div>
          </div>

          {/* Family Annual Income */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="f-family-income" className="block text-sm font-semibold text-slate-800">
                Family Annual Income (Household) <span className="text-red-500">*</span>
              </label>
              {data.familyIncome && (
                <span className="text-xs font-bold text-blue-700">
                  {getLakhsHelper(data.familyIncome)}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mb-2">
              Combined annual income of all household earning members.
            </p>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-600 font-bold text-base">
                ₹
              </div>
              <input
                id="f-family-income"
                type="text"
                value={data.familyIncome}
                onChange={(e) => handleIncomeChange('familyIncome', e.target.value)}
                placeholder="e.g. 3,50,000"
                className={`w-full pl-9 pr-3.5 py-2.5 text-sm bg-white rounded-lg border transition-colors ${
                  errors.familyIncome
                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                    : 'border-slate-300 hover:border-slate-400 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                } text-slate-900 placeholder:text-slate-400 focus:outline-none font-medium`}
              />
            </div>
            {errors.familyIncome && (
              <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.familyIncome}</p>
            )}

            <div className="flex flex-wrap gap-1.5 mt-2">
              {['1,00,000', '2,50,000', '4,50,000', '8,00,000', '12,00,000'].map((chip) => (
                <button
                  type="button"
                  key={chip}
                  onClick={() => updateData({ familyIncome: chip })}
                  className="text-[11px] py-0.5 px-2 rounded-md bg-slate-100 border border-slate-200 text-slate-700 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-800 transition-colors cursor-pointer"
                >
                  ₹ {chip}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* BPL / Ration Card Holder */}
        <div>
          <label className="block text-sm font-semibold text-slate-800 mb-1">
            Do you or your family hold a BPL / Priority Ration Card? <span className="text-red-500">*</span>
          </label>
          <p className="text-xs text-slate-500 mb-2.5">
            Below Poverty Line (BPL), Antyodaya Anna Yojana (AAY / Yellow card), or Priority Household (PHH) card.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-sm">
            {(['Yes', 'No'] as const).map((opt) => (
              <button
                type="button"
                key={opt}
                onClick={() => updateData({ bplRationCard: opt })}
                className={`py-3 px-4 rounded-lg text-sm font-medium border text-left flex items-center justify-between transition-all cursor-pointer ${
                  data.bplRationCard === opt
                    ? 'border-blue-600 bg-blue-50/60 text-blue-950 font-semibold ring-2 ring-blue-600/20'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                <span>{opt}</span>
                <span
                  className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    data.bplRationCard === opt
                      ? 'border-blue-700 bg-blue-700 text-white'
                      : 'border-slate-300 bg-white'
                  }`}
                >
                  {data.bplRationCard === opt && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                </span>
              </button>
            ))}
          </div>
          {errors.bplRationCard && (
            <p className="mt-1.5 text-xs text-red-600 font-medium">{errors.bplRationCard}</p>
          )}
        </div>
      </div>

      {/* Separated Bottom Navigation Area */}
      <div className="pt-6 mt-8 border-t border-slate-200 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium text-sm hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-2xs flex items-center gap-2 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-3">
          {isEditingFromReview && onReturnToReview && (
            <button
              type="button"
              onClick={onReturnToReview}
              className="px-4 py-2.5 rounded-lg border border-blue-600 text-blue-700 bg-blue-50/50 hover:bg-blue-50 font-semibold text-sm transition-colors cursor-pointer"
            >
              Return to Review
            </button>
          )}

          <button
            type="button"
            onClick={onNext}
            className="px-6 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 active:bg-blue-900 text-white font-semibold text-sm transition-colors shadow-sm flex items-center gap-2 cursor-pointer"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
