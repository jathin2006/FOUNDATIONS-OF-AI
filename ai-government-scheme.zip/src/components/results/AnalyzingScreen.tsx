import React, { useEffect, useState } from 'react';
import { Check, Loader2, ShieldCheck, FileSearch } from 'lucide-react';

interface AnalyzingScreenProps {
  onComplete: () => void;
}

interface StepItem {
  id: number;
  label: string;
}

const ANALYSIS_STEPS: StepItem[] = [
  { id: 1, label: 'Personal information verified' },
  { id: 2, label: 'Social and category information checked' },
  { id: 3, label: 'Financial information analyzed' },
  { id: 4, label: 'Education and employment details checked' },
  { id: 5, label: 'Matching scheme eligibility criteria...' },
];

export const AnalyzingScreen: React.FC<AnalyzingScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [activeStepIndex, setActiveStepIndex] = useState(0);

  useEffect(() => {
    // Total duration ~2.8 seconds
    const intervalTime = 35;
    const increment = 100 / (2800 / intervalTime);

    const timer = setInterval(() => {
      setProgress((prev) => {
        const next = Math.min(100, prev + increment);

        // Update step checklist based on progress percentage
        if (next >= 85) {
          setActiveStepIndex(4); // Step 5 in progress or done
        } else if (next >= 65) {
          setActiveStepIndex(3);
        } else if (next >= 40) {
          setActiveStepIndex(2);
        } else if (next >= 20) {
          setActiveStepIndex(1);
        } else {
          setActiveStepIndex(0);
        }

        if (next >= 100) {
          clearInterval(timer);
          setTimeout(() => {
            onComplete();
          }, 350);
          return 100;
        }
        return next;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between font-sans text-slate-800">
      {/* Top Simple Header */}
      <header className="bg-white border-b border-slate-200 py-3.5 px-4 sm:px-8">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-md bg-blue-800 text-white flex items-center justify-center flex-shrink-0">
              <svg className="w-5 h-5" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 7L7 15H33L20 7Z" fill="currentColor" />
                <rect x="8" y="16" width="24" height="2" fill="currentColor" opacity="0.9" />
                <rect x="10" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="16" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="22" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="28" y="19" width="3" height="10" rx="0.5" fill="currentColor" />
                <rect x="7" y="30" width="26" height="3" rx="0.5" fill="currentColor" />
              </svg>
            </div>
            <div>
              <h1 className="text-xs sm:text-sm font-bold text-slate-900">Government Scheme Advisor</h1>
              <p className="text-[10px] text-slate-500 font-medium">Eligibility Evaluation Engine</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600 bg-slate-100 py-1 px-2.5 rounded-full">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-700" />
            <span className="hidden sm:inline">Rule-Based Evaluation</span>
          </div>
        </div>
      </header>

      {/* Main Analysis Container */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-8">
        <div className="w-full max-w-xl bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-10 text-center">
          {/* Professional Circular Progress Visualization */}
          <div className="relative w-24 h-24 mx-auto mb-6 flex items-center justify-center">
            {/* Background SVG Circle */}
            <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="42"
                stroke="currentColor"
                strokeWidth="7"
                className="text-slate-100"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r="42"
                stroke="currentColor"
                strokeWidth="7"
                strokeDasharray="263.89"
                strokeDashoffset={263.89 - (263.89 * Math.round(progress)) / 100}
                strokeLinecap="round"
                className="text-blue-700 transition-all duration-75"
                fill="transparent"
              />
            </svg>

            {/* Inner Icon / Percentage */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-xl font-bold text-slate-900 tracking-tight">
                {Math.round(progress)}%
              </span>
              <span className="text-[10px] text-slate-400 font-medium uppercase">
                {progress === 100 ? 'Ready' : 'Checking'}
              </span>
            </div>
          </div>

          {/* Heading & Subtitle */}
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Analyzing Your Eligibility
          </h2>
          <p className="text-sm text-slate-600 mt-2 max-w-md mx-auto leading-relaxed">
            We&apos;re comparing your profile with available government schemes.
          </p>

          {/* Linear Progress Bar */}
          <div className="mt-6 mb-8 max-w-md mx-auto">
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200/80">
              <div
                className="h-full bg-blue-700 rounded-full transition-all duration-100"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-xs text-slate-500 mt-2">
              <span className="font-medium text-slate-700">
                {progress < 100 ? 'Analyzing government schemes...' : 'Evaluation complete! Preparing dashboard...'}
              </span>
              <span className="font-bold text-blue-700">{Math.round(progress)}%</span>
            </div>
          </div>

          {/* Analysis Checklist Steps */}
          <div className="bg-slate-50 rounded-xl border border-slate-200/80 p-4 sm:p-5 text-left space-y-2.5 max-w-md mx-auto text-xs sm:text-sm">
            {ANALYSIS_STEPS.map((step, idx) => {
              const isFinished = activeStepIndex > idx || progress === 100;
              const isCurrent = activeStepIndex === idx && progress < 100;

              return (
                <div key={step.id} className="flex items-center gap-3">
                  <div
                    className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 text-xs transition-colors ${
                      isFinished
                        ? 'bg-emerald-600 text-white'
                        : isCurrent
                        ? 'bg-blue-100 text-blue-700 border border-blue-400'
                        : 'bg-slate-200 text-slate-400'
                    }`}
                  >
                    {isFinished ? (
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    ) : isCurrent ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <span className="text-[10px]">{step.id}</span>
                    )}
                  </div>
                  <span
                    className={`transition-colors ${
                      isFinished
                        ? 'text-slate-800 font-medium'
                        : isCurrent
                        ? 'text-blue-900 font-semibold'
                        : 'text-slate-400'
                    }`}
                  >
                    {step.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </main>

      {/* Footer Disclaimer */}
      <footer className="py-4 border-t border-slate-200 text-center text-xs text-slate-400">
        <p>National Citizen Scheme Evaluation Gateway • Official Rules-Based Engine</p>
      </footer>
    </div>
  );
};
