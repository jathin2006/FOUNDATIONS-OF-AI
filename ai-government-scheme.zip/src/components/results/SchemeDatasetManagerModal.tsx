import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  Download,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Database,
  ShieldCheck,
  FileCode,
  ExternalLink,
  Info,
  Server,
  Layers,
  Sparkles,
  HelpCircle,
} from 'lucide-react';
import { SchemeDatasetMetadata, SchemeImportResult } from '../../types';
import {
  importGovernmentSchemes,
  resetToOfficialDatabase,
  exportSchemesAsJSON,
  getDatasetMetadata,
} from '../../services/schemeDatabaseService';

interface SchemeDatasetManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDatasetUpdated: () => void;
}

export const SchemeDatasetManagerModal: React.FC<SchemeDatasetManagerModalProps> = ({
  isOpen,
  onClose,
  onDatasetUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'info' | 'import' | 'schema'>('info');
  const [jsonInput, setJsonInput] = useState('');
  const [importResult, setImportResult] = useState<SchemeImportResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [resetMessage, setResetMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const metadata: SchemeDatasetMetadata = getDatasetMetadata();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setImportResult(null);
    setResetMessage(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const result = importGovernmentSchemes(text);
        setImportResult(result);
        if (result.success) {
          onDatasetUpdated();
        }
      } catch (err) {
        setImportResult({
          success: false,
          importedCount: 0,
          skippedCount: 0,
          errors: ['Failed to read or parse JSON file: ' + (err as Error).message],
          totalDatabaseCount: metadata.totalSchemesCount,
        });
      } finally {
        setIsProcessing(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  const handleJsonPasteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!jsonInput.trim()) return;

    setIsProcessing(true);
    setImportResult(null);
    setResetMessage(null);

    try {
      const result = importGovernmentSchemes(jsonInput);
      setImportResult(result);
      if (result.success) {
        onDatasetUpdated();
        setJsonInput('');
      }
    } catch (err) {
      setImportResult({
        success: false,
        importedCount: 0,
        skippedCount: 0,
        errors: ['Error parsing input: ' + (err as Error).message],
        totalDatabaseCount: metadata.totalSchemesCount,
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleResetDatabase = () => {
    const confirmReset = window.confirm(
      'Are you sure you want to restore the official verified database snapshot? Any custom imported schemes will be removed.'
    );
    if (!confirmReset) return;

    const count = resetToOfficialDatabase();
    setResetMessage(`Successfully restored official verified baseline. Database active with ${count} verified schemes.`);
    setImportResult(null);
    onDatasetUpdated();
  };

  const handleExportJSON = () => {
    const jsonStr = exportSchemesAsJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `government_schemes_verified_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const sampleJsonTemplate = `[
  {
    "id": "pm-awas-sample",
    "name": "Pradhan Mantri Awas Yojana (PMAY)",
    "schemeName": "Pradhan Mantri Awas Yojana",
    "department": "Ministry of Housing and Urban Affairs",
    "ministry": "Ministry of Housing and Urban Affairs",
    "governmentLevel": "Central",
    "state": "All",
    "category": "Housing",
    "benefits": [
      "Financial assistance up to ₹1,30,000 for house construction"
    ],
    "familyIncomeLimit": 300000,
    "bplRequirement": true,
    "requiredDocuments": [
      "Aadhaar Card",
      "BPL / Priority Ration Card",
      "Bank Account Passbook"
    ],
    "applicationProcess": [
      "Apply online via pmaymis.gov.in or nearest CSC"
    ],
    "officialUrl": "https://pmaymis.gov.in",
    "sourceUrl": "https://www.myscheme.gov.in/schemes/pmay-g",
    "lastUpdated": "2026-03-01",
    "activeStatus": true,
    "isVerifiedOfficial": true
  }
]`;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs text-slate-800"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[90vh] bg-white rounded-2xl border border-slate-200 shadow-2xl flex flex-col overflow-hidden text-sm"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-[#F8FAFC] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-50 text-blue-900 border border-blue-200">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <span>Government Scheme Database Architecture</span>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-300">
                  myScheme Sync
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Scalable registry supporting 5,000+ real verified Central & State Government programs
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-5 gap-2 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('info')}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'info'
                ? 'border-blue-900 text-blue-900 font-bold bg-white -mb-[1px] rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            <span>Dataset Overview & Stats</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('import')}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'import'
                ? 'border-blue-900 text-blue-900 font-bold bg-white -mb-[1px] rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import Dataset (.json)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('schema')}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'schema'
                ? 'border-blue-900 text-blue-900 font-bold bg-white -mb-[1px] rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Schema Reference</span>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* TAB 1: DATASET OVERVIEW & STATS */}
          {activeTab === 'info' && (
            <div className="space-y-5">
              {/* Authenticity Guarantee Card */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-blue-50/80 to-slate-50 border border-blue-200/80 space-y-2">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-800" />
                  <span className="font-bold text-blue-950 text-xs uppercase tracking-wider">
                    Official Authenticity Guarantee
                  </span>
                </div>
                <p className="text-xs text-blue-950/90 leading-relaxed">
                  In compliance with official government dataset standards, this platform does not generate or invent fake placeholder schemes. All entries originate from verified official sources including{' '}
                  <a
                    href="https://www.myscheme.gov.in"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-bold underline text-blue-900 inline-flex items-center gap-0.5 hover:text-blue-700"
                  >
                    <span>myScheme.gov.in</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>{' '}
                  and respective Union Ministries.
                </p>
              </div>

              {/* Statistics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    Total Loaded
                  </span>
                  <div className="text-2xl font-extrabold text-[#0F2942]">
                    {metadata.totalSchemesCount}
                  </div>
                  <span className="text-[10px] text-slate-500 font-medium">In active database</span>
                </div>

                <div className="p-3.5 rounded-xl bg-emerald-50/60 border border-emerald-200 space-y-1">
                  <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block">
                    Verified Real
                  </span>
                  <div className="text-2xl font-extrabold text-emerald-800">
                    {metadata.verifiedOfficialCount}
                  </div>
                  <span className="text-[10px] text-emerald-700 font-medium">100% Verified data</span>
                </div>

                <div className="p-3.5 rounded-xl bg-blue-50/60 border border-blue-200 space-y-1">
                  <span className="text-[11px] font-bold text-blue-800 uppercase tracking-wider block">
                    Central Schemes
                  </span>
                  <div className="text-2xl font-extrabold text-blue-900">
                    {metadata.centralSchemesCount}
                  </div>
                  <span className="text-[10px] text-blue-700 font-medium">Union Ministries</span>
                </div>

                <div className="p-3.5 rounded-xl bg-amber-50/60 border border-amber-200 space-y-1">
                  <span className="text-[11px] font-bold text-amber-800 uppercase tracking-wider block">
                    State / UT Schemes
                  </span>
                  <div className="text-2xl font-extrabold text-amber-900">
                    {metadata.stateSchemesCount}
                  </div>
                  <span className="text-[10px] text-amber-700 font-medium">State Governments</span>
                </div>
              </div>

              {/* Meta details list */}
              <div className="rounded-xl border border-slate-200 overflow-hidden divide-y divide-slate-100 text-xs">
                <div className="p-3 flex items-center justify-between bg-slate-50/50">
                  <span className="text-slate-500 font-medium">Source Registry</span>
                  <span className="font-semibold text-slate-800">{metadata.sourceName}</span>
                </div>
                <div className="p-3 flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Official Portal Link</span>
                  <a
                    href={metadata.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-bold text-blue-800 hover:underline inline-flex items-center gap-1"
                  >
                    <span>{metadata.sourceUrl}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <div className="p-3 flex items-center justify-between bg-slate-50/50">
                  <span className="text-slate-500 font-medium">Last Synchronized Snapshot</span>
                  <span className="font-semibold text-slate-800">{metadata.lastSynchronized}</span>
                </div>
                <div className="p-3 flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Database Architecture Capacity</span>
                  <span className="font-bold text-emerald-800">5,000+ Schemes Scalable (Deterministic Engine)</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleExportJSON}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold text-xs transition-colors cursor-pointer shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  <span>Download Active Dataset (.json)</span>
                </button>

                <button
                  type="button"
                  onClick={handleResetDatabase}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-800 border border-slate-200 hover:border-rose-200 font-semibold text-xs transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restore Official Baseline Snapshot</span>
                </button>
              </div>

              {resetMessage && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-600" />
                  <span>{resetMessage}</span>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: IMPORT DATASET */}
          {activeTab === 'import' && (
            <div className="space-y-5">
              <div className="p-4 rounded-xl bg-blue-50 border border-blue-200/80 text-xs text-blue-900 space-y-1">
                <p className="font-bold flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-blue-800 flex-shrink-0" />
                  <span>Bulk Government Scheme Import Service</span>
                </p>
                <p className="leading-relaxed">
                  Import official scheme datasets in JSON format (such as <code>government_schemes.json</code>).
                  The import validator strictly verifies data authenticity and rejects placeholder names
                  (e.g., &quot;Government Scheme 001&quot;).
                </p>
              </div>

              {/* Option A: File Upload */}
              <div className="p-5 rounded-2xl border-2 border-dashed border-slate-300 hover:border-blue-800 bg-slate-50 text-center space-y-3 transition-colors">
                <div className="mx-auto w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-blue-900 shadow-2xs">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-800 text-sm">Upload Government Schemes JSON</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Select a .json file containing verified scheme records
                  </p>
                </div>

                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".json,application/json"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="scheme-file-upload"
                  />
                  <label
                    htmlFor="scheme-file-upload"
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0F2942] hover:bg-[#15385B] text-white font-semibold text-xs cursor-pointer shadow-xs transition-colors"
                  >
                    <span>Choose JSON File</span>
                  </label>
                </div>
              </div>

              {/* Option B: Direct JSON Paste */}
              <form onSubmit={handleJsonPasteSubmit} className="space-y-3">
                <div className="flex items-center justify-between">
                  <label htmlFor="json-paste-input" className="text-xs font-bold text-slate-700">
                    Or Paste JSON Schemes Dataset Directly:
                  </label>
                  <button
                    type="button"
                    onClick={() => setJsonInput(sampleJsonTemplate)}
                    className="text-[11px] font-semibold text-blue-800 hover:underline cursor-pointer"
                  >
                    Load Sample Verified Record
                  </button>
                </div>

                <textarea
                  id="json-paste-input"
                  rows={6}
                  value={jsonInput}
                  onChange={(e) => setJsonInput(e.target.value)}
                  placeholder="Paste JSON array of scheme objects here..."
                  className="w-full p-3 font-mono text-xs rounded-xl border border-slate-300 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/30 focus:border-blue-900 text-slate-800"
                />

                <div className="flex items-center justify-end gap-2">
                  <button
                    type="submit"
                    disabled={isProcessing || !jsonInput.trim()}
                    className="px-5 py-2 rounded-xl bg-[#0F2942] hover:bg-[#15385B] text-white font-semibold text-xs disabled:opacity-50 cursor-pointer shadow-xs transition-colors"
                  >
                    {isProcessing ? 'Validating & Importing...' : 'Validate & Import Schemes'}
                  </button>
                </div>
              </form>

              {/* Import Results Banner */}
              {importResult && (
                <div
                  className={`p-4 rounded-xl border text-xs space-y-2 ${
                    importResult.success
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                      : 'bg-rose-50 border-rose-300 text-rose-900'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold text-sm">
                    {importResult.success ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0" />
                    )}
                    <span>
                      {importResult.success
                        ? `Import Successful: Added ${importResult.importedCount} scheme(s)!`
                        : 'Import Failed / Criteria Not Met'}
                    </span>
                  </div>

                  <p className="leading-relaxed">
                    Total Schemes Now in Database: <strong>{importResult.totalDatabaseCount}</strong>
                    {importResult.skippedCount > 0 && ` • Skipped: ${importResult.skippedCount}`}
                  </p>

                  {importResult.errors.length > 0 && (
                    <div className="p-2.5 rounded-lg bg-white/70 border border-slate-200/80 space-y-1 mt-2">
                      <span className="font-bold block text-slate-800">Validation Notice / Errors:</span>
                      <ul className="list-disc pl-4 space-y-0.5 text-slate-700">
                        {importResult.errors.map((err, idx) => (
                          <li key={idx}>{err}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SCHEMA REFERENCE */}
          {activeTab === 'schema' && (
            <div className="space-y-4">
              <div className="space-y-1">
                <h4 className="font-bold text-slate-900 text-sm">Official Scheme JSON Schema</h4>
                <p className="text-xs text-slate-500">
                  Each scheme supports rich demographic, financial, and criteria fields for deterministic rule evaluation:
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900 text-slate-100 font-mono text-[11px] overflow-x-auto max-h-72 leading-relaxed">
                <pre>{sampleJsonTemplate}</pre>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="font-bold text-slate-800">Supported Criteria Fields:</span>
                  <p className="text-slate-600 leading-normal">
                    <code>minimumAge</code>, <code>maximumAge</code>, <code>gender</code>, <code>casteCategory</code>,{' '}
                    <code>familyIncomeLimit</code>, <code>bplRequirement</code>, <code>studentRequirement</code>,{' '}
                    <code>educationRequirement</code>, <code>farmerRequirement</code>, <code>disabilityRequirement</code>
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="font-bold text-slate-800">Rule Generation:</span>
                  <p className="text-slate-600 leading-normal">
                    Schemes with structured criteria automatically synthesize rigorous, mandatory evaluation rules.
                    Missing criteria are never assumed eligible.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>Official Government Registry Architecture</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#0F2942] hover:bg-[#15385B] text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
