import React from 'react';
import {
  AlertTriangle,
  ExternalLink,
  X,
  Building2,
  Globe,
  ShieldAlert,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { GovernmentScheme } from '../../types';
import { ValidatedSchemeUrl, getUnavailableNoticeDetails } from '../../utils/urlValidator';

interface SchemeUrlNoticeModalProps {
  scheme: GovernmentScheme | null;
  targetUrlInfo?: ValidatedSchemeUrl | null;
  onClose: () => void;
}

export const SchemeUrlNoticeModal: React.FC<SchemeUrlNoticeModalProps> = ({
  scheme,
  targetUrlInfo,
  onClose,
}) => {
  if (!scheme) return null;

  const notice = getUnavailableNoticeDetails(scheme, targetUrlInfo);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="url-notice-title"
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-start justify-between gap-3 bg-amber-50/70">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-100 text-amber-800 border border-amber-200/80 flex-shrink-0">
              <AlertTriangle className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800">
                Official Portal Status Notice
              </span>
              <h3 id="url-notice-title" className="text-base font-bold text-slate-900 leading-tight">
                {notice.title}
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-700">
          {/* Scheme Information */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/90 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Scheme Name
            </span>
            <div className="font-bold text-slate-900 text-sm leading-snug">
              {notice.schemeName}
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 pt-0.5">
              <Building2 className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              <span>{notice.department}</span>
            </div>
          </div>

          {/* Attempted URL Details */}
          {notice.attemptedUrl && (
            <div className="p-3 rounded-xl bg-slate-100/80 border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Destination Address in Scheme Record
              </span>
              <div className="font-mono text-[11px] text-slate-800 break-all flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                <span>{notice.attemptedUrl}</span>
              </div>
            </div>
          )}

          {/* Explanation Alert */}
          <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 space-y-2">
            <div className="flex items-center gap-2 font-bold text-amber-900">
              <ShieldAlert className="w-4 h-4 text-amber-700 flex-shrink-0" />
              <span>Server Availability Advisory</span>
            </div>
            <p className="text-xs leading-relaxed text-amber-900/90">
              {notice.reason}
            </p>
          </div>

          {/* User Reassurance */}
          <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200/70 text-blue-950 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-blue-700 flex-shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed text-blue-900">
              This message indicates that the destination government server is temporarily unreachable or requires verification. <strong>Your eligibility results and profile criteria remain completely unaffected.</strong>
            </p>
          </div>

          {/* Next Steps / Suggested Portals */}
          <div className="space-y-2 pt-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
              Official Verification Options
            </span>

            <div className="space-y-2">
              {/* Suggested Ministry / Alternative Portal */}
              {notice.suggestedAlternative && (
                <a
                  href={notice.suggestedAlternative.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 flex items-center justify-between text-slate-800 transition-colors cursor-pointer group"
                >
                  <div className="space-y-0.5">
                    <span className="font-semibold text-blue-900 group-hover:underline block">
                      {notice.suggestedAlternative.label}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {notice.suggestedAlternative.url}
                    </span>
                  </div>
                  <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-blue-900 flex-shrink-0" />
                </a>
              )}

              {/* Source URL reference (myScheme) */}
              {notice.sourceUrl && (
                <a
                  href={notice.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 flex items-center justify-between text-slate-800 transition-colors cursor-pointer group"
                >
                  <div className="space-y-0.5">
                    <span className="font-semibold text-blue-900 group-hover:underline block">
                      myScheme National Government Repository
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {notice.sourceUrl}
                    </span>
                  </div>
                  <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-blue-900 flex-shrink-0" />
                </a>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-3">
          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Official Government Source Safety Check</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
