import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  X,
  ExternalLink,
  CheckCircle2,
  XCircle,
  FileText,
  Building2,
  Calendar,
  AlertCircle,
  Award,
  Layers,
  ArrowRight,
  ShieldCheck,
  Check,
  Info,
  Globe,
  AlertTriangle,
} from 'lucide-react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { EvaluatedScheme, GovernmentScheme } from '../../types';
import { getSchemeUrlSummary, ValidatedSchemeUrl } from '../../utils/urlValidator';
import { SchemeUrlNoticeModal } from './SchemeUrlNoticeModal';

interface SchemeDetailsModalProps {
  evaluatedScheme: EvaluatedScheme | null;
  onClose: () => void;
}

const getStructuredEligibilityList = (scheme: GovernmentScheme): string[] => {
  if (scheme.eligibilityCriteria && scheme.eligibilityCriteria.length > 0) {
    return scheme.eligibilityCriteria;
  }
  const items: string[] = [];
  if (scheme.minimumAge || scheme.maximumAge) {
    if (scheme.minimumAge && scheme.maximumAge) {
      items.push(`Age Requirement: Between ${scheme.minimumAge} and ${scheme.maximumAge} years`);
    } else if (scheme.minimumAge) {
      items.push(`Age Requirement: Minimum ${scheme.minimumAge} years`);
    } else if (scheme.maximumAge) {
      items.push(`Age Requirement: Maximum ${scheme.maximumAge} years`);
    }
  }
  if (scheme.gender && scheme.gender !== 'All') {
    const g = Array.isArray(scheme.gender) ? scheme.gender.join(', ') : scheme.gender;
    items.push(`Target Gender: ${g}`);
  }
  if (scheme.casteCategory && scheme.casteCategory !== 'All') {
    const c = Array.isArray(scheme.casteCategory) ? scheme.casteCategory.join(', ') : scheme.casteCategory;
    items.push(`Social Category: ${c}`);
  }
  if (scheme.religion && scheme.religion !== 'All') {
    const r = Array.isArray(scheme.religion) ? scheme.religion.join(', ') : scheme.religion;
    items.push(`Community / Religion: ${r}`);
  }
  if (scheme.familyIncomeLimit) {
    items.push(`Family Annual Income Ceiling: ₹ ${scheme.familyIncomeLimit.toLocaleString('en-IN')}`);
  }
  if (scheme.personalIncomeLimit) {
    items.push(`Personal Annual Income Ceiling: ₹ ${scheme.personalIncomeLimit.toLocaleString('en-IN')}`);
  }
  if (scheme.bplRequirement === true || scheme.bplRequirement === 'Yes') {
    items.push('Economic Status: Priority BPL or Antyodaya household ration card');
  }
  if (scheme.educationRequirement) {
    const ed = Array.isArray(scheme.educationRequirement)
      ? scheme.educationRequirement.join(', ')
      : scheme.educationRequirement;
    items.push(`Education Level: ${ed}`);
  }
  if (scheme.studentRequirement === true || scheme.studentRequirement === 'Yes') {
    items.push('Student Status: Actively enrolled student in an accredited institution');
  }
  if (scheme.employmentRequirement) {
    const emp = Array.isArray(scheme.employmentRequirement)
      ? scheme.employmentRequirement.join(', ')
      : scheme.employmentRequirement;
    items.push(`Employment Category: ${emp}`);
  }
  if (scheme.farmerRequirement === true || scheme.farmerRequirement === 'Yes') {
    items.push('Agricultural Status: Verified cultivator or farmer');
  }
  if (scheme.landOwnershipRequirement === true || scheme.landOwnershipRequirement === 'Yes') {
    items.push('Land Holding: Ownership or operational holding of cultivable agricultural land');
  }
  if (scheme.maritalStatus && scheme.maritalStatus !== 'All') {
    const m = Array.isArray(scheme.maritalStatus) ? scheme.maritalStatus.join(', ') : scheme.maritalStatus;
    items.push(`Marital Status: ${m}`);
  }
  if (scheme.disabilityRequirement === true || scheme.disabilityRequirement === 'Yes') {
    items.push(
      `Disability Status: Benchmark Person with Disability (PwD${
        scheme.disabilityPercentage ? ` ≥ ${scheme.disabilityPercentage}%` : ''
      })`
    );
  }
  return items;
};

export const SchemeDetailsModal: React.FC<SchemeDetailsModalProps> = ({
  evaluatedScheme,
  onClose,
}) => {
  const [activeNoticeUrl, setActiveNoticeUrl] = useState<ValidatedSchemeUrl | null>(null);
  const [showNoticeModal, setShowNoticeModal] = useState(false);

  const shouldReduceMotion = useReducedMotion();
  const modalCardRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const previousActiveElementRef = useRef<HTMLElement | null>(null);

  // Capture active element before opening modal, lock background scroll, handle focus trap and Escape
  useEffect(() => {
    if (evaluatedScheme) {
      previousActiveElementRef.current = document.activeElement as HTMLElement | null;
      document.body.style.overflow = 'hidden';

      // Focus close button or card when opened
      const focusTimer = setTimeout(() => {
        closeButtonRef.current?.focus();
      }, 50);

      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          if (showNoticeModal) {
            setShowNoticeModal(false);
            setActiveNoticeUrl(null);
          } else {
            onClose();
          }
          return;
        }

        // Focus trap inside modal
        if (e.key === 'Tab' && modalCardRef.current && !showNoticeModal) {
          const focusableElements = modalCardRef.current.querySelectorAll<HTMLElement>(
            'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
          );

          if (focusableElements.length > 0) {
            const first = focusableElements[0];
            const last = focusableElements[focusableElements.length - 1];

            if (e.shiftKey) {
              if (document.activeElement === first) {
                last.focus();
                e.preventDefault();
              }
            } else {
              if (document.activeElement === last) {
                first.focus();
                e.preventDefault();
              }
            }
          }
        }
      };

      window.addEventListener('keydown', handleKeyDown);

      return () => {
        clearTimeout(focusTimer);
        window.removeEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'unset';
        previousActiveElementRef.current?.focus?.();
      };
    }
  }, [evaluatedScheme, showNoticeModal, onClose]);

  const handleBackdropClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (e.target === e.currentTarget && !showNoticeModal) {
        onClose();
      }
    },
    [onClose, showNoticeModal]
  );

  return (
    <AnimatePresence>
      {evaluatedScheme && (
        <motion.div
          key="scheme-details-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: shouldReduceMotion ? 0.05 : 0.28, ease: [0.16, 1, 0.3, 1] }}
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-[5px] overflow-hidden"
          onClick={handleBackdropClick}
          role="dialog"
          aria-modal="true"
          aria-labelledby="scheme-details-title"
        >
          <motion.div
            ref={modalCardRef}
            tabIndex={-1}
            key="scheme-details-dialog"
            initial={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.94, y: 20 }}
            animate={shouldReduceMotion ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }}
            exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 15 }}
            transition={{ duration: shouldReduceMotion ? 0.05 : 0.32, ease: [0.16, 1, 0.3, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-[850px] max-h-[88vh] bg-white rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200/90 flex flex-col text-slate-800 overflow-hidden outline-none"
          >
            {/* STICKY TOP HEADER */}
            <div className="p-5 sm:p-6 border-b border-slate-200 bg-white sticky top-0 z-20 shadow-2xs">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-2 flex-1 min-w-0">
                  {/* Category, Level, Verification & Status Badges */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[11px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded bg-blue-50 text-blue-900 border border-blue-200">
                      {evaluatedScheme.scheme.category}
                    </span>

                    <span className="text-[11px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded bg-indigo-50 text-indigo-900 border border-indigo-200">
                      {evaluatedScheme.scheme.governmentLevel === 'State' ||
                      evaluatedScheme.scheme.governmentLevel === 'UT'
                        ? `State (${evaluatedScheme.scheme.state || 'All States'})`
                        : 'Central Govt'}
                    </span>

                    {evaluatedScheme.scheme.isVerifiedOfficial !== false && (
                      <span className="text-[11px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-300 inline-flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-emerald-600" />
                        <span>Verified Official</span>
                      </span>
                    )}

                    <span
                      className={`text-[11px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded border inline-flex items-center gap-1.5 ${
                        evaluatedScheme.status === 'Potentially Eligible'
                          ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                          : evaluatedScheme.status === 'Partial Match'
                          ? 'bg-amber-50 text-amber-900 border-amber-300'
                          : 'bg-slate-100 text-slate-700 border-slate-300'
                      }`}
                    >
                      {evaluatedScheme.status === 'Potentially Eligible' ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                      ) : evaluatedScheme.status === 'Partial Match' ? (
                        <AlertCircle className="w-3.5 h-3.5 text-amber-700" />
                      ) : (
                        <XCircle className="w-3.5 h-3.5 text-slate-500" />
                      )}
                      <span>
                        {evaluatedScheme.status} ({evaluatedScheme.matchScore}% Match)
                      </span>
                    </span>
                  </div>

                  {/* Title & Ministry */}
                  <h2
                    id="scheme-details-title"
                    className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight leading-snug"
                  >
                    {evaluatedScheme.scheme.name}
                  </h2>

                  <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
                    <Building2 className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                    <span>
                      {evaluatedScheme.scheme.department}
                      {evaluatedScheme.scheme.ministry &&
                        evaluatedScheme.scheme.ministry !== evaluatedScheme.scheme.department &&
                        ` • ${evaluatedScheme.scheme.ministry}`}
                    </span>
                  </div>
                </div>

                {/* Close Button */}
                <button
                  ref={closeButtonRef}
                  type="button"
                  onClick={onClose}
                  className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer flex-shrink-0"
                  aria-label="Close scheme details modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* SCROLLABLE MODAL CONTENT BODY */}
            <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 text-sm leading-relaxed overscroll-contain">
              {/* ELIGIBILITY SUMMARY CARD */}
              <div className="rounded-2xl border border-blue-200/90 bg-gradient-to-br from-blue-50/70 via-indigo-50/40 to-white p-5 sm:p-6 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-blue-900">
                        Citizen Eligibility Assessment
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border ${
                          evaluatedScheme.status === 'Potentially Eligible'
                            ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            : evaluatedScheme.status === 'Partial Match'
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : 'bg-slate-100 text-slate-700 border-slate-300'
                        }`}
                      >
                        {evaluatedScheme.status}
                      </span>
                    </div>

                    <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                      {evaluatedScheme.matchScore}% Criteria Match
                    </h3>

                    <p className="text-xs text-slate-600">
                      {evaluatedScheme.matchedRules.length} of{' '}
                      {evaluatedScheme.matchedRules.length + evaluatedScheme.unmetRules.length}{' '}
                      evaluated administrative criteria satisfied.
                    </p>
                  </div>

                  {/* Criteria Fulfillment Count Widget */}
                  <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 pt-2 sm:pt-0 border-blue-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      Evaluation Score
                    </span>
                    <span className="text-lg font-bold text-blue-950">
                      {evaluatedScheme.matchedRules.length}/
                      {evaluatedScheme.matchedRules.length + evaluatedScheme.unmetRules.length} Criteria Met
                    </span>
                  </div>
                </div>

                {/* Animated Match Progress Bar */}
                <div className="space-y-1.5">
                  <div className="w-full bg-slate-200/90 rounded-full h-3 overflow-hidden shadow-inner p-0.5">
                    <motion.div
                      initial={shouldReduceMotion ? { width: `${evaluatedScheme.matchScore}%` } : { width: '0%' }}
                      animate={{ width: `${evaluatedScheme.matchScore}%` }}
                      transition={{
                        duration: shouldReduceMotion ? 0.05 : 0.75,
                        delay: shouldReduceMotion ? 0 : 0.15,
                        ease: [0.16, 1, 0.3, 1],
                      }}
                      className={`h-full rounded-full transition-all ${
                        evaluatedScheme.matchScore >= 75
                          ? 'bg-gradient-to-r from-emerald-500 to-emerald-600'
                          : evaluatedScheme.matchScore >= 50
                          ? 'bg-gradient-to-r from-amber-500 to-amber-600'
                          : 'bg-gradient-to-r from-slate-400 to-slate-500'
                      }`}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] font-medium text-slate-500">
                    <span>0%</span>
                    <span>50%</span>
                    <span>100% Criteria Match</span>
                  </div>
                </div>

                {/* Disclaimer */}
                <div className="flex items-start gap-2.5 p-3 rounded-xl bg-white/90 border border-blue-200/70 text-xs text-slate-600">
                  <Info className="w-4 h-4 text-blue-800 flex-shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong className="text-slate-800">Important Advisory:</strong> The criteria match percentage
                    reflects deterministic alignment with published departmental requirements. Final benefit
                    sanction and disbursement are subject to official verification by the concerned government authority.
                  </p>
                </div>
              </div>

              {/* 1. ABOUT THE SCHEME */}
              <section className="space-y-2">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-800" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    About the Scheme
                  </h3>
                </div>
                <div className="text-slate-700 leading-relaxed text-sm bg-slate-50/70 p-4 rounded-xl border border-slate-200/80">
                  {evaluatedScheme.scheme.detailedDescription || evaluatedScheme.scheme.description ? (
                    <p>{evaluatedScheme.scheme.detailedDescription || evaluatedScheme.scheme.description}</p>
                  ) : (
                    <p className="text-slate-400 italic">Information not available in the current dataset.</p>
                  )}
                </div>
              </section>

              {/* 2. KEY BENEFITS & FINANCIAL ASSISTANCE */}
              <section className="space-y-3">
                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-blue-800" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    Key Benefits & Financial Assistance
                  </h3>
                </div>
                {evaluatedScheme.scheme.benefits && evaluatedScheme.scheme.benefits.length > 0 ? (
                  <div className="bg-slate-50/70 border border-slate-200/80 rounded-xl p-4 space-y-2.5">
                    {evaluatedScheme.scheme.benefits.map((benefit, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-800">
                        <span className="w-2 h-2 rounded-full bg-blue-800 mt-1.5 flex-shrink-0" />
                        <span className="leading-relaxed">{benefit}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 italic p-3 bg-slate-50 rounded-xl border border-slate-200">
                    Information not available in the current dataset.
                  </p>
                )}
              </section>

              {/* 3. ELIGIBILITY REQUIREMENTS */}
              <section className="space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-800" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    Eligibility Requirements
                  </h3>
                </div>
                {(() => {
                  const eligList = getStructuredEligibilityList(evaluatedScheme.scheme);
                  return eligList.length > 0 ? (
                    <div className="bg-slate-50/70 border border-slate-200/80 rounded-xl p-4 space-y-2">
                      {eligList.map((crit, idx) => (
                        <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-800">
                          <Check className="w-3.5 h-3.5 text-blue-800 stroke-[3] mt-0.5 flex-shrink-0" />
                          <span className="leading-relaxed">{crit}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500 italic p-3 bg-slate-50 rounded-xl border border-slate-200">
                      Information not available in the current dataset.
                    </p>
                  );
                })()}
              </section>

              {/* 4. YOUR CRITERIA MATCH BREAKDOWN */}
              <section className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-blue-800" />
                    <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                      Your Criteria Match Breakdown
                    </h3>
                  </div>
                  <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-md">
                    {evaluatedScheme.matchedRules.length} of{' '}
                    {evaluatedScheme.matchedRules.length + evaluatedScheme.unmetRules.length} criteria fulfilled
                  </span>
                </div>

                <div className="space-y-2.5">
                  {/* Satisfied Conditions */}
                  {evaluatedScheme.matchedRules.map((rule, idx) => (
                    <div
                      key={`match-${idx}`}
                      className="p-3.5 rounded-xl bg-emerald-50/60 border border-emerald-200/90 text-xs flex items-start gap-3 transition-colors hover:bg-emerald-50"
                    >
                      <div className="p-1 rounded-full bg-emerald-100 text-emerald-800 flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <strong className="text-emerald-950 font-bold text-sm">
                            {rule.label}
                          </strong>
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 uppercase">
                            Fulfilled
                          </span>
                        </div>
                        <p className="text-emerald-900/90 leading-relaxed">
                          {rule.reason}
                        </p>
                      </div>
                    </div>
                  ))}

                  {/* Conditions Not Met */}
                  {evaluatedScheme.unmetRules.map((rule, idx) => (
                    <div
                      key={`unmet-${idx}`}
                      className={`p-3.5 rounded-xl text-xs flex items-start gap-3 transition-colors ${
                        rule.isMandatory
                          ? 'bg-rose-50/60 border border-rose-200/90 hover:bg-rose-50'
                          : 'bg-amber-50/60 border border-amber-200/90 hover:bg-amber-50'
                      }`}
                    >
                      <div
                        className={`p-1 rounded-full flex-shrink-0 mt-0.5 ${
                          rule.isMandatory
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {rule.isMandatory ? (
                          <XCircle className="w-4 h-4 text-rose-700" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-amber-700" />
                        )}
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <strong
                            className={`font-bold text-sm ${
                              rule.isMandatory ? 'text-rose-950' : 'text-amber-950'
                            }`}
                          >
                            {rule.label}
                          </strong>
                          <div className="flex items-center gap-1.5">
                            {rule.isMandatory && (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-200 text-rose-900 border border-rose-300 uppercase">
                                Mandatory Condition
                              </span>
                            )}
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                                rule.isMandatory
                                  ? 'bg-rose-100 text-rose-800 border-rose-200'
                                  : 'bg-amber-100 text-amber-800 border-amber-200'
                              }`}
                            >
                              {rule.isMandatory ? 'Not Met' : 'Unmatched'}
                            </span>
                          </div>
                        </div>
                        <p
                          className={`leading-relaxed ${
                            rule.isMandatory ? 'text-rose-900/90' : 'text-amber-900/90'
                          }`}
                        >
                          {rule.reason}
                        </p>
                      </div>
                    </div>
                  ))}

                  {evaluatedScheme.matchedRules.length === 0 && evaluatedScheme.unmetRules.length === 0 && (
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-slate-500 text-xs text-center">
                      Universal citizen criteria apply to all verified applicants.
                    </div>
                  )}
                </div>
              </section>

              {/* 5. REQUIRED DOCUMENTS */}
              <section className="space-y-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-800" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    Required Documents Checklist
                  </h3>
                </div>
                {evaluatedScheme.scheme.requiredDocuments &&
                evaluatedScheme.scheme.requiredDocuments.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {evaluatedScheme.scheme.requiredDocuments.map((doc, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-white border border-slate-200 text-xs text-slate-700 flex items-start gap-2.5 shadow-2xs hover:border-blue-300 transition-colors"
                      >
                        <FileText className="w-4 h-4 text-blue-800 flex-shrink-0 mt-0.5" />
                        <span className="leading-snug">{doc}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 italic p-3 bg-slate-50 rounded-xl border border-slate-200">
                    Information not available in the current dataset.
                  </p>
                )}
              </section>

              {/* 6. HOW TO APPLY */}
              <section className="space-y-3">
                <div className="flex items-center gap-2">
                  <ArrowRight className="w-4 h-4 text-blue-800" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    How to Apply: Step-by-Step Procedure
                  </h3>
                </div>
                {evaluatedScheme.scheme.applicationProcess &&
                evaluatedScheme.scheme.applicationProcess.length > 0 ? (
                  <ol className="space-y-2.5 text-xs text-slate-700">
                    {evaluatedScheme.scheme.applicationProcess.map((step, idx) => (
                      <li
                        key={idx}
                        className="flex items-start gap-3 p-3 rounded-xl bg-slate-50/70 border border-slate-200/80 hover:bg-slate-50 transition-colors"
                      >
                        <span className="w-5 h-5 rounded-full bg-blue-900 text-white font-bold flex items-center justify-center flex-shrink-0 text-[11px] shadow-xs">
                          {idx + 1}
                        </span>
                        <span className="mt-0.5 leading-relaxed font-medium">{step}</span>
                      </li>
                    ))}
                  </ol>
                ) : (
                  <p className="text-xs text-slate-500 italic p-3 bg-slate-50 rounded-xl border border-slate-200">
                    Information not available in the current dataset.
                  </p>
                )}
              </section>

              {/* 7. IMPORTANT NOTES & OFFICIAL PORTALS */}
              <section className="space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-slate-200">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Important Notes & Official Portals
                  </h3>
                  <span className="text-[11px] font-semibold text-slate-500">
                    Government Endpoints
                  </span>
                </div>

                {(() => {
                  const urlSummary = getSchemeUrlSummary(evaluatedScheme.scheme);
                  return (
                    <div className="space-y-3">
                      {/* Official Information Website Card */}
                      <div className="p-3.5 rounded-xl border bg-slate-50 border-slate-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-bold text-slate-800">
                              Official Information Website
                            </span>
                            {urlSummary.officialWebsite?.status === 'verified' ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 inline-flex items-center gap-1">
                                <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                                <span>Verified Government Portal</span>
                              </span>
                            ) : urlSummary.officialWebsite?.status === 'unavailable' ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 inline-flex items-center gap-1">
                                <AlertTriangle className="w-2.5 h-2.5 text-amber-700" />
                                <span>Requires Verification</span>
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
                                Status: {urlSummary.officialWebsite?.status || 'Unknown'}
                              </span>
                            )}
                          </div>

                          {urlSummary.officialWebsite ? (
                            <div className="font-mono text-xs text-slate-600 break-all flex items-center gap-1.5">
                              <Globe className="w-3 h-3 text-slate-400 flex-shrink-0" />
                              <span>{urlSummary.officialWebsite.url}</span>
                            </div>
                          ) : (
                            <div className="text-xs text-slate-500 italic">
                              No official portal address published by department.
                            </div>
                          )}

                          {urlSummary.officialWebsite?.status === 'unavailable' && (
                            <p className="text-[11px] text-amber-900 bg-amber-50 p-2 rounded-lg border border-amber-200 mt-1 leading-relaxed">
                              {urlSummary.officialWebsite.unavailableReason ||
                                'Official website is currently unreachable. Please verify through the concerned Government Department.'}
                            </p>
                          )}
                        </div>

                        <div className="flex-shrink-0">
                          {urlSummary.officialWebsite?.status === 'verified' ? (
                            <a
                              href={urlSummary.officialWebsite.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-3.5 py-1.5 rounded-lg bg-blue-900 hover:bg-blue-950 text-white font-semibold text-xs transition-colors inline-flex items-center gap-1.5 shadow-xs cursor-pointer"
                            >
                              <span>Open Official Website</span>
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          ) : urlSummary.officialWebsite?.status === 'unavailable' ||
                            urlSummary.officialWebsite?.status === 'needs_verification' ? (
                            <button
                              type="button"
                              onClick={() => {
                                setActiveNoticeUrl(urlSummary.officialWebsite);
                                setShowNoticeModal(true);
                              }}
                              className="px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs transition-colors inline-flex items-center gap-1.5 shadow-xs cursor-pointer"
                            >
                              <span>Check Status Notice</span>
                              <AlertTriangle className="w-3.5 h-3.5" />
                            </button>
                          ) : null}
                        </div>
                      </div>

                      {/* Official Application Portal (if separate) */}
                      {urlSummary.hasSeparateApplicationPortal && urlSummary.officialApplication && (
                        <div className="p-3.5 rounded-xl border bg-emerald-50/50 border-emerald-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs font-bold text-emerald-950">
                                Official Application Portal
                              </span>
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-200/80 text-emerald-900 border border-emerald-300 inline-flex items-center gap-1">
                                <CheckCircle2 className="w-2.5 h-2.5 text-emerald-700" />
                                <span>Direct Online Application</span>
                              </span>
                            </div>
                            <div className="font-mono text-xs text-emerald-900/90 break-all flex items-center gap-1.5">
                              <Globe className="w-3 h-3 text-emerald-600 flex-shrink-0" />
                              <span>{urlSummary.officialApplication.url}</span>
                            </div>
                          </div>

                          <a
                            href={urlSummary.officialApplication.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-shrink-0 px-3.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs transition-colors inline-flex items-center gap-1.5 shadow-xs cursor-pointer"
                          >
                            <span>Apply Online</span>
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      )}

                      {/* Department Jurisdiction Card */}
                      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                            Administrative Jurisdiction
                          </span>
                          <span className="text-[11px] font-semibold text-slate-600">
                            {evaluatedScheme.scheme.governmentLevel === 'State' ||
                            evaluatedScheme.scheme.governmentLevel === 'UT'
                              ? `State Government • ${evaluatedScheme.scheme.state || 'All States'}`
                              : 'Central Government of India'}
                          </span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                          <div>
                            <span className="text-slate-400 block text-[10px] uppercase font-bold">
                              Nodal Department
                            </span>
                            <span className="font-semibold text-slate-800">
                              {evaluatedScheme.scheme.department}
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[10px] uppercase font-bold">
                              Ministry / Authority
                            </span>
                            <span className="font-semibold text-slate-800">
                              {evaluatedScheme.scheme.ministry || evaluatedScheme.scheme.department}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </section>
            </div>

            {/* STICKY BOTTOM ACTION FOOTER */}
            {(() => {
              const urlSummary = getSchemeUrlSummary(evaluatedScheme.scheme);
              const officialWebsiteUrl =
                urlSummary.officialWebsite?.url ||
                evaluatedScheme.scheme.officialWebsite ||
                evaluatedScheme.scheme.officialUrl;
              const isVerifiedWebsite = urlSummary.officialWebsite?.status === 'verified';
              const isUnavailableOrNeedsNotice =
                urlSummary.officialWebsite?.status === 'unavailable' ||
                urlSummary.officialWebsite?.status === 'needs_verification';
              const hasValidWebsiteUrl = Boolean(officialWebsiteUrl && /^https?:\/\//i.test(officialWebsiteUrl));

              return (
                <div className="p-4 sm:p-5 border-t border-slate-200 bg-[#F8FAFC] sticky bottom-0 z-20 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-xs text-slate-500 order-2 sm:order-1 w-full sm:w-auto justify-center sm:justify-start">
                    {evaluatedScheme.scheme.lastUpdated && (
                      <>
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>Last updated: {evaluatedScheme.scheme.lastUpdated}</span>
                      </>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 sm:gap-3 w-full sm:w-auto order-1 sm:order-2 justify-end">
                    <button
                      type="button"
                      onClick={onClose}
                      className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-700 font-semibold text-xs hover:bg-slate-50 transition-colors cursor-pointer shadow-2xs"
                    >
                      Close
                    </button>

                    {urlSummary.hasSeparateApplicationPortal && urlSummary.officialApplication && (
                      <a
                        href={urlSummary.officialApplication.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs transition-colors shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span>Apply Online</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}

                    {isVerifiedWebsite && officialWebsiteUrl ? (
                      <a
                        href={officialWebsiteUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-950 active:bg-slate-900 text-white font-semibold text-xs transition-colors shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span>Visit Official Website</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    ) : isUnavailableOrNeedsNotice ? (
                      <button
                        type="button"
                        onClick={() => {
                          setActiveNoticeUrl(urlSummary.officialWebsite);
                          setShowNoticeModal(true);
                        }}
                        className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white font-semibold text-xs transition-colors shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                        title="Official website is currently unavailable. Click for details."
                      >
                        <span>Official Website (Unavailable)</span>
                        <AlertTriangle className="w-3.5 h-3.5" />
                      </button>
                    ) : hasValidWebsiteUrl ? (
                      <a
                        href={officialWebsiteUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-950 active:bg-slate-900 text-white font-semibold text-xs transition-colors shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span>Visit Official Website</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    ) : (
                      <button
                        type="button"
                        disabled
                        className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-slate-200 text-slate-400 font-semibold text-xs cursor-not-allowed flex items-center justify-center gap-1.5"
                        title="Official website URL is not available"
                      >
                        <span>Visit Official Website</span>
                        <ExternalLink className="w-3.5 h-3.5 opacity-50" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })()}
          </motion.div>
        </motion.div>
      )}

      {/* URL Notice Modal for unavailable / unverified portals */}
      {showNoticeModal && (
        <SchemeUrlNoticeModal
          scheme={evaluatedScheme?.scheme || null}
          targetUrlInfo={activeNoticeUrl}
          onClose={() => {
            setShowNoticeModal(false);
            setActiveNoticeUrl(null);
          }}
        />
      )}
    </AnimatePresence>
  );
};
