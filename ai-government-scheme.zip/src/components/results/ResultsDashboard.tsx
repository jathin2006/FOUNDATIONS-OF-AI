import React, { useState, useMemo } from 'react';
import {
  Search,
  CheckCircle2,
  AlertCircle,
  XCircle,
  ExternalLink,
  Edit3,
  RotateCcw,
  Building2,
  ChevronRight,
  ShieldCheck,
  Award,
  Layers,
  Sparkles,
  ArrowRight,
  User,
  FileText,
  Bell,
  HelpCircle,
  Check,
  X,
  Filter,
  PhoneCall,
  Clock,
  Landmark,
  BadgeCheck,
  Database,
  AlertTriangle,
  Globe,
} from 'lucide-react';
import { EvaluatedScheme, GovernmentScheme, ProfileData, SchemeCategory } from '../../types';
import { evaluateProfileEligibility } from '../../services/eligibilityEngine';
import { SchemeDetailsModal } from './SchemeDetailsModal';
import { SchemeUrlNoticeModal } from './SchemeUrlNoticeModal';
import { getDatasetMetadata } from '../../services/schemeDatabaseService';
import { isStateMatching, normalizeState, isSchemeApplicableToUserState } from '../../utils/stateNormalizer';
import { getSchemeUrlSummary, ValidatedSchemeUrl } from '../../utils/urlValidator';

interface ResultsDashboardProps {
  profileData: ProfileData;
  userEmail?: string;
  onEditProfile: () => void;
  onSignOut: () => void;
}

export const ResultsDashboard: React.FC<ResultsDashboardProps> = ({
  profileData,
  userEmail,
  onEditProfile,
  onSignOut,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('All');
  const [selectedGovernmentLevel, setSelectedGovernmentLevel] = useState<'All' | 'Central' | 'State'>('All');
  const [activeTab, setActiveTab] = useState<'All' | 'Potentially Eligible' | 'Partial Match' | 'Not Matching'>('All');
  const [sortBy, setSortBy] = useState<'score-desc' | 'score-asc' | 'name-asc'>('score-desc');
  const [selectedSchemeForModal, setSelectedSchemeForModal] = useState<EvaluatedScheme | null>(null);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [urlNoticeScheme, setUrlNoticeScheme] = useState<GovernmentScheme | null>(null);
  const [urlNoticeTarget, setUrlNoticeTarget] = useState<ValidatedSchemeUrl | null>(null);
  const [datasetVersionKey, setDatasetVersionKey] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 8;

  // Retrieve citizen profile state dynamically
  const userState = profileData.state?.trim() || '';

  // Retrieve current scheme dataset metadata dynamically
  const metadata = useMemo(() => {
    return getDatasetMetadata();
  }, [datasetVersionKey]);

  // Deterministic rule-based evaluation of user's profile against scheme database
  const evaluationSummary = useMemo(() => {
    return evaluateProfileEligibility(profileData);
  }, [profileData, datasetVersionKey]);

  // Scoped schemes strictly based on Government Level and Citizen's State/UT residency
  // TEST 1: State / UT -> Only user's state schemes (e.g. Tamil Nadu)
  // TEST 2: Central -> Only Central Government schemes
  // TEST 3: All Levels -> Central schemes + user's state schemes (unrelated states are excluded)
  const levelScopedSchemes = useMemo(() => {
    return evaluationSummary.evaluatedSchemes.filter((item) => {
      const isCentral = item.scheme.governmentLevel === 'Central';
      const isStateOrUt = item.scheme.governmentLevel === 'State' || item.scheme.governmentLevel === 'UT';
      const matchesUserState = isStateMatching(item.scheme.state, userState);

      // Central Government filter
      if (selectedGovernmentLevel === 'Central') {
        return isCentral;
      }

      // State / UT filter: strictly user's profile state
      if (selectedGovernmentLevel === 'State') {
        if (!userState) return isStateOrUt;
        return isStateOrUt && matchesUserState;
      }

      // All Levels filter: Central schemes + User's State/UT schemes
      // Excludes other states' schemes (e.g. West Bengal, Maharashtra, Karnataka) from relevant recommendations
      if (!userState) return true;
      return isCentral || (isStateOrUt && matchesUserState);
    });
  }, [evaluationSummary.evaluatedSchemes, selectedGovernmentLevel, userState]);

  // Dynamic counts calculated from the level & state scoped schemes
  const dynamicCounts = useMemo(() => {
    const total = levelScopedSchemes.length;
    const eligible = levelScopedSchemes.filter((s) => s.status === 'Potentially Eligible').length;
    const partial = levelScopedSchemes.filter((s) => s.status === 'Partial Match').length;
    const notMatching = levelScopedSchemes.filter((s) => s.status === 'Not Matching').length;

    return {
      total,
      eligible,
      partial,
      notMatching,
    };
  }, [levelScopedSchemes]);

  // Guidance indication message reflecting current Level filter and user's state
  const levelIndicationText = useMemo(() => {
    if (selectedGovernmentLevel === 'Central') {
      return 'Showing Central Government schemes';
    }
    if (selectedGovernmentLevel === 'State') {
      return userState
        ? `Showing State/UT schemes for ${userState}`
        : 'Showing State/UT schemes';
    }
    return userState
      ? `Showing Central Government schemes and ${userState} State/UT schemes`
      : 'Showing Central Government schemes and State/UT schemes';
  }, [selectedGovernmentLevel, userState]);

  // Extract unique categories available in level-scoped schemes
  const availableCategories = useMemo(() => {
    const cats = new Set<string>();
    levelScopedSchemes.forEach((item) => cats.add(item.scheme.category));
    return ['All', ...Array.from(cats).sort()];
  }, [levelScopedSchemes]);

  // Extract unique departments available in level-scoped schemes
  const availableDepartments = useMemo(() => {
    const depts = new Set<string>();
    levelScopedSchemes.forEach((item) => {
      if (item.scheme.department) depts.add(item.scheme.department);
    });
    return ['All', ...Array.from(depts).sort()];
  }, [levelScopedSchemes]);

  // Filter and sort schemes from levelScopedSchemes
  const filteredSchemes = useMemo(() => {
    return levelScopedSchemes
      .filter((item) => {
        // Tab / Status filter
        if (activeTab !== 'All' && item.status !== activeTab) {
          return false;
        }

        // Search query filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchName = item.scheme.name.toLowerCase().includes(q);
          const matchDept = item.scheme.department.toLowerCase().includes(q);
          const matchDesc = item.scheme.description.toLowerCase().includes(q);
          const matchCategory = item.scheme.category.toLowerCase().includes(q);
          const matchState = (item.scheme.state || '').toLowerCase().includes(q);
          if (!matchName && !matchDept && !matchDesc && !matchCategory && !matchState) {
            return false;
          }
        }

        // Category filter
        if (selectedCategory !== 'All' && item.scheme.category !== selectedCategory) {
          return false;
        }

        // Department filter
        if (selectedDepartment !== 'All' && item.scheme.department !== selectedDepartment) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'score-desc') {
          return b.matchScore - a.matchScore;
        }
        if (sortBy === 'score-asc') {
          return a.matchScore - b.matchScore;
        }
        if (sortBy === 'name-asc') {
          return a.scheme.name.localeCompare(b.scheme.name);
        }
        return 0;
      });
  }, [
    levelScopedSchemes,
    activeTab,
    searchQuery,
    selectedCategory,
    selectedDepartment,
    sortBy,
  ]);

  // Reset pagination when any filter changes
  React.useEffect(() => {
    setCurrentPage(1);
  }, [
    searchQuery,
    selectedCategory,
    selectedDepartment,
    selectedGovernmentLevel,
    activeTab,
    sortBy,
  ]);

  const totalPages = Math.ceil(filteredSchemes.length / ITEMS_PER_PAGE) || 1;
  const paginatedSchemes = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredSchemes.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredSchemes, currentPage]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedDepartment('All');
    setSelectedGovernmentLevel('All');
    setActiveTab('All');
    setSortBy('score-desc');
    setCurrentPage(1);
  };

  const isFiltersActive =
    searchQuery.trim() !== '' ||
    selectedCategory !== 'All' ||
    selectedDepartment !== 'All' ||
    selectedGovernmentLevel !== 'All' ||
    activeTab !== 'All';

  // User Initial for avatar
  const userName = profileData.fullName?.trim() || userEmail?.split('@')[0] || 'V Gokulan';
  const userInitial = userName.charAt(0).toUpperCase();

  // Percentage of eligible schemes
  const totalSchemes = dynamicCounts.total || 1;
  const eligiblePercentage = Math.round(
    (dynamicCounts.eligible / totalSchemes) * 100
  );

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#0F1E36] font-sans flex flex-col justify-between selection:bg-blue-100 selection:text-blue-900">
      {/* ==================================================
          1. HEADER
         ================================================== */}
      <header className="bg-white border-b border-slate-200/90 sticky top-0 z-30 shadow-[0_1px_3px_rgba(0,0,0,0.03)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
          {/* Left: Emblem and Service Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#0F2942] text-white flex items-center justify-center flex-shrink-0 shadow-xs border border-blue-900/30">
              {/* Dignified Government Emblem Icon */}
              <svg className="w-5 h-5" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 5L6 14H34L20 5Z" fill="currentColor" />
                <rect x="7" y="15" width="26" height="2" fill="currentColor" opacity="0.9" />
                <rect x="9" y="18" width="3.5" height="12" rx="0.5" fill="currentColor" />
                <rect x="15.5" y="18" width="3.5" height="12" rx="0.5" fill="currentColor" />
                <rect x="21" y="18" width="3.5" height="12" rx="0.5" fill="currentColor" />
                <rect x="27.5" y="18" width="3.5" height="12" rx="0.5" fill="currentColor" />
                <rect x="6" y="31" width="28" height="3" rx="0.5" fill="currentColor" />
                <path d="M19.5 35H20.5V37H19.5V35Z" fill="currentColor" />
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-[#0F2942] tracking-tight leading-none">
                  Government Scheme Advisor
                </h1>
                <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700 border border-slate-200">
                  National Citizen Portal
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                Public Welfare Services & Benefit Matching
              </p>
            </div>
          </div>

          {/* Center/Right: Status, Profile, Help, Notifications */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Status indicator */}
            <div className="hidden lg:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-50 border border-slate-200 text-xs font-medium text-slate-700">
              <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
              <span>Assessment: Verified</span>
            </div>

            {/* Help Button */}
            <button
              type="button"
              onClick={() => setShowHelpModal(true)}
              className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
              title="Public Service Helpline & Guidelines"
            >
              <HelpCircle className="w-4 h-4 text-slate-500" />
              <span>Help</span>
            </button>

            {/* Notification Bell */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer relative"
                aria-label="Notifications"
                title="Portal Notifications"
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-blue-700 ring-2 ring-white" />
              </button>

              {/* Notification Popover */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 p-4 z-50 text-xs space-y-2.5">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <span className="font-bold text-slate-900">Citizen Notifications</span>
                    <span className="text-[10px] text-slate-400">1 new</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-blue-50/70 border border-blue-100 space-y-1">
                    <div className="flex items-center gap-1.5 font-semibold text-blue-900">
                      <BadgeCheck className="w-3.5 h-3.5 text-blue-700" />
                      <span>Evaluation Complete</span>
                    </div>
                    <p className="text-[11px] text-blue-800/90 leading-relaxed">
                      Your profile was successfully evaluated against all indexed national and state welfare criteria.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowNotifications(false)}
                    className="w-full text-center py-1 text-[11px] font-semibold text-slate-500 hover:text-slate-800"
                  >
                    Dismiss
                  </button>
                </div>
              )}
            </div>

            <div className="h-5 w-[1px] bg-slate-200 mx-1 hidden sm:block" />

            {/* Right Action Buttons */}
            <button
              type="button"
              onClick={onEditProfile}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 hover:text-blue-900 font-semibold text-xs transition-colors shadow-2xs cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5 text-blue-700" />
              <span className="hidden sm:inline">Edit Profile</span>
            </button>

            <button
              type="button"
              onClick={onSignOut}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 font-semibold text-xs transition-colors cursor-pointer"
            >
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
        {/* ==================================================
            2. USER PROFILE SUMMARY
           ================================================== */}
        <section className="bg-white rounded-2xl border border-slate-200/90 shadow-[0_1px_3px_rgba(0,0,0,0.04)] p-5 sm:p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
            {/* Left: Avatar, Name, Metadata, Completeness */}
            <div className="flex items-start sm:items-center gap-4">
              <div className="w-13 h-13 rounded-full bg-[#0F2942] text-white flex items-center justify-center font-bold text-lg flex-shrink-0 shadow-xs ring-4 ring-slate-100">
                {userInitial}
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-lg sm:text-xl font-bold text-[#0F2942] tracking-tight">
                    {userName}
                  </h2>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>Profile completed</span>
                  </span>
                </div>

                {/* Compact Metadata line */}
                <div className="flex items-center gap-x-3 gap-y-1 text-xs text-slate-600 flex-wrap font-medium">
                  {profileData.age && <span>Age {profileData.age}</span>}
                  {profileData.gender && <span>• {profileData.gender}</span>}
                  {profileData.employmentStatus && <span>• {profileData.employmentStatus}</span>}
                  {profileData.state && (
                    <span>
                      • {profileData.district ? `${profileData.district}, ` : ''}
                      {profileData.state}
                    </span>
                  )}
                  {profileData.familyIncome && (
                    <span>
                      • Family Income ₹{profileData.familyIncome.replace(/[^\d,]/g, '')}/year
                    </span>
                  )}
                  {profileData.casteCategory && (
                    <span>• Category: {profileData.casteCategory}</span>
                  )}
                  {profileData.personWithDisability === 'Yes' && (
                    <span className="text-blue-700 font-semibold">• PwD</span>
                  )}
                  {profileData.isFarmer === 'Yes' && (
                    <span className="text-emerald-700 font-semibold">• Farmer</span>
                  )}
                </div>

                {/* Profile Completeness Indicator */}
                <div className="flex items-center gap-2 pt-1">
                  <div className="w-24 h-1.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                    <div className="w-full h-full bg-emerald-600 rounded-full" />
                  </div>
                  <span className="text-[11px] font-semibold text-slate-500">
                    Profile completeness 100%
                  </span>
                </div>
              </div>
            </div>

            {/* Right: Modify Assessment button */}
            <div className="self-start md:self-auto">
              <button
                type="button"
                onClick={onEditProfile}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-[#0F2942] font-semibold text-xs border border-slate-300 transition-colors shadow-2xs cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5 text-blue-800" />
                <span>Modify Assessment</span>
              </button>
            </div>
          </div>
        </section>

        {/* ==================================================
            3. MAIN HERO SECTION
           ================================================== */}
        <section className="bg-white rounded-2xl border border-slate-200/90 shadow-[0_1px_3px_rgba(0,0,0,0.04)] p-6 sm:p-8">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 sm:gap-8">
            {/* Left: Authoritative Heading & Subtitle */}
            <div className="max-w-2xl space-y-2">
              <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-blue-900 bg-blue-50 px-2.5 py-0.5 rounded border border-blue-200/80 mb-1">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-800" />
                <span>Eligibility Assessment Report</span>
              </div>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#0F2942] tracking-tight leading-tight">
                Your Government Scheme Eligibility
              </h2>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                We reviewed your profile against the available scheme criteria and identified programs that may be relevant to you.
              </p>
            </div>

            {/* Right: Elegant Circular Eligibility Overview */}
            <div className="flex items-center justify-center lg:justify-end">
              <div className="flex items-center gap-5 p-4 sm:p-5 rounded-2xl bg-slate-50/80 border border-slate-200/90 shadow-2xs">
                {/* Clean Circular Ring */}
                <div className="relative w-24 h-24 flex items-center justify-center">
                  <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="42"
                      stroke="currentColor"
                      strokeWidth="6"
                      className="text-slate-200"
                      fill="transparent"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="42"
                      stroke="currentColor"
                      strokeWidth="6"
                      strokeDasharray="263.89"
                      strokeDashoffset={263.89 - (263.89 * Math.max(15, eligiblePercentage)) / 100}
                      strokeLinecap="round"
                      className="text-emerald-600 transition-all duration-700"
                      fill="transparent"
                    />
                  </svg>

                  {/* Inside Circle Content */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="text-2xl font-black text-[#0F2942] leading-none">
                      {dynamicCounts.eligible}
                    </span>
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tight mt-0.5">
                      Potentially
                    </span>
                    <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-tight -mt-0.5">
                      Eligible
                    </span>
                  </div>
                </div>

                {/* Text summary next to or under ring */}
                <div className="space-y-1">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                    Assessed Outcome
                  </span>
                  <div className="text-sm font-bold text-slate-800">
                    {dynamicCounts.total} schemes assessed
                  </div>
                  <p className="text-[11px] text-slate-500 leading-normal max-w-[150px]">
                    {dynamicCounts.eligible} immediate matches qualify under your criteria.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ==================================================
            4. SUMMARY STATISTICS
           ================================================== */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-5">
          {/* Card 01: SCHEMES REVIEWED */}
          <div
            onClick={() => setActiveTab('All')}
            className={`rounded-2xl border bg-white p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] cursor-pointer transition-all hover:shadow-md relative overflow-hidden group ${
              activeTab === 'All' ? 'border-[#0F2942] ring-1 ring-[#0F2942]' : 'border-slate-200/90 hover:border-slate-300'
            }`}
          >
            {/* Top Accent Line */}
            <div className="absolute top-0 left-0 right-0 h-[3px] bg-[#0F2942]" />
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-[11px] font-bold tracking-wider text-slate-400 uppercase">
                01 • SCHEMES REVIEWED
              </span>
              <Landmark className="w-4 h-4 text-slate-400 group-hover:text-slate-600 transition-colors" />
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-[#0F2942] tracking-tight">
              {dynamicCounts.total}
            </div>
            <p className="text-[11px] text-slate-500 mt-2 font-medium">
              National & state welfare schemes assessed
            </p>
          </div>

          {/* Card 02: POTENTIALLY ELIGIBLE */}
          <div
            onClick={() => setActiveTab('Potentially Eligible')}
            className={`rounded-2xl border bg-white p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] cursor-pointer transition-all hover:shadow-md relative overflow-hidden group ${
              activeTab === 'Potentially Eligible'
                ? 'border-emerald-600 ring-1 ring-emerald-600 bg-emerald-50/20'
                : 'border-slate-200/90 hover:border-emerald-300'
            }`}
          >
            {/* Top Accent Line */}
            <div className="absolute top-0 left-0 right-0 h-[3px] bg-emerald-600" />
            <div className="flex items-center justify-between text-emerald-800 mb-2">
              <span className="text-[11px] font-bold tracking-wider text-emerald-800 uppercase">
                02 • POTENTIALLY ELIGIBLE
              </span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-emerald-800 tracking-tight">
              {dynamicCounts.eligible}
            </div>
            <p className="text-[11px] text-emerald-700 mt-2 font-medium">
              Satisfies all primary qualification criteria
            </p>
          </div>

          {/* Card 03: PARTIAL MATCH */}
          <div
            onClick={() => setActiveTab('Partial Match')}
            className={`rounded-2xl border bg-white p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] cursor-pointer transition-all hover:shadow-md relative overflow-hidden group ${
              activeTab === 'Partial Match'
                ? 'border-amber-600 ring-1 ring-amber-600 bg-amber-50/20'
                : 'border-slate-200/90 hover:border-amber-300'
            }`}
          >
            {/* Top Accent Line */}
            <div className="absolute top-0 left-0 right-0 h-[3px] bg-amber-600" />
            <div className="flex items-center justify-between text-amber-800 mb-2">
              <span className="text-[11px] font-bold tracking-wider text-amber-800 uppercase">
                03 • PARTIAL MATCH
              </span>
              <AlertCircle className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-amber-800 tracking-tight">
              {dynamicCounts.partial}
            </div>
            <p className="text-[11px] text-amber-700 mt-2 font-medium">
              May require minor secondary qualifications
            </p>
          </div>

          {/* Card 04: NOT MATCHING */}
          <div
            onClick={() => setActiveTab('Not Matching')}
            className={`rounded-2xl border bg-white p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] cursor-pointer transition-all hover:shadow-md relative overflow-hidden group ${
              activeTab === 'Not Matching'
                ? 'border-slate-500 ring-1 ring-slate-500 bg-slate-50'
                : 'border-slate-200/90 hover:border-slate-300'
            }`}
          >
            {/* Top Accent Line */}
            <div className="absolute top-0 left-0 right-0 h-[3px] bg-slate-400" />
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-[11px] font-bold tracking-wider text-slate-500 uppercase">
                04 • NOT MATCHING
              </span>
              <XCircle className="w-4 h-4 text-slate-400" />
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-slate-600 tracking-tight">
              {dynamicCounts.notMatching}
            </div>
            <p className="text-[11px] text-slate-500 mt-2 font-medium">
              Criteria unfulfilled based on current inputs
            </p>
          </div>
        </section>

        {/* ==================================================
            CITIZEN STATUS PANEL: NATIONAL GOVERNMENT SCHEME DATABASE
           ================================================== */}
        <section className="bg-gradient-to-r from-blue-950 via-[#0F2942] to-slate-900 rounded-2xl p-5 text-white shadow-md border border-blue-900/40">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3.5">
              <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-xs text-cyan-300 border border-white/10 flex-shrink-0">
                <Landmark className="w-5 h-5 text-cyan-300" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h3 className="font-bold text-white text-base sm:text-lg tracking-tight">
                    National Government Scheme Database
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-200 border border-cyan-400/30">
                    Verified Scheme Dataset
                  </span>
                </div>
                <p className="text-xs text-blue-200/90 font-medium">
                  Government schemes indexed for eligibility matching
                </p>
              </div>
            </div>

            {/* Dynamic Metadata Badges & Citizen Reassurance */}
            <div className="flex flex-wrap items-center gap-2.5 text-xs text-blue-100/90 pt-2 lg:pt-0 border-t border-white/10 lg:border-t-0 font-medium">
              <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg border border-white/10">
                <Database className="w-3.5 h-3.5 text-cyan-300" />
                <span className="font-semibold text-white">
                  {metadata.totalSchemesCount.toLocaleString()} schemes indexed
                </span>
              </div>
              <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg border border-white/10">
                <Building2 className="w-3.5 h-3.5 text-blue-200" />
                <span>Central & State/UT schemes</span>
              </div>
              <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg border border-white/10">
                <Clock className="w-3.5 h-3.5 text-blue-200" />
                <span>Last updated: {metadata.lastSynchronized}</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-300 bg-emerald-950/50 px-3 py-1.5 rounded-lg border border-emerald-500/30 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Automatically considered during your assessment</span>
              </div>
            </div>
          </div>
        </section>

        {/* ==================================================
            5. NAVIGATION / TABS
           ================================================== */}
        <section className="border-b border-slate-200">
          <div className="flex items-center gap-6 sm:gap-8 overflow-x-auto no-scrollbar">
            {[
              { id: 'All', label: 'Overview', count: dynamicCounts.total },
              { id: 'Potentially Eligible', label: 'Potentially Eligible', count: dynamicCounts.eligible },
              { id: 'Partial Match', label: 'Partial Matches', count: dynamicCounts.partial },
              { id: 'Not Matching', label: 'Not Matching', count: dynamicCounts.notMatching },
            ].map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`py-3.5 text-sm font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
                    isActive
                      ? 'border-[#0F2942] text-[#0F2942]'
                      : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
                  }`}
                >
                  <span>{tab.label}</span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                      isActive ? 'bg-slate-200/80 text-slate-900' : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {tab.count}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* ==================================================
            6. SEARCH & FILTER TOOLBAR
           ================================================== */}
        <section className="bg-white rounded-2xl border border-slate-200/90 shadow-[0_1px_3px_rgba(0,0,0,0.03)] p-4 sm:p-5">
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 sm:gap-4">
            {/* Left: Search input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search schemes by name, department, or keywords..."
                className="w-full pl-10 pr-9 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 focus:border-blue-800 placeholder:text-slate-400 bg-white"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  aria-label="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Right: Dropdowns for Level, Category, Department, Sort, and Clear */}
            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              {/* Government Level Dropdown */}
              <div className="flex items-center gap-1.5">
                <label htmlFor="level-select" className="text-xs font-semibold text-slate-500 whitespace-nowrap">
                  Level:
                </label>
                <select
                  id="level-select"
                  value={selectedGovernmentLevel}
                  onChange={(e) => setSelectedGovernmentLevel(e.target.value as any)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-800 cursor-pointer"
                >
                  <option value="All">All Levels</option>
                  <option value="Central">Central Govt</option>
                  <option value="State">State / UT</option>
                </select>
              </div>

              {/* Category Dropdown */}
              <div className="flex items-center gap-1.5">
                <label htmlFor="category-select" className="text-xs font-semibold text-slate-500 whitespace-nowrap">
                  Category:
                </label>
                <select
                  id="category-select"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-800 cursor-pointer max-w-[140px] truncate"
                >
                  {availableCategories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat === 'All' ? 'All Categories' : cat}
                    </option>
                  ))}
                </select>
              </div>

              {/* Department Dropdown */}
              <div className="flex items-center gap-1.5">
                <label htmlFor="dept-select" className="text-xs font-semibold text-slate-500 whitespace-nowrap">
                  Department:
                </label>
                <select
                  id="dept-select"
                  value={selectedDepartment}
                  onChange={(e) => setSelectedDepartment(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-800 cursor-pointer max-w-[150px] truncate"
                >
                  {availableDepartments.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept === 'All' ? 'All Departments' : dept}
                    </option>
                  ))}
                </select>
              </div>

              {/* Sort Dropdown */}
              <div className="flex items-center gap-1.5">
                <label htmlFor="sort-select" className="text-xs font-semibold text-slate-500 whitespace-nowrap">
                  Sort:
                </label>
                <select
                  id="sort-select"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-800 cursor-pointer"
                >
                  <option value="score-desc">Match Score (High to Low)</option>
                  <option value="score-asc">Match Score (Low to High)</option>
                  <option value="name-asc">Scheme Name (A to Z)</option>
                </select>
              </div>

              {/* Clear Filters Button */}
              {isFiltersActive && (
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-blue-900 hover:bg-blue-50 border border-blue-200 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Clear Filters</span>
                </button>
              )}
            </div>
          </div>
        </section>

        {/* ==================================================
            DYNAMIC LEVEL & STATE GUIDANCE INDICATOR (REQ 14)
           ================================================== */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 rounded-xl bg-blue-50/90 border border-blue-200/80 text-blue-950 text-xs shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-700 animate-pulse flex-shrink-0" />
            <span className="font-bold text-[#0F2942]">Level Filter:</span>
            <span className="font-semibold text-blue-900">{levelIndicationText}</span>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-slate-600 font-medium">
            <span className="text-slate-500">Citizen Profile Domicile:</span>
            <span className="px-2.5 py-0.5 rounded-md bg-white border border-blue-200 font-bold text-blue-950 shadow-2xs">
              {userState || 'All India'}
            </span>
          </div>
        </div>

        {/* Results Counter Banner */}
        <div className="flex flex-wrap items-center justify-between text-xs text-slate-500 px-1 gap-2">
          <span className="font-semibold text-slate-700">
            Showing {paginatedSchemes.length} of {filteredSchemes.length} filtered (Total {dynamicCounts.total} Evaluated Schemes for your State & Level)
          </span>
          {activeTab !== 'All' && (
            <span className="text-blue-900 font-medium">Filter view: {activeTab}</span>
          )}
        </div>

        {/* ==================================================
            7. SCHEME RESULTS CARDS
           ================================================== */}
        {filteredSchemes.length === 0 ? (
          /* ==================================================
             8. EMPTY STATE
             ================================================== */
          <div className="bg-white rounded-2xl border border-slate-200/90 p-12 text-center max-w-lg mx-auto space-y-4 shadow-xs">
            <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
              <Landmark className="w-7 h-7 text-slate-400" />
            </div>
            <h3 className="text-lg font-bold text-[#0F2942]">No schemes match your current filters</h3>
            <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
              No government welfare programs matched your current search keywords or category filters. Try resetting the criteria to see other available programs.
            </p>
            <button
              type="button"
              onClick={handleResetFilters}
              className="px-4 py-2 rounded-xl bg-[#0F2942] hover:bg-[#15385B] text-white font-semibold text-xs transition-colors cursor-pointer shadow-xs"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
              {paginatedSchemes.map((item) => {
                const { scheme, matchScore, status, matchedRules, unmetRules } = item;
                const urlSummary = getSchemeUrlSummary(scheme);

                const isEligible = status === 'Potentially Eligible';
                const isPartial = status === 'Partial Match';

                // Extract top 4 matched rules to display in "WHY YOU MATCH"
                const topRules = matchedRules.slice(0, 4);

                return (
                  <div
                    key={scheme.id}
                    className={`bg-white rounded-2xl border shadow-[0_1px_3px_rgba(0,0,0,0.03)] hover:shadow-md transition-all duration-200 flex flex-col justify-between overflow-hidden group ${
                      isEligible
                        ? 'border-emerald-200 hover:border-emerald-400'
                        : isPartial
                        ? 'border-amber-200 hover:border-amber-400'
                        : 'border-slate-200/90 hover:border-slate-300'
                    }`}
                  >
                    <div className="p-5 sm:p-6 space-y-4">
                      {/* TOP: Category Label & Eligibility Match */}
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
                            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-900 bg-blue-50 px-2 py-0.5 rounded border border-blue-200/70 inline-block">
                              {scheme.category}
                            </span>
                            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-900 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200/70 inline-block">
                              {scheme.governmentLevel === 'State' || scheme.governmentLevel === 'UT'
                                ? `State • ${scheme.state || 'All States'}`
                                : 'Central Govt'}
                            </span>
                            {(scheme.governmentLevel === 'State' || scheme.governmentLevel === 'UT') &&
                              !isStateMatching(scheme.state, userState) && (
                                <span className="text-[10px] font-bold text-rose-800 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 inline-block">
                                  Not applicable to your state
                                </span>
                              )}
                            {scheme.isVerifiedOfficial !== false && (
                              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 inline-flex items-center gap-1">
                                <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                                <span>Verified</span>
                              </span>
                            )}
                          </div>
                          <h3 className="text-base sm:text-lg font-bold text-[#0F2942] leading-snug tracking-tight">
                            {scheme.name}
                          </h3>
                          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium mt-1">
                            <Building2 className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                            <span className="line-clamp-1" title={scheme.department}>
                              {scheme.department}
                            </span>
                          </div>
                        </div>

                        {/* Right: Clean Score Indicator */}
                        <div className="text-right flex-shrink-0">
                          <div
                            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${
                              isEligible
                                ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                                : isPartial
                                ? 'bg-amber-50 text-amber-900 border-amber-300'
                                : 'bg-slate-100 text-slate-700 border-slate-300'
                            }`}
                          >
                            {isEligible ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                            ) : isPartial ? (
                              <AlertCircle className="w-3.5 h-3.5 text-amber-700" />
                            ) : (
                              <XCircle className="w-3.5 h-3.5 text-slate-500" />
                            )}
                            <span>MATCH {matchScore}%</span>
                          </div>
                          <span className="block text-[10px] text-slate-400 font-medium mt-1">
                            {status}
                          </span>
                        </div>
                      </div>

                      {/* MIDDLE: Short Description */}
                      <p className="text-xs sm:text-[13px] text-slate-600 line-clamp-2 leading-relaxed">
                        {scheme.description}
                      </p>

                      {/* WHY YOU MATCH OR UNMET CRITERIA SECTION */}
                      <div className="pt-2 border-t border-slate-100 space-y-2">
                        {status === 'Not Matching' ? (
                          <>
                            <span className="text-[11px] font-bold uppercase tracking-wider text-rose-600 block">
                              CRITERIA NOT MET
                            </span>
                            <div className="space-y-1.5 text-xs">
                              {unmetRules.slice(0, 2).map((rule, idx) => (
                                <div key={idx} className="flex items-start gap-1.5 text-rose-900 bg-rose-50/70 p-2 rounded-lg border border-rose-200/60">
                                  <XCircle className="w-3.5 h-3.5 text-rose-600 mt-0.5 flex-shrink-0" />
                                  <div className="line-clamp-2">
                                    <div className="flex items-center gap-1.5 flex-wrap">
                                      <span className="font-semibold text-rose-950">{rule.label}</span>
                                      {rule.isMandatory && (
                                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-200 text-rose-900 uppercase">
                                          Mandatory
                                        </span>
                                      )}
                                    </div>
                                    <p className="text-[11px] text-rose-800/90 mt-0.5">{rule.reason}</p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </>
                        ) : (
                          <>
                            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                              WHY YOU MATCH
                            </span>
                            <div className="grid grid-cols-2 gap-2 text-xs">
                              {topRules.map((rule, idx) => (
                                <div key={idx} className="flex items-start gap-1.5 text-slate-700">
                                  <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3] mt-0.5 flex-shrink-0" />
                                  <span className="line-clamp-1 font-medium text-slate-800" title={rule.label}>
                                    {rule.label}
                                  </span>
                                </div>
                              ))}
                              {/* If partial match, show the unmet condition as well */}
                              {isPartial && unmetRules.length > 0 && (
                                <div className="flex items-start gap-1.5 text-amber-900 col-span-2 bg-amber-50/70 p-1.5 rounded border border-amber-200/70">
                                  <AlertCircle className="w-3.5 h-3.5 text-amber-700 mt-0.5 flex-shrink-0" />
                                  <span className="text-[11px] line-clamp-1">
                                    <strong>Requirement note:</strong> {unmetRules[0].label}
                                  </span>
                                </div>
                              )}
                            </div>
                          </>
                        )}
                      </div>

                      {/* BOTTOM: Key Benefits Preview */}
                      <div className="pt-2 border-t border-slate-100 text-xs space-y-1">
                        <div className="flex items-start gap-1.5 text-slate-600">
                          <span className="font-semibold text-slate-800 flex-shrink-0">Benefits:</span>
                          <span className="line-clamp-1">
                            {scheme.benefits[0] || 'Comprehensive welfare assistance and subsidies.'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* CARD FOOTER */}
                    <div className="p-4 sm:px-6 sm:py-3 bg-[#F8FAFC] border-t border-slate-200/80 flex items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => setSelectedSchemeForModal(item)}
                        className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-900 hover:text-blue-950 transition-colors cursor-pointer group-hover:underline"
                      >
                        <span>View Scheme Details</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>

                      <div className="flex items-center gap-2">
                        {urlSummary.hasSeparateApplicationPortal && urlSummary.officialApplication && (
                          <a
                            href={urlSummary.officialApplication.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                            title="Direct official application portal"
                          >
                            <span>Apply Online</span>
                            <ExternalLink className="w-3 h-3 text-emerald-700" />
                          </a>
                        )}

                        {urlSummary.officialWebsite?.status === 'verified' ? (
                          <a
                            href={urlSummary.officialWebsite.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-xs font-semibold text-slate-700 hover:text-blue-900 transition-colors cursor-pointer"
                            title="Open verified official government portal"
                          >
                            <span>Official Website</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        ) : urlSummary.officialWebsite?.status === 'unavailable' ||
                          urlSummary.officialWebsite?.status === 'needs_verification' ? (
                          <button
                            type="button"
                            onClick={() => {
                              setUrlNoticeScheme(scheme);
                              setUrlNoticeTarget(urlSummary.officialWebsite);
                            }}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200/80 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                            title="Official website is currently unavailable or requires verification. Click for details."
                          >
                            <span>Official Website</span>
                            <AlertTriangle className="w-3 h-3 text-amber-600" />
                          </button>
                        ) : (
                          <span className="text-xs text-slate-400 font-medium">
                            No Official Portal
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Pagination Controls */}
            {filteredSchemes.length > ITEMS_PER_PAGE && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-200">
                <span className="text-xs font-medium text-slate-500">
                  Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1} to{' '}
                  {Math.min(currentPage * ITEMS_PER_PAGE, filteredSchemes.length)} of{' '}
                  {filteredSchemes.length} schemes
                </span>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  >
                    Previous
                  </button>

                  {Array.from({ length: totalPages }, (_, i) => i + 1)
                    .filter((p) => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1)
                    .map((pageNum, idx, arr) => (
                      <React.Fragment key={pageNum}>
                        {idx > 0 && arr[idx - 1] !== pageNum - 1 && (
                          <span className="px-1 text-slate-400 text-xs">...</span>
                        )}
                        <button
                          type="button"
                          onClick={() => setCurrentPage(pageNum)}
                          className={`w-8 h-8 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                            currentPage === pageNum
                              ? 'bg-[#0F2942] text-white'
                              : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          {pageNum}
                        </button>
                      </React.Fragment>
                    ))}

                  <button
                    type="button"
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ==================================================
            9. STATUTORY PUBLIC SERVICE ADVISORY
           ================================================== */}
        <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 text-xs text-slate-600 space-y-2 shadow-2xs">
          <div className="flex items-center gap-2 font-bold text-[#0F2942]">
            <ShieldCheck className="w-4 h-4 text-blue-900 flex-shrink-0" />
            <span>National Public Service Transparency Advisory</span>
          </div>
          <p className="leading-relaxed text-slate-600">
            Eligibility assessments generated on this portal are based strictly on deterministic rule-matching against criteria provided by Central and State ministries. Official applications must be submitted via the designated government portals with verified documentation.
          </p>
        </section>
      </main>

      {/* Details Side Drawer / Modal */}
      <SchemeDetailsModal
        evaluatedScheme={selectedSchemeForModal}
        onClose={() => setSelectedSchemeForModal(null)}
      />

      {/* Citizen Help Modal */}
      {showHelpModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs"
          onClick={() => setShowHelpModal(false)}
        >
          <div
            className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-2xl p-6 space-y-4 text-slate-800"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Landmark className="w-5 h-5 text-blue-900" />
                <h3 className="font-bold text-slate-900 text-sm">Citizen Service Help Desk</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowHelpModal(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <PhoneCall className="w-3.5 h-3.5 text-blue-800" />
                  <span>National Welfare Helpline</span>
                </span>
                <p className="text-slate-600">
                  Toll-Free: <strong>1800-11-0033</strong> / <strong>1947</strong> (Direct DBT Helpline)
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-blue-800" />
                  <span>Working Hours</span>
                </span>
                <p className="text-slate-600">
                  Monday to Saturday: 9:00 AM – 6:00 PM IST (Except National Holidays)
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Verified Portals</span>
                </span>
                <p className="text-slate-600">
                  All external application links resolve exclusively to official <code>.gov.in</code> or <code>.nic.in</code> portals.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowHelpModal(false)}
              className="w-full py-2 rounded-xl bg-[#0F2942] hover:bg-[#15385B] text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              Close Help
            </button>
          </div>
        </div>
      )}

      {/* Official Results Footer */}
      <footer className="mt-12 bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 space-y-1">
          <p className="font-semibold text-slate-700">
            Government Scheme Advisor • Public Welfare Services & Benefit Matching Portal
          </p>
          <p>
            Helping citizens discover relevant government welfare programs through verified criteria matching.
          </p>
        </div>
      </footer>
    </div>
  );
};
