import React from 'react';
import { X, Shield, FileText, Phone, Mail, Clock, MapPin, CheckCircle } from 'lucide-react';
import { ModalType } from '../types';

interface InfoModalProps {
  modalType: ModalType;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ modalType, onClose }) => {
  if (!modalType) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl max-h-[85vh] flex flex-col glass-card rounded-2xl border border-cyan-400/40 shadow-2xl overflow-hidden backdrop-blur-2xl text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-400/20 bg-blue-950/50">
          <div className="flex items-center gap-2.5">
            {modalType === 'privacy' && <Shield className="w-5 h-5 text-cyan-400" />}
            {modalType === 'terms' && <FileText className="w-5 h-5 text-cyan-400" />}
            {modalType === 'contact' && <Phone className="w-5 h-5 text-cyan-400" />}
            {modalType === 'accessibility' && <CheckCircle className="w-5 h-5 text-cyan-400" />}
            <h2 id="modal-title" className="text-base font-bold text-white tracking-wide">
              {modalType === 'privacy' && 'Citizen Privacy & Data Protection'}
              {modalType === 'terms' && 'Terms of Use & Citizen Charter'}
              {modalType === 'contact' && 'Citizen Support & Grievance Redressal'}
              {modalType === 'accessibility' && 'Accessibility Standards'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded text-blue-300/70 hover:text-white hover:bg-blue-900/40 cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto text-xs sm:text-sm text-blue-100/90 space-y-4 leading-relaxed">
          {modalType === 'privacy' && (
            <>
              <div className="p-3 bg-cyan-950/40 border border-cyan-400/30 rounded text-cyan-200 text-xs font-medium">
                Official Guarantee: All personal information is encrypted in transit and at rest. Citizen profiles are never monetized or shared with third-party advertising brokers.
              </div>
              <h3 className="font-bold text-white text-sm">1. Purpose of Data Processing</h3>
              <p>
                Credentials and demographic data are collected strictly to determine eligibility for statutory government schemes, subsidies, and welfare interventions.
              </p>
              <h3 className="font-bold text-white text-sm">2. 256-Bit Cryptographic Security</h3>
              <p>
                Multi-layer encryption safeguards citizen records in compliance with national digital sovereignty frameworks.
              </p>
            </>
          )}

          {modalType === 'terms' && (
            <>
              <h3 className="font-bold text-white text-sm">1. Advisory Scope</h3>
              <p>
                The Government Scheme Eligibility Advisor provides indicative guidance based on citizen input. Final scheme award decisions rest exclusively with the designated public authority.
              </p>
              <h3 className="font-bold text-white text-sm">2. Citizen Integrity</h3>
              <p>
                Providing false representations may result in disqualification from public assistance programs under applicable laws.
              </p>
            </>
          )}

          {modalType === 'contact' && (
            <div className="space-y-4">
              <p className="text-blue-200/80">
                Official contact channels for assistance with scheme discovery and authentication:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="p-3.5 border border-cyan-400/20 rounded-lg bg-blue-950/40">
                  <div className="flex items-center gap-2 font-bold text-cyan-300 text-xs">
                    <Phone className="w-4 h-4" />
                    <span>Toll-Free Helpline</span>
                  </div>
                  <p className="text-sm font-bold text-white mt-1">1800-SCHEME-GOV</p>
                  <p className="text-[11px] text-blue-300/60 mt-0.5">Mon–Fri: 08:00 – 20:00</p>
                </div>

                <div className="p-3.5 border border-cyan-400/20 rounded-lg bg-blue-950/40">
                  <div className="flex items-center gap-2 font-bold text-cyan-300 text-xs">
                    <Mail className="w-4 h-4" />
                    <span>Citizen Email Desk</span>
                  </div>
                  <p className="text-xs font-semibold text-white mt-1">support@schemes.gov.portal</p>
                  <p className="text-[11px] text-blue-300/60 mt-0.5">24/7 Intake</p>
                </div>
              </div>
            </div>
          )}

          {modalType === 'accessibility' && (
            <>
              <h3 className="font-bold text-white text-sm">WCAG 2.1 AA Certified</h3>
              <p>
                This citizen gateway features high-contrast legibility, screen reader semantic structure, focus visibility, and dynamic font scale controls.
              </p>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-blue-950/50 border-t border-cyan-400/20 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 neon-btn text-white font-bold text-xs uppercase rounded cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
