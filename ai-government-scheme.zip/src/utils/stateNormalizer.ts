/**
 * Reusable Indian State & Union Territory Normalization Utility
 * Handles variations in case, punctuation, whitespace, and official abbreviations.
 */

const STATE_ALIASES: Record<string, string> = {
  // Abbreviations & common forms
  tn: 'tamil nadu',
  tamilnadu: 'tamil nadu',
  'tamil-nadu': 'tamil nadu',
  'tamil nadu': 'tamil nadu',
  ka: 'karnataka',
  'karnataka state': 'karnataka',
  karnataka: 'karnataka',
  mh: 'maharashtra',
  maha: 'maharashtra',
  maharashtra: 'maharashtra',
  wb: 'west bengal',
  westbengal: 'west bengal',
  'west-bengal': 'west bengal',
  'west bengal': 'west bengal',
  'paschim banga': 'west bengal',
  'paschim bangal': 'west bengal',
  up: 'uttar pradesh',
  uttarpradesh: 'uttar pradesh',
  'uttar-pradesh': 'uttar pradesh',
  'uttar pradesh': 'uttar pradesh',
  ap: 'andhra pradesh',
  andhrapradesh: 'andhra pradesh',
  'andhra pradesh': 'andhra pradesh',
  ts: 'telangana',
  tg: 'telangana',
  telangana: 'telangana',
  kl: 'kerala',
  kerala: 'kerala',
  dl: 'delhi',
  delhi: 'delhi',
  'delhi nct': 'delhi',
  'delhi (nct)': 'delhi',
  'nct of delhi': 'delhi',
  'national capital territory of delhi': 'delhi',
  'new delhi': 'delhi',
  gj: 'gujarat',
  gujarat: 'gujarat',
  mp: 'madhya pradesh',
  madhyapradesh: 'madhya pradesh',
  'madhya pradesh': 'madhya pradesh',
  br: 'bihar',
  bihar: 'bihar',
  rj: 'rajasthan',
  rajasthan: 'rajasthan',
  pb: 'punjab',
  punjab: 'punjab',
  hr: 'haryana',
  haryana: 'haryana',
  or: 'odisha',
  od: 'odisha',
  odisha: 'odisha',
  orissa: 'odisha',
  jh: 'jharkhand',
  jharkhand: 'jharkhand',
  cg: 'chhattisgarh',
  ct: 'chhattisgarh',
  chhattisgarh: 'chhattisgarh',
  chattisgarh: 'chhattisgarh',
  uk: 'uttarakhand',
  ua: 'uttarakhand',
  uttarakhand: 'uttarakhand',
  uttaranchal: 'uttarakhand',
  hp: 'himachal pradesh',
  himachalpradesh: 'himachal pradesh',
  'himachal pradesh': 'himachal pradesh',
  as: 'assam',
  assam: 'assam',
  jk: 'jammu and kashmir',
  'j&k': 'jammu and kashmir',
  'jammu & kashmir': 'jammu and kashmir',
  'jammu and kashmir': 'jammu and kashmir',
  la: 'ladakh',
  ladakh: 'ladakh',
  py: 'puducherry',
  pondicherry: 'puducherry',
  puducherry: 'puducherry',
  ch: 'chandigarh',
  chandigarh: 'chandigarh',
  ga: 'goa',
  goa: 'goa',
  sk: 'sikkim',
  sikkim: 'sikkim',
  tr: 'tripura',
  tripura: 'tripura',
  mn: 'manipur',
  manipur: 'manipur',
  ml: 'meghalaya',
  meghalaya: 'meghalaya',
  mz: 'mizoram',
  mizoram: 'mizoram',
  nl: 'nagaland',
  nagaland: 'nagaland',
  ar: 'arunachal pradesh',
  'arunachal pradesh': 'arunachal pradesh',
  an: 'andaman and nicobar islands',
  'andaman & nicobar islands': 'andaman and nicobar islands',
  'andaman and nicobar': 'andaman and nicobar islands',
  'andaman and nicobar islands': 'andaman and nicobar islands',
  ld: 'lakshadweep',
  lakshadweep: 'lakshadweep',
  dnh: 'dadra and nagar haveli and daman and diu',
  dd: 'dadra and nagar haveli and daman and diu',
  'dadra and nagar haveli': 'dadra and nagar haveli and daman and diu',
  'daman and diu': 'dadra and nagar haveli and daman and diu',
  'dadra and nagar haveli and daman and diu': 'dadra and nagar haveli and daman and diu',

  // Generic national tags
  all: 'all',
  'all india': 'all',
  'all states': 'all',
  'all states/uts': 'all',
  'all states / uts': 'all',
  national: 'all',
  central: 'all',
  panindia: 'all',
  'pan india': 'all',
};

/**
 * Normalizes any Indian State/UT name or abbreviation to a canonical lowercase string.
 * Example: "Tamil Nadu", "tamil nadu", "TAMIL NADU", "TN" -> "tamil nadu"
 */
export const normalizeState = (state?: string | null): string => {
  if (!state || typeof state !== 'string') return '';

  const raw = state.trim().toLowerCase();
  if (!raw) return '';

  // Clean common noise characters like parentheses, punctuation
  const cleaned = raw
    .replace(/[().,]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // Direct alias lookup
  if (STATE_ALIASES[cleaned]) {
    return STATE_ALIASES[cleaned];
  }

  // Check hyphenated version
  const dashed = cleaned.replace(/\s+/g, '-');
  if (STATE_ALIASES[dashed]) {
    return STATE_ALIASES[dashed];
  }

  const unDashed = cleaned.replace(/-/g, ' ');
  if (STATE_ALIASES[unDashed]) {
    return STATE_ALIASES[unDashed];
  }

  return cleaned;
};

/**
 * Compares two states to check if they match.
 * If schemeState is 'all' or empty, it matches any user state.
 * Supports string, array, or comma-separated lists of states.
 */
export const isStateMatching = (
  schemeState?: string | string[] | null,
  userState?: string | null
): boolean => {
  const normUser = normalizeState(userState);

  // If scheme has no state restriction
  if (!schemeState) {
    return true;
  }

  // If scheme has array of states
  if (Array.isArray(schemeState)) {
    if (schemeState.length === 0) return true;
    return schemeState.some((s) => {
      const n = normalizeState(s);
      return n === 'all' || (normUser && n === normUser);
    });
  }

  const normScheme = normalizeState(schemeState);

  // If scheme has no state restriction or applies to all states
  if (!normScheme || normScheme === 'all') {
    return true;
  }

  // If user state is missing, state-restricted schemes cannot match
  if (!normUser) {
    return false;
  }

  if (normScheme === normUser) {
    return true;
  }

  // Check if scheme has multiple states separated by commas or slashes
  if (schemeState.includes(',') || schemeState.includes('/')) {
    const parts = schemeState.split(/[,/]/).map((p) => normalizeState(p.trim()));
    return parts.some((p) => p === 'all' || p === normUser);
  }

  return false;
};

/**
 * Checks whether a scheme is applicable to the user's state.
 * Central schemes are considered national by default.
 * State/UT schemes require scheme.state === user.state.
 */
export const isSchemeApplicableToUserState = (
  scheme: { governmentLevel?: string; state?: string | string[] },
  userState?: string | null
): boolean => {
  if (scheme.governmentLevel === 'Central') {
    // Central schemes apply nationally unless explicitly restricted to a specific state
    if (!scheme.state || normalizeState(Array.isArray(scheme.state) ? scheme.state[0] : scheme.state) === 'all') {
      return true;
    }
    return isStateMatching(scheme.state, userState);
  }

  // State / UT schemes: must match the user's state
  if (scheme.governmentLevel === 'State' || scheme.governmentLevel === 'UT') {
    if (!scheme.state || normalizeState(Array.isArray(scheme.state) ? scheme.state[0] : scheme.state) === 'all') {
      return true;
    }
    return isStateMatching(scheme.state, userState);
  }

  return true;
};

