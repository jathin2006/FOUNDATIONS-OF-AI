/**
 * Reusable Government Scheme URL Validation & Verification Utility
 * Handles official domain verification, operational status checks,
 * safe opening of links, and error explanation for unavailable domains.
 */

import { GovernmentScheme, SchemeUrlStatus } from '../types';

export interface ValidatedSchemeUrl {
  url: string;
  status: SchemeUrlStatus;
  type: 'website' | 'application' | 'source';
  label: string;
  isGovernmentDomain: boolean;
  unavailableReason?: string;
  suggestedAlternative?: {
    label: string;
    url: string;
  };
}

export interface SchemeUrlSummary {
  officialWebsite: ValidatedSchemeUrl | null;
  officialApplication: ValidatedSchemeUrl | null;
  sourceUrl: ValidatedSchemeUrl | null;
  hasSeparateApplicationPortal: boolean;
  isOfficialWebsiteAvailable: boolean;
}

/**
 * Registry of known government domains and their operational status.
 * Helps prevent misleading user clicks to server timeouts or deprecated domains.
 */
export const KNOWN_DOMAIN_STATUS_REGISTRY: Record<
  string,
  {
    status: SchemeUrlStatus;
    reason: string;
    suggestedPortalUrl?: string;
    suggestedPortalLabel?: string;
    mySchemeUrl?: string;
  }
> = {
  'aajeevika.gov.in': {
    status: 'unavailable',
    reason:
      'The legacy portal (aajeevika.gov.in) is currently non-operational or unreachable from public networks (ERR_CONNECTION_TIMED_OUT). Official schemes under DAY-NRLM are actively administered by the Ministry of Rural Development.',
    suggestedPortalUrl: 'https://rural.nic.in',
    suggestedPortalLabel: 'Ministry of Rural Development Portal (rural.nic.in)',
    mySchemeUrl: 'https://www.myscheme.gov.in/schemes/day-nrlm',
  },
};

/**
 * Validates whether a given URL is syntactically well-formed
 * and uses http:// or https://.
 */
export const validateUrlSyntax = (
  rawUrl?: string | null
): { isValid: boolean; normalizedUrl: string; hostname: string; error?: string } => {
  if (!rawUrl || typeof rawUrl !== 'string') {
    return { isValid: false, normalizedUrl: '', hostname: '', error: 'URL is missing or empty' };
  }

  const trimmed = rawUrl.trim();
  if (!trimmed || trimmed === '#' || trimmed === 'https://' || trimmed === 'http://') {
    return { isValid: false, normalizedUrl: '', hostname: '', error: 'URL is a placeholder' };
  }

  // Enforce http/https
  if (!/^https?:\/\//i.test(trimmed)) {
    return {
      isValid: false,
      normalizedUrl: trimmed,
      hostname: '',
      error: 'URL must use http:// or https:// protocol',
    };
  }

  try {
    const parsed = new URL(trimmed);
    const hostname = parsed.hostname.toLowerCase();

    // Check for obvious malformations
    if (!hostname || !hostname.includes('.') || hostname.endsWith('.')) {
      return {
        isValid: false,
        normalizedUrl: trimmed,
        hostname: '',
        error: 'URL hostname is malformed',
      };
    }

    return {
      isValid: true,
      normalizedUrl: parsed.toString(),
      hostname,
    };
  } catch {
    return {
      isValid: false,
      normalizedUrl: trimmed,
      hostname: '',
      error: 'URL syntax could not be parsed',
    };
  }
};

/**
 * Checks if a hostname belongs to an authentic Indian Government
 * ministry, department, statutory board, or official enterprise portal.
 */
export const isOfficialGovernmentDomain = (hostname: string): boolean => {
  const h = hostname.toLowerCase();

  // Standard official Indian government top-level domains
  if (h.endsWith('.gov.in') || h.endsWith('.nic.in')) {
    return true;
  }

  // Official statutory, public education, autonomous or agency domains
  const recognizedOfficialDomains = [
    'nsdl.co.in',
    'enps.nsdl.com',
    'alimco.in',
    'adip.alimco.in',
    'kviconline.gov.in',
    'startuptn.in',
    'standupmitra.in',
    'udyamimitra.in',
    'mudra.org.in',
    'ugc.ac.in',
    'myscheme.gov.in',
  ];

  return recognizedOfficialDomains.some(
    (allowed) => h === allowed || h.endsWith(`.${allowed}`)
  );
};

/**
 * Resolves the operational and verification status of a URL.
 */
export const resolveUrlStatus = (
  rawUrl?: string | null,
  explicitStatus?: SchemeUrlStatus,
  explicitReason?: string
): {
  status: SchemeUrlStatus;
  isValid: boolean;
  normalizedUrl: string;
  hostname: string;
  isGovernmentDomain: boolean;
  reason?: string;
  suggestedAlternative?: { label: string; url: string };
} => {
  const validation = validateUrlSyntax(rawUrl);

  if (!validation.isValid) {
    return {
      status: 'unknown',
      isValid: false,
      normalizedUrl: '',
      hostname: '',
      isGovernmentDomain: false,
      reason: validation.error,
    };
  }

  const { hostname, normalizedUrl } = validation;
  const isGov = isOfficialGovernmentDomain(hostname);

  // Check known domain registry first (e.g. aajeevika.gov.in)
  if (KNOWN_DOMAIN_STATUS_REGISTRY[hostname]) {
    const known = KNOWN_DOMAIN_STATUS_REGISTRY[hostname];
    return {
      status: known.status,
      isValid: true,
      normalizedUrl,
      hostname,
      isGovernmentDomain: isGov,
      reason: explicitReason || known.reason,
      suggestedAlternative: known.suggestedPortalUrl
        ? {
            label: known.suggestedPortalLabel || 'Official Ministry Portal',
            url: known.suggestedPortalUrl,
          }
        : undefined,
    };
  }

  // If explicit status provided in dataset record
  if (explicitStatus) {
    return {
      status: explicitStatus,
      isValid: true,
      normalizedUrl,
      hostname,
      isGovernmentDomain: isGov,
      reason: explicitReason,
    };
  }

  // If authentic government domain and well-formed
  if (isGov) {
    return {
      status: 'verified',
      isValid: true,
      normalizedUrl,
      hostname,
      isGovernmentDomain: true,
    };
  }

  // Non-standard or third-party URL
  return {
    status: 'needs_verification',
    isValid: true,
    normalizedUrl,
    hostname,
    isGovernmentDomain: false,
    reason:
      'Domain is an external or secondary reference that has not been confirmed as an official government portal.',
  };
};

/**
 * Generates a full summary of official website, application, and source URLs for a scheme.
 */
export const getSchemeUrlSummary = (scheme: Partial<GovernmentScheme>): SchemeUrlSummary => {
  const websiteRaw = scheme.officialWebsite || scheme.officialUrl;
  const applicationRaw = scheme.officialApplicationUrl;
  const sourceRaw = scheme.sourceUrl;

  // 1. Official Website
  let officialWebsite: ValidatedSchemeUrl | null = null;
  if (websiteRaw) {
    const res = resolveUrlStatus(websiteRaw, scheme.urlStatus, scheme.urlUnavailableReason);
    if (res.isValid) {
      officialWebsite = {
        url: res.normalizedUrl,
        status: res.status,
        type: 'website',
        label: 'Official Website',
        isGovernmentDomain: res.isGovernmentDomain,
        unavailableReason: res.reason,
        suggestedAlternative: res.suggestedAlternative,
      };
    }
  }

  // 2. Official Application Portal
  let officialApplication: ValidatedSchemeUrl | null = null;
  if (applicationRaw) {
    const res = resolveUrlStatus(applicationRaw, scheme.applicationUrlStatus);
    if (res.isValid) {
      officialApplication = {
        url: res.normalizedUrl,
        status: res.status,
        type: 'application',
        label: 'Apply Online',
        isGovernmentDomain: res.isGovernmentDomain,
        unavailableReason: res.reason,
        suggestedAlternative: res.suggestedAlternative,
      };
    }
  }

  // 3. Source Reference Portal
  let sourceUrl: ValidatedSchemeUrl | null = null;
  if (sourceRaw) {
    const res = resolveUrlStatus(sourceRaw, 'verified');
    if (res.isValid) {
      sourceUrl = {
        url: res.normalizedUrl,
        status: res.status,
        type: 'source',
        label: 'Official Source Reference',
        isGovernmentDomain: res.isGovernmentDomain,
      };
    }
  }

  // Check if separate distinct application portal exists
  const hasSeparateApplicationPortal = Boolean(
    officialApplication &&
      officialWebsite &&
      officialApplication.url !== officialWebsite.url &&
      officialApplication.status === 'verified'
  );

  const isOfficialWebsiteAvailable = Boolean(
    officialWebsite && officialWebsite.status === 'verified'
  );

  return {
    officialWebsite,
    officialApplication,
    sourceUrl,
    hasSeparateApplicationPortal,
    isOfficialWebsiteAvailable,
  };
};

/**
 * Returns structured information for displaying a user-friendly notice
 * when an official website is unavailable or needs verification.
 */
export const getUnavailableNoticeDetails = (
  scheme: Partial<GovernmentScheme>,
  targetUrlInfo?: ValidatedSchemeUrl | null
) => {
  const schemeName = scheme.name || scheme.schemeName || 'Government Scheme';
  const department = scheme.department || 'Concerned Government Department';
  const ministry = scheme.ministry || scheme.department || 'Government Ministry';
  const attemptedUrl = targetUrlInfo?.url || scheme.officialWebsite || scheme.officialUrl || '';

  const reason =
    targetUrlInfo?.unavailableReason ||
    scheme.urlUnavailableReason ||
    'Official website is currently unavailable or experiencing a server timeout. Please verify the scheme through the concerned Government Department.';

  const isKnownTimeout =
    attemptedUrl.includes('aajeevika.gov.in') ||
    reason.toLowerCase().includes('timeout') ||
    reason.toLowerCase().includes('non-operational');

  return {
    title: isKnownTimeout
      ? 'Government Website Temporarily Unavailable'
      : 'Official Website Requires Verification',
    schemeName,
    department,
    ministry,
    attemptedUrl,
    reason,
    isKnownTimeout,
    suggestedAlternative: targetUrlInfo?.suggestedAlternative,
    sourceUrl: scheme.sourceUrl,
    historicalUrl: scheme.historicalUrl,
  };
};
