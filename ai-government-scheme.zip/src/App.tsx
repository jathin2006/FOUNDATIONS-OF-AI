/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import { OfficialTopBanner } from './components/OfficialTopBanner';
import { OfficialHeader } from './components/OfficialHeader';
import { LoginForm } from './components/LoginForm';
import { RegisterView } from './components/RegisterView';
import { ForgotPasswordView } from './components/ForgotPasswordView';
import { AuthStatusCard } from './components/AuthStatusCard';
import { ProfileWizard } from './components/profile/ProfileWizard';
import { AnalyzingScreen } from './components/results/AnalyzingScreen';
import { ResultsDashboard } from './components/results/ResultsDashboard';
import { OfficialFooter } from './components/OfficialFooter';
import { InfoModal } from './components/InfoModal';
import { AuthView, ModalType, ProfileData, ProfileStep, AuthenticatedUser } from './types';
import {
  verifySession,
  logoutUser,
  saveUserProfile,
  saveUserDraft,
  createDefaultProfile,
} from './services/userService';

export default function App() {
  const [authView, setAuthView] = useState<AuthView>('login');
  const [activeModal, setActiveModal] = useState<ModalType>(null);
  const [currentUser, setCurrentUser] = useState<AuthenticatedUser | null>(null);
  const [isCheckingSession, setIsCheckingSession] = useState<boolean>(true);
  const [userEmail, setUserEmail] = useState<string>('');
  const [savedProfile, setSavedProfile] = useState<ProfileData | null>(null);
  const [wizardStep, setWizardStep] = useState<ProfileStep>(1);

  // Check real backend authentication session on initial load and page refresh
  useEffect(() => {
    let isMounted = true;
    async function initSession() {
      try {
        const res = await verifySession();
        if (isMounted) {
          if (res.authenticated && res.user) {
            setCurrentUser(res.user);
            setUserEmail(res.user.email);
            setSavedProfile(res.user.profile);
            if (res.user.profileCompleted) {
              setAuthView('recommendations');
            } else {
              setWizardStep(res.user.lastActiveStep || 1);
              setAuthView('profile-wizard');
            }
          } else {
            setCurrentUser(null);
            setUserEmail('');
            setSavedProfile(null);
            setAuthView('login');
          }
        }
      } catch (err) {
        console.error('Session verification error:', err);
        if (isMounted) {
          setCurrentUser(null);
          setAuthView('login');
        }
      } finally {
        if (isMounted) {
          setIsCheckingSession(false);
        }
      }
    }
    initSession();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleLoginSuccess = async (_email: string) => {
    // Retrieve validated session and user record from backend
    const res = await verifySession();
    if (res.authenticated && res.user) {
      setCurrentUser(res.user);
      setUserEmail(res.user.email);
      setSavedProfile(res.user.profile);

      if (res.user.profileCompleted) {
        setAuthView('recommendations');
      } else {
        setWizardStep(res.user.lastActiveStep || 1);
        setAuthView('profile-wizard');
      }
    }
  };

  const handleSignOut = async () => {
    await logoutUser();
    setCurrentUser(null);
    setUserEmail('');
    setSavedProfile(null);
    setWizardStep(1);
    setAuthView('login');
  };

  const handleEditProfile = () => {
    if (!currentUser) {
      setAuthView('login');
      return;
    }
    setWizardStep(8);
    setAuthView('profile-wizard');
  };

  const handleFindEligibleSchemes = async (data: ProfileData) => {
    if (!currentUser) {
      setAuthView('login');
      return;
    }
    const updated = await saveUserProfile(currentUser.email, data, true, 8);
    if (updated) {
      setCurrentUser(updated);
      setSavedProfile(updated.profile);
    } else {
      setSavedProfile(data);
    }
    setAuthView('analyzing');
  };

  const handleSaveDraft = async (data: ProfileData, step: ProfileStep) => {
    if (!currentUser) return;
    const updated = await saveUserDraft(currentUser.email, data, step);
    if (updated) {
      setCurrentUser(updated);
      setSavedProfile(updated.profile);
    }
  };

  // 1. Session verification loading screen
  if (isCheckingSession) {
    return (
      <div className="min-h-screen bg-[#061226] text-white flex items-center justify-center font-sans">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
          <p className="text-sm font-semibold tracking-wide text-blue-200">
            Verifying secure citizen session...
          </p>
        </div>
      </div>
    );
  }

  // 2. Protected Route Guard: If not authenticated, prevent access to protected wizard/dashboard
  const isProtectedView = ['profile-wizard', 'analyzing', 'recommendations'].includes(authView);
  if (isProtectedView && !currentUser) {
    return (
      <div
        className="min-h-screen flex flex-col font-sans relative overflow-x-hidden text-white bg-[#061226]"
        style={{
          backgroundImage: `
            radial-gradient(circle at 50% 40%, rgba(20, 72, 140, 0.45) 0%, rgba(10, 35, 75, 0.25) 45%, rgba(4, 12, 26, 0.95) 100%),
            radial-gradient(circle at 80% 20%, rgba(14, 116, 204, 0.2) 0%, transparent 50%),
            radial-gradient(circle at 20% 70%, rgba(6, 68, 130, 0.25) 0%, transparent 60%)
          `,
        }}
      >
        <OfficialTopBanner onOpenHelp={() => setActiveModal('contact')} />
        <OfficialHeader onContactClick={() => setActiveModal('contact')} onResetView={() => setAuthView('login')} />
        <main className="flex-1 py-8 sm:py-12 px-4 sm:px-6 flex items-center justify-center relative z-10">
          <LoginForm
            onNavigateToRegister={() => setAuthView('register')}
            onNavigateToForgotPassword={() => setAuthView('forgot-password')}
            onLoginSuccess={handleLoginSuccess}
          />
        </main>
        <OfficialFooter onOpenModal={(type) => setActiveModal(type)} />
        <InfoModal modalType={activeModal} onClose={() => setActiveModal(null)} />
      </div>
    );
  }

  // 3. Render protected wizard
  if (authView === 'profile-wizard' && currentUser) {
    return (
      <div className="min-h-screen text-[15px]">
        <ProfileWizard
          key={`${currentUser.uid}_${wizardStep}`}
          userEmail={currentUser.email}
          initialProfileData={savedProfile || currentUser.profile || undefined}
          initialStep={wizardStep}
          onExitToLogin={handleSignOut}
          onSaveDraft={handleSaveDraft}
          onFindEligibleSchemes={handleFindEligibleSchemes}
        />
        <InfoModal modalType={activeModal} onClose={() => setActiveModal(null)} />
      </div>
    );
  }

  // 4. Render protected analyzing screen
  if (authView === 'analyzing' && currentUser) {
    return (
      <div className="min-h-screen text-[15px]">
        <AnalyzingScreen
          onComplete={() => setAuthView('recommendations')}
        />
      </div>
    );
  }

  // 5. Render protected recommendations dashboard
  if (authView === 'recommendations' && currentUser) {
    const activeProfile: ProfileData =
      savedProfile || currentUser.profile || createDefaultProfile(currentUser.fullName);

    return (
      <div className="min-h-screen text-[15px]">
        <ResultsDashboard
          profileData={activeProfile}
          userEmail={currentUser.email}
          onEditProfile={handleEditProfile}
          onSignOut={handleSignOut}
        />
        <InfoModal modalType={activeModal} onClose={() => setActiveModal(null)} />
      </div>
    );
  }

  // 6. Public authentication views
  return (
    <div
      className="min-h-screen flex flex-col font-sans relative overflow-x-hidden text-white bg-[#061226]"
      style={{
        backgroundImage: `
          radial-gradient(circle at 50% 40%, rgba(20, 72, 140, 0.45) 0%, rgba(10, 35, 75, 0.25) 45%, rgba(4, 12, 26, 0.95) 100%),
          radial-gradient(circle at 80% 20%, rgba(14, 116, 204, 0.2) 0%, transparent 50%),
          radial-gradient(circle at 20% 70%, rgba(6, 68, 130, 0.25) 0%, transparent 60%)
        `,
      }}
    >
      {/* Background ambient lighting orbs to create authentic glassmorphism depth */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-blue-600/20 rounded-full blur-[120px] pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute top-1/2 left-1/4 w-[350px] h-[350px] bg-cyan-600/10 rounded-full blur-[100px] pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-indigo-600/15 rounded-full blur-[110px] pointer-events-none"
        aria-hidden="true"
      />

      {/* Top Banner: Official Status */}
      <OfficialTopBanner
        onOpenHelp={() => setActiveModal('contact')}
      />

      {/* Official Government Header */}
      <OfficialHeader
        onContactClick={() => setActiveModal('contact')}
        onResetView={() => setAuthView('login')}
      />

      {/* Main Section */}
      <main className="flex-1 py-8 sm:py-12 px-4 sm:px-6 flex items-center justify-center relative z-10">
        <div className="w-full flex items-center justify-center">
          {authView === 'login' && (
            <LoginForm
              onNavigateToRegister={() => setAuthView('register')}
              onNavigateToForgotPassword={() => setAuthView('forgot-password')}
              onLoginSuccess={handleLoginSuccess}
            />
          )}

          {authView === 'register' && (
            <RegisterView
              onBackToLogin={() => setAuthView('login')}
              onRegisterSuccess={(email) => {
                handleLoginSuccess(email);
              }}
            />
          )}

          {authView === 'forgot-password' && (
            <ForgotPasswordView
              onBackToLogin={() => setAuthView('login')}
            />
          )}

          {authView === 'guest-active' && (
            <AuthStatusCard
              mode="guest"
              onProceedToProfile={() => setAuthView('profile-wizard')}
              onReturnToLogin={() => setAuthView('login')}
            />
          )}

          {authView === 'login-success' && (
            <AuthStatusCard
              mode="authenticated"
              userEmail={userEmail}
              onProceedToProfile={() => setAuthView('profile-wizard')}
              onReturnToLogin={() => setAuthView('login')}
            />
          )}
        </div>
      </main>

      {/* Official Public Footer */}
      <OfficialFooter onOpenModal={(type) => setActiveModal(type)} />

      {/* Policy, Terms & Contact Modal */}
      <InfoModal modalType={activeModal} onClose={() => setActiveModal(null)} />
    </div>
  );
}
