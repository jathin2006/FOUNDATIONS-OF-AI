export type AuthView =
  | 'login'
  | 'register'
  | 'forgot-password'
  | 'guest-active'
  | 'login-success'
  | 'profile-wizard'
  | 'analyzing'
  | 'recommendations'
  | 'admin-schemes';

export type ModalType = 'privacy' | 'terms' | 'contact' | 'accessibility' | null;

export type ProfileStep = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;

export interface ProfileData {
  // Step 1: Personal Details
  fullName: string;
  age: string;
  gender: 'Male' | 'Female' | 'Other' | '';
  state: string;
  district: string;

  // Step 2: Social & Category Details
  religion: string;
  casteCategory: 'General' | 'OBC' | 'SC' | 'ST' | 'EWS' | 'Other' | '';
  minorityCommunity: 'Yes' | 'No' | '';

  // Step 3: Financial Details
  personalIncome: string;
  familyIncome: string;
  bplRationCard: 'Yes' | 'No' | '';

  // Step 4: Educational Details
  educationLevel:
    | 'Primary School'
    | 'Secondary School'
    | 'Higher Secondary'
    | 'Diploma'
    | 'Undergraduate'
    | 'Postgraduate'
    | 'PhD'
    | 'Not Studying'
    | '';
  courseStream: string;
  currentStudent: 'Yes' | 'No' | '';
  currentGradeYear: string;

  // Step 5: Employment Details
  employmentStatus:
    | 'Student'
    | 'Employed'
    | 'Unemployed'
    | 'Self-employed'
    | 'Farmer'
    | 'Daily Wage Worker'
    | 'Retired'
    | 'Other'
    | '';
  otherEmploymentStatus?: string;
  occupation: string;
  farmerLandOwnership: 'Yes' | 'No' | '';

  // Step 6: Family Details
  maritalStatus: 'Single' | 'Married' | 'Widowed' | 'Divorced' | 'Separated' | '';
  familyMembersCount: string;
  earningMembersCount: string;

  // Step 7: Special Conditions
  personWithDisability: 'Yes' | 'No' | '';
  disabilityPercentage: string;
  isFarmer: 'Yes' | 'No' | '';
  ownAgriculturalLand: 'Yes' | 'No' | '';
  ownHouse: 'Yes' | 'No' | '';
}

export interface ValidationErrors {
  email?: string;
  password?: string;
  fullName?: string;
  confirmPassword?: string;
  terms?: string;
  [key: string]: string | undefined;
}

// Scheme Evaluation Types
export type SchemeCategory =
  | 'Education'
  | 'Financial Assistance'
  | 'Employment'
  | 'Agriculture'
  | 'Housing'
  | 'Health'
  | 'Social Welfare'
  | 'Women & Child Development'
  | 'Skill Development'
  | 'Pension & Senior Citizen'
  | 'Other';

export type GovernmentLevel = 'Central' | 'State' | 'UT';

export type SchemeUrlStatus = 'verified' | 'unavailable' | 'needs_verification' | 'unknown';

export type EligibilityStatus = 'Potentially Eligible' | 'Partial Match' | 'Not Matching';

export interface SchemeRule {
  id: string;
  label: string;
  isMandatory: boolean;
  evaluate: (profile: ProfileData) => { satisfied: boolean; reason: string };
}

export interface GovernmentScheme {
  id: string;
  // Core Identifiers & Names
  schemeName?: string;
  name: string; // Backwards compatible with existing UI
  shortDescription?: string;
  description: string; // Backwards compatible with existing UI
  detailedDescription?: string;

  // Administrative hierarchy
  governmentLevel?: GovernmentLevel;
  ministry?: string;
  department: string;
  state?: string; // e.g. "All" or specific state like "Tamil Nadu", "Maharashtra"

  // Taxonomy
  category: SchemeCategory;
  subCategory?: string;
  tags?: string[];

  // Benefits & Criteria summaries
  benefits: string[];
  eligibilityCriteria?: string[];

  // Structured Demographic Criteria
  minimumAge?: number;
  maximumAge?: number;
  gender?: ('Male' | 'Female' | 'Other')[] | 'All' | string;
  casteCategory?: ('General' | 'OBC' | 'SC' | 'ST' | 'EWS' | 'Other')[] | 'All' | string;
  religion?: string[] | string;
  minorityRequirement?: boolean | 'Yes' | 'No' | 'Both';

  // Structured Financial Criteria
  personalIncomeLimit?: number;
  familyIncomeLimit?: number;
  bplRequirement?: boolean | 'Yes' | 'No' | 'Both';
  rationCardRequirement?: boolean | 'Yes' | 'No' | 'Both';

  // Structured Educational Criteria
  educationRequirement?: string[] | string;
  courseStream?: string[];
  studentRequirement?: boolean | 'Yes' | 'No' | 'Both';

  // Structured Employment / Occupation Criteria
  employmentRequirement?: string[] | string;
  occupationRequirement?: string[] | string;
  farmerRequirement?: boolean | 'Yes' | 'No' | 'Both';
  landOwnershipRequirement?: boolean | 'Yes' | 'No' | 'Both';

  // Structured Family & Special Condition Criteria
  maritalStatus?: ('Single' | 'Married' | 'Widowed' | 'Divorced' | 'Separated')[] | 'All';
  familySizeRequirement?: number;
  disabilityRequirement?: boolean | 'Yes' | 'No' | 'Both';
  disabilityPercentage?: number;

  // Documentation & Procedure
  requiredDocuments: string[];
  applicationProcedure?: string[];
  applicationProcess: string[]; // Backwards compatible

  // Verification & Portals
  officialWebsite?: string;
  officialApplicationUrl?: string;
  officialUrl: string; // Backwards compatible
  sourceUrl?: string; // Primary reference URL (e.g. myScheme or ministry portal)
  urlStatus?: SchemeUrlStatus;
  applicationUrlStatus?: SchemeUrlStatus;
  urlUnavailableReason?: string;
  historicalUrl?: string;
  lastUpdated?: string;
  activeStatus?: boolean | 'Active' | 'Discontinued';

  // Data authenticity metadata
  isVerifiedOfficial?: boolean;
  isDemoScheme?: boolean;

  // Rules evaluated by the engine (can be predefined or dynamically derived)
  rules: SchemeRule[];
}

export interface RuleResult {
  label: string;
  satisfied: boolean;
  reason: string;
  isMandatory: boolean;
}

export interface EvaluatedScheme {
  scheme: GovernmentScheme;
  matchScore: number; // 0 to 100 percentage
  status: EligibilityStatus;
  matchedRules: RuleResult[];
  unmetRules: RuleResult[];
}

export interface SchemeDatasetMetadata {
  datasetVersion: string;
  sourceName: string;
  sourceUrl: string;
  lastSynchronized: string;
  totalSchemesCount: number;
  verifiedOfficialCount: number;
  centralSchemesCount: number;
  stateSchemesCount: number;
  isRealVerifiedDataset: boolean;
}

export interface SchemeImportResult {
  success: boolean;
  importedCount: number;
  skippedCount: number;
  errors: string[];
  totalDatabaseCount: number;
}

export interface AuthenticatedUser {
  uid: string;
  email: string;
  fullName: string;
  profileCompleted: boolean;
  lastActiveStep: ProfileStep;
  profile: ProfileData;
}
