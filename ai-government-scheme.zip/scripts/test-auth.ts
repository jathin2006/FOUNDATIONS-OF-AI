import http from 'http';
import fs from 'fs';
import path from 'path';

const BASE_URL = 'http://127.0.0.1:3000';

function makeRequest(method: string, pathUrl: string, body?: any, token?: string): Promise<{ status: number; data: any }> {
  return new Promise((resolve, reject) => {
    const url = new URL(pathUrl, BASE_URL);
    const postData = body ? JSON.stringify(body) : null;
    const options: http.RequestOptions = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname,
      method: method,
      headers: {
        'Content-Type': 'application/json',
        ...(postData ? { 'Content-Length': Buffer.byteLength(postData) } : {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    };

    const req = http.request(options, (res) => {
      let rawData = '';
      res.on('data', (chunk) => {
        rawData += chunk;
      });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(rawData);
          resolve({ status: res.statusCode || 200, data: parsed });
        } catch {
          resolve({ status: res.statusCode || 200, data: rawData });
        }
      });
    });

    req.on('error', (err) => reject(err));
    if (postData) req.write(postData);
    req.end();
  });
}

async function runTests() {
  console.log('--- STARTING AUTHENTICATION VERIFICATION TEST SUITE ---');

  // TEST 1: Unregistered email
  console.log('\n[TEST 1] Testing unregistered email login:');
  const test1 = await makeRequest('POST', '/api/auth/login', {
    email: 'unregistered_random_user_999@example.com',
    password: 'Password@123',
  });
  console.log(`Status: ${test1.status}`);
  console.log(`Response:`, test1.data);
  if (test1.status === 404 && test1.data.error === 'No account found with this email address. Please create an account first.') {
    console.log('✅ TEST 1 PASSED: Unregistered email rejected with expected message.');
  } else {
    console.error('❌ TEST 1 FAILED');
    process.exit(1);
  }

  // TEST 2: Register a new account
  console.log('\n[TEST 2] Testing real account registration:');
  const user1Email = `citizen_test_${Date.now()}@advisor.gov.in`;
  const user1Pass = 'SecureGov@2026';
  const test2 = await makeRequest('POST', '/api/auth/register', {
    email: user1Email,
    fullName: 'Ananya Sharma',
    password: user1Pass,
  });
  console.log(`Status: ${test2.status}`);
  console.log(`Response (user):`, { uid: test2.data.user?.uid, email: test2.data.user?.email, tokenExists: Boolean(test2.data.token) });
  if (test2.status === 201 && test2.data.success && test2.data.token && test2.data.user?.uid) {
    console.log('✅ TEST 2 PASSED: Account registered securely with UID and token.');
  } else {
    console.error('❌ TEST 2 FAILED');
    process.exit(1);
  }

  // TEST 3: Login with newly registered email and correct password
  console.log('\n[TEST 3] Testing login with valid credentials:');
  const test3 = await makeRequest('POST', '/api/auth/login', {
    email: user1Email,
    password: user1Pass,
  });
  console.log(`Status: ${test3.status}`);
  console.log(`Response (token):`, Boolean(test3.data.token));
  if (test3.status === 200 && test3.data.success && test3.data.token && test3.data.user?.email === user1Email) {
    console.log('✅ TEST 3 PASSED: Login succeeded with valid credentials.');
  } else {
    console.error('❌ TEST 3 FAILED');
    process.exit(1);
  }
  const user1Token = test3.data.token;

  // TEST 4: Login with incorrect password
  console.log('\n[TEST 4] Testing login with incorrect password:');
  const test4 = await makeRequest('POST', '/api/auth/login', {
    email: user1Email,
    password: 'WrongPassword@999',
  });
  console.log(`Status: ${test4.status}`);
  console.log(`Response:`, test4.data);
  if (test4.status === 401 && test4.data.error === 'Incorrect email or password. Please try again.') {
    console.log('✅ TEST 4 PASSED: Incorrect password rejected with expected message.');
  } else {
    console.error('❌ TEST 4 FAILED');
    process.exit(1);
  }

  // TEST 5 & 6: Verify session restoration and logout invalidation
  console.log('\n[TEST 6] Testing session restoration via /api/auth/session:');
  const test6 = await makeRequest('GET', '/api/auth/session', null, user1Token);
  console.log(`Status: ${test6.status}, Authenticated: ${test6.data.authenticated}`);
  if (test6.status === 200 && test6.data.authenticated && test6.data.user?.email === user1Email) {
    console.log('✅ TEST 6 PASSED: Session verified successfully.');
  } else {
    console.error('❌ TEST 6 FAILED');
    process.exit(1);
  }

  console.log('\n[TEST 5] Testing logout and access invalidation:');
  const logoutRes = await makeRequest('POST', '/api/auth/logout', null, user1Token);
  console.log('Logout result:', logoutRes.data);
  const test5 = await makeRequest('GET', '/api/auth/session', null, user1Token);
  console.log(`Status after logout: ${test5.status}`);
  if (test5.status === 401) {
    console.log('✅ TEST 5 PASSED: Session token invalidated on backend. Protected access denied.');
  } else {
    console.error('❌ TEST 5 FAILED');
    process.exit(1);
  }

  // TEST 7: Data isolation between two different users
  console.log('\n[TEST 7] Testing data isolation between two users:');
  // Register User A
  const emailA = `citizen_a_${Date.now()}@advisor.gov.in`;
  const resA = await makeRequest('POST', '/api/auth/register', {
    email: emailA,
    fullName: 'Citizen Alpha',
    password: 'PasswordAlpha@123',
  });
  const tokenA = resA.data.token;

  // Save profile for User A
  await makeRequest('POST', '/api/user/profile', {
    profile: {
      fullName: 'Citizen Alpha',
      state: 'Tamil Nadu',
      district: 'Chennai',
      casteCategory: 'General',
      educationLevel: 'Undergraduate',
      employmentStatus: 'Employed',
    },
    completed: true,
    step: 8,
  }, tokenA);

  // Register User B
  const emailB = `citizen_b_${Date.now()}@advisor.gov.in`;
  const resB = await makeRequest('POST', '/api/auth/register', {
    email: emailB,
    fullName: 'Citizen Beta',
    password: 'PasswordBeta@123',
  });
  const tokenB = resB.data.token;

  // Save profile for User B
  await makeRequest('POST', '/api/user/profile', {
    profile: {
      fullName: 'Citizen Beta',
      state: 'Maharashtra',
      district: 'Pune',
      casteCategory: 'OBC',
      educationLevel: 'Postgraduate',
      employmentStatus: 'Self-employed',
    },
    completed: true,
    step: 8,
  }, tokenB);

  // Read User A's profile
  const profileA = await makeRequest('GET', '/api/user/profile', null, tokenA);
  // Read User B's profile
  const profileB = await makeRequest('GET', '/api/user/profile', null, tokenB);

  console.log(`User A state: ${profileA.data.profile?.state}, district: ${profileA.data.profile?.district}`);
  console.log(`User B state: ${profileB.data.profile?.state}, district: ${profileB.data.profile?.district}`);

  if (
    profileA.data.profile?.state === 'Tamil Nadu' &&
    profileB.data.profile?.state === 'Maharashtra' &&
    profileA.data.uid !== profileB.data.uid
  ) {
    console.log('✅ TEST 7 PASSED: Profiles are strictly isolated by authenticated user UID.');
  } else {
    console.error('❌ TEST 7 FAILED');
    process.exit(1);
  }

  // TEST 8: Verify no plaintext passwords in database or code
  console.log('\n[TEST 8] Verifying no plaintext passwords stored in database:');
  const dbContent = fs.readFileSync(path.resolve('.data/auth_db.json'), 'utf-8');
  const dbData = JSON.parse(dbContent);
  const users = Object.values(dbData.users) as any[];

  let hasPlaintext = false;
  for (const u of users) {
    if (!u.passwordHash || !u.passwordHash.startsWith('$2')) {
      hasPlaintext = true;
      console.error(`User ${u.email} does not have a bcrypt hash!`, u.passwordHash);
    }
  }

  if (!hasPlaintext && !dbContent.includes('PasswordAlpha@123') && !dbContent.includes('PasswordBeta@123')) {
    console.log('✅ TEST 8 PASSED: All user passwords are encrypted using bcrypt hashes ($2a$/$2b$). Zero plaintext passwords.');
  } else {
    console.error('❌ TEST 8 FAILED: Plaintext password detected!');
    process.exit(1);
  }

  console.log('\n🎉 ALL 8 AUTHENTICATION TESTS PASSED SUCCESSFULLY! 🎉\n');
}

runTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
