import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';

interface UserRecord {
  uid: string;
  email: string; // normalized
  fullName: string;
  passwordHash: string; // bcrypt hash
  createdAt: string;
  updatedAt: string;
  profileCompleted: boolean;
  lastActiveStep: number;
  profile: any;
}

interface SessionRecord {
  token: string;
  uid: string;
  createdAt: string;
  expiresAt: string;
}

interface DatabaseSchema {
  users: Record<string, UserRecord>; // keyed by normalized email
  sessions: Record<string, SessionRecord>; // keyed by token
}

const DB_DIR = path.resolve('.data');
const DB_PATH = path.join(DB_DIR, 'auth_db.json');

const createDefaultProfile = (fullName: string = '') => ({
  fullName: fullName || '',
  age: '',
  gender: '',
  state: '',
  district: '',
  religion: '',
  casteCategory: '',
  minorityCommunity: '',
  personalIncome: '',
  familyIncome: '',
  bplRationCard: '',
  educationLevel: '',
  courseStream: '',
  currentStudent: '',
  currentGradeYear: '',
  employmentStatus: '',
  otherEmploymentStatus: '',
  occupation: '',
  farmerLandOwnership: '',
  maritalStatus: '',
  familyMembersCount: '',
  earningMembersCount: '',
  personWithDisability: '',
  disabilityPercentage: '',
  isFarmer: '',
  ownAgriculturalLand: '',
  ownHouse: '',
});

// Load or initialize file-backed database
function loadDatabase(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_PATH)) {
      const content = fs.readFileSync(DB_PATH, 'utf-8');
      const data = JSON.parse(content);
      if (data && typeof data === 'object' && data.users && data.sessions) {
        return data as DatabaseSchema;
      }
    }
  } catch (err) {
    console.error('Error reading auth database, creating fresh instance:', err);
  }

  // Initialize with seeded citizen account with bcrypt-hashed password (NEVER plaintext)
  const initialDb: DatabaseSchema = {
    users: {},
    sessions: {},
  };

  const seedEmail = 'citizen@gov.in';
  const seedPasswordHash = bcrypt.hashSync('Password@123', 10);
  initialDb.users[seedEmail] = {
    uid: 'usr_citizen_gov_in',
    email: seedEmail,
    fullName: 'Rajesh Kumar',
    passwordHash: seedPasswordHash,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    profileCompleted: false,
    lastActiveStep: 1,
    profile: createDefaultProfile('Rajesh Kumar'),
  };

  saveDatabase(initialDb);
  return initialDb;
}

function saveDatabase(db: DatabaseSchema) {
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    // Atomic write to prevent file corruption
    const tempPath = `${DB_PATH}.tmp.${Date.now()}`;
    fs.writeFileSync(tempPath, JSON.stringify(db, null, 2), 'utf-8');
    fs.renameSync(tempPath, DB_PATH);
  } catch (err) {
    console.error('Failed to save auth database:', err);
  }
}

const db = loadDatabase();

const normalizeEmail = (email: string): string => {
  return (email || '').trim().toLowerCase();
};

const isValidEmail = (email: string): boolean => {
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailPattern.test(email);
};

const sanitizeUserOutput = (user: UserRecord) => ({
  uid: user.uid,
  email: user.email,
  fullName: user.fullName,
  profileCompleted: user.profileCompleted,
  lastActiveStep: user.lastActiveStep,
  profile: user.profile,
  updatedAt: user.updatedAt,
});

// Middleware to authenticate Bearer token
const authenticateToken = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ authenticated: false, error: 'Authentication token required.' });
  }

  const token = authHeader.substring(7).trim();
  const session = db.sessions[token];
  if (!session) {
    return res.status(401).json({ authenticated: false, error: 'Invalid or expired session token.' });
  }

  const now = new Date().getTime();
  const expiresAt = new Date(session.expiresAt).getTime();
  if (now > expiresAt) {
    delete db.sessions[token];
    saveDatabase(db);
    return res.status(401).json({ authenticated: false, error: 'Session expired. Please log in again.' });
  }

  // Lookup user by UID
  const user = Object.values(db.users).find((u) => u.uid === session.uid);
  if (!user) {
    delete db.sessions[token];
    saveDatabase(db);
    return res.status(401).json({ authenticated: false, error: 'User account not found.' });
  }

  (req as any).user = user;
  (req as any).sessionToken = token;
  next();
};

async function startServer() {
  const app = express();
  app.use(express.json());

  // ---------------- AUTHENTICATION API ROUTES ----------------

  // Health / Provider Check
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      provider: 'custom-backend-auth-bcrypt',
      timestamp: new Date().toISOString(),
    });
  });

  // 1. REGISTER
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const { email, password, fullName } = req.body;

      const normalized = normalizeEmail(email);
      if (!normalized || !isValidEmail(normalized)) {
        return res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
      }

      if (!password || typeof password !== 'string') {
        return res.status(400).json({ success: false, error: 'Password is required.' });
      }

      if (password.length < 8) {
        return res.status(400).json({ success: false, error: 'Password must be at least 8 characters long.' });
      }

      const trimmedName = (fullName || '').trim() || normalized.split('@')[0];

      // Check if user already exists
      if (db.users[normalized]) {
        return res.status(409).json({
          success: false,
          error: 'An account with this email address already exists. Please sign in instead.',
        });
      }

      // Hash password using bcrypt (cost factor 10)
      const passwordHash = await bcrypt.hash(password, 10);
      const uid = `usr_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;

      const newUser: UserRecord = {
        uid,
        email: normalized,
        fullName: trimmedName,
        passwordHash,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        profileCompleted: false,
        lastActiveStep: 1,
        profile: createDefaultProfile(trimmedName),
      };

      db.users[normalized] = newUser;

      // Issue cryptographically secure session token (valid for 7 days)
      const token = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
      db.sessions[token] = {
        token,
        uid,
        createdAt: new Date().toISOString(),
        expiresAt,
      };

      saveDatabase(db);

      return res.status(201).json({
        success: true,
        token,
        user: sanitizeUserOutput(newUser),
      });
    } catch (err: any) {
      console.error('Registration error:', err);
      return res.status(500).json({ success: false, error: 'Registration failed due to a server error.' });
    }
  });

  // 2. LOGIN
  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;

      const normalized = normalizeEmail(email);
      if (!normalized || !isValidEmail(normalized)) {
        return res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
      }

      if (!password) {
        return res.status(400).json({ success: false, error: 'Password is required.' });
      }

      const user = db.users[normalized];
      if (!user) {
        // Explicit required message for unregistered email
        return res.status(404).json({
          success: false,
          error: 'No account found with this email address. Please create an account first.',
        });
      }

      // Verify bcrypt password hash
      const isMatch = await bcrypt.compare(password, user.passwordHash);
      if (!isMatch) {
        // Explicit required message for incorrect password
        return res.status(401).json({
          success: false,
          error: 'Incorrect email or password. Please try again.',
        });
      }

      // Generate secure session token
      const token = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
      db.sessions[token] = {
        token,
        uid: user.uid,
        createdAt: new Date().toISOString(),
        expiresAt,
      };

      saveDatabase(db);

      return res.json({
        success: true,
        token,
        user: sanitizeUserOutput(user),
      });
    } catch (err: any) {
      console.error('Login error:', err);
      return res.status(500).json({ success: false, error: 'Authentication failed due to a server error.' });
    }
  });

  // 3. VERIFY SESSION
  app.get('/api/auth/session', authenticateToken, (req: Request, res: Response) => {
    const user = (req as any).user as UserRecord;
    return res.json({
      authenticated: true,
      user: sanitizeUserOutput(user),
    });
  });

  // 4. LOGOUT
  app.post('/api/auth/logout', authenticateToken, (req: Request, res: Response) => {
    const token = (req as any).sessionToken as string;
    if (token && db.sessions[token]) {
      delete db.sessions[token];
      saveDatabase(db);
    }
    return res.json({ success: true, message: 'Logged out successfully.' });
  });

  // 5. GET USER PROFILE (Isolated to authenticated user's UID)
  app.get('/api/user/profile', authenticateToken, (req: Request, res: Response) => {
    const user = (req as any).user as UserRecord;
    return res.json({
      success: true,
      uid: user.uid,
      profile: user.profile,
      profileCompleted: user.profileCompleted,
      lastActiveStep: user.lastActiveStep,
    });
  });

  // 6. SAVE USER PROFILE (Isolated to authenticated user's UID)
  app.post('/api/user/profile', authenticateToken, (req: Request, res: Response) => {
    const user = (req as any).user as UserRecord;
    const { profile, completed, step } = req.body;

    if (!profile || typeof profile !== 'object') {
      return res.status(400).json({ success: false, error: 'Valid profile object required.' });
    }

    user.profile = { ...user.profile, ...profile };
    user.profileCompleted = Boolean(completed);
    user.lastActiveStep = Number(step) || user.lastActiveStep || 1;
    user.updatedAt = new Date().toISOString();
    if (profile.fullName && profile.fullName.trim()) {
      user.fullName = profile.fullName.trim();
    }

    db.users[user.email] = user;
    saveDatabase(db);

    return res.json({
      success: true,
      user: sanitizeUserOutput(user),
    });
  });

  // 7. SAVE USER DRAFT
  app.post('/api/user/draft', authenticateToken, (req: Request, res: Response) => {
    const user = (req as any).user as UserRecord;
    const { profileFields, step } = req.body;

    user.profile = { ...user.profile, ...profileFields };
    user.lastActiveStep = Number(step) || user.lastActiveStep || 1;
    user.updatedAt = new Date().toISOString();

    db.users[user.email] = user;
    saveDatabase(db);

    return res.json({
      success: true,
      user: sanitizeUserOutput(user),
    });
  });

  // ---------------- VITE FRONTEND MOUNTING ----------------
  const isProd = process.env.NODE_ENV === 'production';
  if (isProd) {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Government Scheme Advisor] Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
  process.exit(1);
});
